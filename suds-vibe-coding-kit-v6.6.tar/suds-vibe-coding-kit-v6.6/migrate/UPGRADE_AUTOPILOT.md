# UPGRADE_AUTOPILOT.md — upgrade this project's kit with ZERO user steering

**Who this file is for: the AGENT.** If a newer kit has been dropped anywhere inside this
project (a temp folder, `.kit-incoming/`, an unpacked tar) and the user says anything like
"upgrade the kit" / "apply the new kit" — or you find a staged kit while orienting — follow
this file top to bottom and **do not ask the user anything** unless a §6 stop condition is
met. Every decision an upgrade requires is either made by the migrator (deterministic, by
hash) or prescribed as a merge rule below (semantic, by file). The design goal: the user's
only actions are *drop the folder in* and *read your final report*.

Contract with the user, stated once: nothing of theirs is ever overwritten (backup + branch +
WIP snapshot happen before any write), every judgment call follows a written rule, and the
upgrade ends in a verified green state or an honest report of exactly what's red and why.

---

## §1 — Stage (skip whatever is already done)

1. If the new kit is a tar: `mkdir -p .kit-incoming && tar -xf <kit>.tar -C .kit-incoming
   --strip-components=1`. If it's already an unpacked folder anywhere in the project, leave
   it where it is — discovery finds it. Ensure `.kit-incoming` is gitignored (the kit's
   `.gitignore` already lists it; add it if this project's copy predates that).
2. Do **not** pre-clean the working tree and do not ask the user to. A dirty tree is handled
   automatically in §2 (snapshot commit on the migration branch).

## §2 — Run the migrator's autopilot mode

```bash
python .kit-incoming/migrate/migrate_kit.py --auto
```

(If the staged kit is elsewhere, `--auto` discovers it; you can also pass `--kit <dir>`
explicitly. Always run the NEW kit's migrator, not the project's old copy.)

What `--auto` does deterministically — trust it, don't redo it by hand: discovers the staged
kit; classifies every file by hash (PRESERVE / OVERWRITE / ADD / MERGE / SKIP-DRIFTED /
RETIRE); writes a full backup to `.kit-backup-<stamp>/`; creates branch
`migrate-kit-<stamp>`; commits any dirty work as `wip: pre-kit-upgrade snapshot (auto)`;
applies OVERWRITE + ADD; stages every judgment file as `<file>.kit-incoming`; auto-merges
`SinsGotchasLearnings.md` via `merge_sins.py` (your entries first and verbatim, kit backstops
appended, deduped by title, renumbered); and prints the remaining sidecar list.

**Read the plan output.** If OVERWRITE shows a matched stock version (e.g. `stock v6.5`),
provenance is verified. A large SKIP-DRIFTED bucket usually means the project is on a version
this kit has no baseline for — the sidecar flow below still handles it safely, file by file.

## §3 — Resolve each remaining `.kit-incoming` sidecar (the semantic merges)

General rule for ALL sidecars: the three inputs are **yours** (current file), **theirs**
(`<file>.kit-incoming`), and **base** (`.kit-backup-<stamp>/<file>`). Produce a merge, write
it over yours, delete the sidecar. Per-file rules — apply mechanically:

- **`AGENTS.md`** — the kit owns the numbered § structure; the project owns its insertions.
  Start FROM the kit version. Then re-apply, at their designated slots, anything in yours
  that is project-specific: entries under "[Project-specific anti-patterns …]" (§2 tail),
  a non-empty `## Child DOX Index`, any project-added §0b digest items (respect the ≤20
  budget — kit items win slots on conflict), and any custom sections not present in the kit
  file at all (append them at the end, preserving their heading levels). Never keep an OLD
  kit paragraph over a NEW kit paragraph — diff yours against base to tell project additions
  (keep) apart from stale kit text (drop).
- **`EXECUTION_PLAN.md`** — yours is project state. Keep yours wholesale; port ONLY
  structural improvements from the kit version that don't exist in yours (e.g. a new phase
  template field). When in doubt, keep yours untouched.
- **`RepoMapReadFirst.md`** — keep YOUR curated block verbatim; take the kit's scaffolding
  around it if the layout changed; then `just map-sync` regenerates the generated part anyway.
- **`skills/grill-to-prd.md`** (and any other `skills/*.md` sidecar) — kit-owned prose. Take
  the kit version wholesale UNLESS the diff vs base shows deliberate project edits; port
  those edits into the kit version.
- **Config/infra sidecars** (`justfile`, `scripts/*`, `verify.ps1`, `.mise.toml`,
  tool-pointer files…) — take the kit version, then re-apply project-specific values found
  in yours (stack config lines, added recipes, changed ports/paths). If yours and base are
  identical, there are no project edits — take the kit version outright.
- **Anything you cannot classify** — keep YOURS in place, leave the sidecar file on disk,
  and list it in the final report under "needs a human decision". This is the only permitted
  deferral, and it must be rare.

Invariants while merging: never delete or weaken a `### Audit Rule` or a `#EXPORT_CRITICAL`
line; never renumber existing sins entries; never edit anything under PRESERVE
(STATE.md, PRD, GLOSSARY, DATA_MODEL, ARCHITECTURE, logs, `src/`, `docs/adr/`).

## §4 — Regenerate, then prove it green

```bash
just sins-sync && just map-sync   # regenerate rules/ + index + repo map
just doctor                       # prove every configured gate can execute
just verify-all                   # the full gate suite
```

No `just`/toolchain on this machine? Run `mise install` first; if mise itself is absent and
cannot be installed, run the python gates directly (`python scripts/run_gate.py …` per the
justfile recipes) and say plainly in the report that doctor/verify ran degraded — never claim
green you didn't earn (AGENTS.md §2: a skipped gate checked nothing).

If verify-all is red: fix ONLY breakage the upgrade itself caused (a stale path in a doc, a
renamed recipe, a new gate's config). Pre-existing project failures are not yours to fix in
this branch — note them in the report. Upgrade-caused breakage gets the normal §6a ladder
(one failed fix → build the repro loop).

## §5 — Clean up and commit

1. Delete the staging dir (`.kit-incoming/`) and verify no `*.kit-incoming` sidecars remain
   (except any §3 "needs a human decision" deferrals).
2. Keep `.kit-backup-<stamp>/` (gitignored) — it's the rollback.
3. Commit the upgrade as its own commit(s) on the migration branch:
   `chore(kit): upgrade to <version> — <N> swapped, <M> merged, sins +<K>, verify-all green`.
   Do NOT merge the branch back to main yourself — leave it for the user (their one decision).
4. Append one `WorkLogAfterEachRun.md` entry and update `STATE.md`'s
   `last_session_summary`.

**Final report to the user (the whole output, keep it short):** version from → to; counts per
bucket; the semantic merges made (one line each); sins appended/skipped; doctor + verify-all
result (and anything degraded); any "needs a human decision" deferrals; rollback one-liner
(`git checkout -` + the backup dir name).

## §6 — The ONLY stop-and-ask conditions

Stop and ask the user only if: the backup step failed (never proceed unbacked); the project
dir and kit dir appear to be the same folder; a §3 merge would force deleting an
`#EXPORT_CRITICAL` constraint or an `### Audit Rule`; or verify-all stays red after the §6a
ladder is exhausted on an upgrade-caused failure. Everything else — dirty trees, missing
tools, unknown versions, drifted files — has a prescribed path above. Silence toward the user
until the final report is a feature, not negligence.
