# MIGRATION.md — get an existing project onto kit v6.6

> **One rule:** unpack the kit tar *somewhere outside your project* and point the
> tool *at* your project. Never extract the tar on top of an existing project —
> that is the only way to lose work, and every path below exists so you don't.
> (Exception: the `upgrade-kit` skill stages the new kit *as `.kit-incoming/`
> inside* the project — that dir is gitignored and is itself the staging area.)

**Fully automated (v6.6) — the default for agents:** drop/unpack the new kit anywhere in the
project (`.kit-incoming/` preferred), then tell your agent "upgrade the kit". The agent
follows **`migrate/UPGRADE_AUTOPILOT.md`** end to end — discovery, classification, backup,
branch, apply, deterministic sins merge, semantic merges by written rule, regenerate,
doctor + verify-all, commit, report — with zero questions unless a data-loss stop condition
fires. The paths below remain for running it by hand.

Three paths. Pick by looking at the folder you're upgrading:

| Your project today | Path | Tool | Overwrites your files? |
|---|---|---|---|
| **Already on v6.4 / v6.5** → v6.6 | **A — Upgrade** | `skills/upgrade-kit.md` (the agent ritual) | **Never** — stock infra swaps only after a hash match; merges staged as `.kit-incoming` |
| **On v4 / v5 / early-v6** → v6.6 | **B — Migrate** | `migrate/migrate_kit.py` (same engine, run by hand) | **Never** — stages everything as `.kit-incoming` for review |
| **Built without the kit** (any stack) | **C — Adopt** | `adopt/adopt_kit.py` | **Never** — only adds missing files |

Paths A and B are the *same engine* (`migrate_kit.py`) — the only difference is whether
a coding agent drives it (A, via the skill) or you drive it by hand (B). The migrator
classifies every file by hash against every shipped baseline (`v4_baseline.sha256`,
`v6.4_baseline.sha256`, …): stock prior-version files → safe OVERWRITE; everything you
edited → staged as `.kit-incoming` for judgment. There is no longer a manual `cp` loop.

Whichever path, you end on the same finish line: `just doctor` green →
`just verify-all` green. That pair is the proof the kit works on your machine.

---

## One-time prerequisite (install once, ever)

[`mise`](https://mise.jdx.dev) is the single gateway. It reads `.mise.toml` and
provisions `just`, `uv`, `node`, `pnpm`, and **`ast-grep`** at pinned versions, so
the agent never burns a turn installing toolchain.

```powershell
winget install jdx.mise      # Windows
# WSL / macOS / Linux:  curl https://mise.run | sh
```

No mise? Install the one v6.5+ prereq directly: `pip install ast-grep-cli`
(or `npm i -g @ast-grep/cli`). Everything else (`just`, `uv`, `pnpm`) you likely have.

---

## Path A — v6.4 / v6.5 → v6.6 (the upgrade skill)

**Run the `upgrade-kit` skill.** It stages the new kit as `.kit-incoming/` inside the
project, runs the migrator to classify every file by hash, auto-applies the safe
swaps, stages 2–4 files that need judgment as `.kit-incoming` sidecars for 3-way
merge, regenerates the index/repo map, and gates the whole upgrade on
`just verify-all`. The skill IS the procedure — there is no hand-maintained list of
"what changed this release" to keep in sync. From inside your project, with the new
kit tar in hand:

```
# hand this to your coding agent:
Read skills/upgrade-kit.md and run the upgrade ritual against
suds-vibe-coding-kit-v6.6.tar. Stop at step 6 and report the verify result.
```

Or, headless (no agent in the loop), the same engine runs by hand — see Path B.

**Why this replaced the old manual swap:** v6.6 is additive and prose-only vs v6.5
(and v6.5 was additive vs v6.4), so most stock files are byte-identical to the v6.4/v6.5
baselines shipped in `migrate/*_baseline.sha256`. The migrator detects the hash match and routes them
to OVERWRITE (auto-swap). Only 2–4 files genuinely need merge judgment
(`AGENTS.md`, `SinsGotchasLearnings.md`, `RepoMapReadFirst.md`,
`skills/grill-to-prd.md`). The skill computes which is which from hashes — never from
a hand-written list — so the merge surface is always exactly right.

Roll back with `git checkout -` + delete the `migrate-kit-*` branch, or restore from
the `.kit-backup-<stamp>/` folder the skill created.

---

## Path B — v4 / v5 / early-v6 → v6.6 (the migrator, by hand)

The migrator is the safest tool: it **backs up, branches, and overwrites nothing**.
It classifies every file (PRESERVE / OVERWRITE / ADD / MERGE / SKIP-DRIFTED /
RETIRE), auto-applies only the safe categories, and stages anything that needs
your judgment next to yours as `<file>.kit-incoming`.

```bash
# 1. unpack v6.6 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.6.tar -C /tmp/
KIT=/tmp/suds-vibe-coding-kit-v6.6

# 2. from INSIDE your project — see the plan (changes nothing):
python "$KIT/migrate/migrate_kit.py" --kit "$KIT" --project . --plan
#   Windows launcher (no -Apply = plan-only):
#   & "$KIT\migrate\migrate-kit.ps1" -Kit "$KIT"

# 3. apply — creates .kit-backup-<stamp>/ + a git branch, stages merges as .kit-incoming:
python "$KIT/migrate/migrate_kit.py" --kit "$KIT" --project . --apply --remove-retired
#   launcher:  & "$KIT\migrate\migrate-kit.ps1" -Kit "$KIT" -Apply -RemoveRetired
```

Read every line of the plan. Categories: **PRESERVE** (untouched),
**OVERWRITE** (safe bugfix — your copy is byte-identical to a stock prior version;
the note names which one, e.g. `stock v6.4`), **ADD** (new files),
**MERGE / SKIP-DRIFTED** (need you — staged as `.kit-incoming`), **RETIRE**
(superseded — `--remove-retired` deletes them). The plan also prints
`Detected stock-version matches: …` so you know what you're upgrading from.

**Resolve each `.kit-incoming`** — the only judgment part. Hand it to your agent:

> Read `migrate/MIGRATION.md`. Walk me through each `*.kit-incoming` file ONE AT A
> TIME: show the diff, tell me what the kit changed, recommend an action, apply
> only when I confirm.

The two that have tooling:

- **`SinsGotchasLearnings.md.kit-incoming`** — don't hand-merge. Run the helper:
  ```bash
  python "$KIT/migrate/merge_sins.py" \
      --mine SinsGotchasLearnings.md \
      --incoming SinsGotchasLearnings.md.kit-incoming
  ```
  Keeps your incidents first and verbatim, appends the kit's generic entries
  renumbered, skips duplicates. Then delete the `.kit-incoming`.
- **`RepoMapReadFirst.md.kit-incoming`** — do NOT take the kit's (it's an empty
  skeleton). Keep yours; delete the `.kit-incoming`; regenerate later.

The rest (`AGENTS.md`, `EXECUTION_PLAN.md`, `skills/grill-to-prd.md`, drifted
scripts/justfile/verify.ps1) — diff against yours, pull in the v6.5/v6.6 sections, keep
your project-specific content, delete the `.kit-incoming`.

**Finish** (provisions the toolchain, rebuilds generated files, proves green):

```bash
mise install                  # just/uv/node/pnpm/ast-grep
just sins-sync                # rebuild ast-grep rules + index from your taxonomy
just map-sync                 # rebuild RepoMapReadFirst.md
just doctor                   # v6.5: prove every gate can execute
just verify-all               # must be green before you keep the branch
```

**Keep or roll back:** merge the `migrate-kit-*` branch, or roll back with
`git checkout -` + delete the branch, or restore from `.kit-backup-*/`.

---

## Path C — adopt the kit into a project built without it

`adopt_kit.py` **only adds files you don't already have** — it cannot overwrite
your source, configs, or anything else present. It git-inits if needed, installs
the gate hooks, and generates the repo map + sins index from your real code. It
does NOT fill your contracts — those get reverse-engineered from your code (the
script prints the agent prompt for that).

```bash
# 1. unpack v6.6 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.6.tar -C /tmp/
KIT=/tmp/suds-vibe-coding-kit-v6.6

# 2. from INSIDE your project — dry-run (changes nothing):
python "$KIT/adopt/adopt_kit.py" --kit "$KIT" --plan
#   launcher:  & "$KIT\adopt\adopt-kit.ps1" -Kit "$KIT"

# 3. apply (adds missing kit files, installs hooks, generates the map):
python "$KIT/adopt/adopt_kit.py" --kit "$KIT" --apply
#   launcher:  & "$KIT\adopt\adopt-kit.ps1" -Kit "$KIT" -Apply

# 4. provision + the contract-backfill prompt it printed → paste into your agent
mise install
# 5. baseline the gates against your existing code:
just verify
just verify-all
```

For anything the audit legitimately flags but you've decided is OK, put
`# ast-grep-ignore` (Python/CSS) or `// ast-grep-ignore` (TS/JS) on the line above
with a reason in the commit — don't weaken the rule.

---

## The finish line (all three paths)

```bash
just doctor          # every configured gate can actually execute on THIS machine
just verify-all      # lint/typecheck/test/verify-libs/verify-schema/audit-sins/dox-check
                      # + check-tasks/check-prompt-log/smoke → all green
```

Green `just verify-all` after a green `just doctor` = you're on v6.6 and the gates
are trustworthy (not silently skipping). If `doctor` is red, fix what it reports
first — a green `verify` on top of a red `doctor` means a gate is lying about what
it checked.

**Reversibility:** every path leaves you a rollback — `git reset --hard pre-v6.6`
(Path A), the `migrate-kit-*` branch + `.kit-backup-*/` (Path B), or your manual
backup (Path C). Nothing here is one-way.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `just: command not found` | `just` not installed | `mise install` (or `winget install Casey.Just`) |
| `ast-grep: command not found` | the one v6.5+ prereq missing | `mise install`, or `pip install ast-grep-cli` |
| `doctor` red on a tool | that tool isn't on PATH but a stack is configured | install via `mise install`; doctor prints the exact fix |
| `audit-sins` skipped silently | ast-grep not on PATH | install it (see above); the gate will then run |
| `verify` red with `ERR_PNPM_NO_PKG_MANIFEST` on a `verify_*.ts` | JS stack not configured but a TS verify file exists | fixed in v6.5 (now skips cleanly); if you see it, your `run_gate.py` is pre-v6.5 — re-run Path A/B |
| `.kit-incoming` files left over | you didn't finish resolving them | walk them one at a time (Path B step "Resolve"); safe to delete once merged |
| migrator says "doesn't look like a kit folder" | `--kit` path has no `migrate/*_baseline.sha256` | point `--kit` at the unpacked kit root, not a subfolder |

## The one rule for the agent

Do not auto-resolve MERGE / `.kit-incoming` files. Do not overwrite anything
outside what the migrator's `--apply` already did. Your job is to diff, explain,
recommend, and apply only on the user's confirmation — one file at a time.
