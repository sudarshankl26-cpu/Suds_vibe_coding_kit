---
name: upgrade-kit
description: Move a project onto a newer kit version without hand-diffing — classify by hash, swap stock files, stage judgment merges. Use when a newer kit tar/folder is in hand; prefer migrate/UPGRADE_AUTOPILOT.md for the zero-steering version.
---

# Skill: upgrade-kit — move a project onto a newer kit version without hand-diffing

**Trigger:** run when the user says "upgrade to v6.6", "apply the new kit", "migrate to the
latest VibeCodingKit", or whenever a newer kit tar/folder is in hand and the project is on an
older one.

**v6.6 — prefer the autopilot.** The zero-steering version of this ritual is
**`migrate/UPGRADE_AUTOPILOT.md`** (in the NEW kit): stage the kit, run
`python .kit-incoming/migrate/migrate_kit.py --auto`, then follow its §3–§5. It subsumes
steps 1–6 below and adds automatic kit discovery, a dirty-tree WIP snapshot, and the
deterministic sins merge. Use this file's step-by-step form only when you want to walk the
upgrade manually or the autopilot hit a §6 stop condition. Also the skill behind `just upgrade-kit` (which is a dry-run preview — the actual
upgrade is this ritual). Takes one focused session; the semantic merges are the only part that
needs your judgment.

**Why this exists.** Every kit bump used to mean manually diffing ~30 changed files across two
trees and reconciling them by hand. That is exactly the work an agent in the loop is good at —
*if* the deterministic boundary (what's safe to swap vs. what needs judgment) is decided by code,
not by the model guessing. This ritual splits the upgrade along that line: the migrator
classifies every file by hash against shipped stock baselines, swaps the safe ones, and stages
the few that need judgment as `.kit-incoming` for you to merge. The model does the semantic part
(3-way content merge); the classifier guards correctness (PRESERVE is a hard rule, never
overridden). The result: a one-command upgrade whose only human-review surface is 2–4 files, not
30 — and the same ritual carries v6.5 → v6.6 → v7 with zero per-release doc maintenance.

## Before you start — preconditions

- A clean working tree (`git status` empty). The migrator branches for you, but it refuses to
  guess on top of uncommitted edits.
- The new kit, unpacked somewhere on disk. You will copy it *into* the project as
  `.kit-incoming/` (gitignored), so the migrator can be invoked with relative paths and the
  `.kit-incoming` sidecars land next to the files they update.
- `just`, `uv`, and `ast-grep` installed (the kit's `.mise.toml` provisions them via `mise
  install`). Step 6 runs `just verify-all`, which needs ast-grep for the `audit-sins` gate. If
  the toolchain isn't installed and the user can't install it, say so plainly and stop after
  step 5 — do not silently skip verification and call the upgrade done.

## The ritual, in order

### 1. Stage the new kit inside the project

Copy the unpacked kit folder to `.kit-incoming/` at the project root (create it; it's
gitignored). The migrator lives at `.kit-incoming/migrate/migrate_kit.py`. Keeping the kit
inside the project means every path the ritual references is relative and the `.kit-incoming`
sidecars it writes sit next to the files they update.

If you only have the tar, unpack it there:

```bash
mkdir -p .kit-incoming && tar -xf suds-vibe-coding-kit-v6.6.tar -C .kit-incoming --strip-components=1
```

(`--strip-components=1` flattens the `suds-vibe-coding-kit-v6.6/` top-level dir so
`.kit-incoming/AGENTS.md` is the path, not `.kit-incoming/suds-vibe-coding-kit-v6.6/AGENTS.md`.)

### 2. Read the plan — this is the only source of truth

```bash
python .kit-incoming/migrate/migrate_kit.py --kit .kit-incoming --project . --plan
```

**Do not maintain a hand-written list of "what changed this release."** The plan IS the diff,
computed fresh from hashes every time. The buckets:

| Bucket | What it means | Who acts |
|---|---|---|
| **OVERWRITE** | your copy is byte-identical to a stock prior version → safe to swap | migrator applies it |
| **ADD** | new in this kit, you don't have it | migrator applies it |
| **RETIRE** | superseded; removed only with `--remove-retired` | migrator, with consent |
| **MERGE / SKIP-DRIFTED** | needs judgment — staged as `<file>.kit-incoming` | **you, this step** |
| **GENERATED** | regenerated after migrate (`just sins-sync`, `just map-sync`) | you, step 5 |
| **PRESERVE** | your state — the migrator never touches it | nobody (verified, not acted on) |

The plan also prints `Detected stock-version matches: v6.4` (or similar) — that's the migrator
telling you what it's upgrading from. If it says nothing matched and everything is SKIP-DRIFTED,
the project's prior version has no shipped baseline; the merges still work, there are just more
of them.

### 3. Apply the deterministic part — branch, backup, swap, stage

```bash
python .kit-incoming/migrate/migrate_kit.py --kit .kit-incoming --project . --apply --remove-retired
```

This creates `.kit-backup-<UTCstamp>/` (full copies of everything touched, recoverable even
without git), branches to `migrate-kit-<stamp>` if it's a git repo, swaps OVERWRITE/ADD, and
stages each MERGE/SKIP-DRIFTED file as `<file>.kit-incoming`. **Never skip this step** — the
backup is your rollback, the branch is your review surface, and the `.kit-incoming` sidecars are
the inputs to step 4.

Verify the apply ran (not just `--plan`): the output should end with "Applied. Nothing of yours
was overwritten; merges are staged as .kit-incoming." If you see "(plan only — nothing
changed)", you forgot `--apply`; re-run.

### 4. The semantic merges — the only place your judgment is needed

For each file listed in MERGE or SKIP-DRIFTED (typically 2–4 files: `AGENTS.md`,
`SinsGotchasLearnings.md`, `RepoMapReadFirst.md`, occasionally `skills/grill-to-prd.md`), do a
**3-way merge** with the three copies now on disk:

| role | where it lives | meaning |
|---|---|---|
| **ancestor** (base) | `.kit-backup-<stamp>/<file>` | your pre-upgrade version — the common ground |
| **incoming** (theirs) | `<file>.kit-incoming` | the new kit's version — the deltas to fold in |
| **current** (yours) | `<file>` | your working copy, possibly with your own edits |

Read all three. Reason about intent, not line-by-line patching: the kit's changes are the
*meaningful* deltas (new sections, policy updates, reworded rules); your changes are
project-specific content the kit doesn't carry. Produce a merged `<file>` that keeps both.
Section anchors are stable across versions (`§0`, `§0a`, `§0b`, `§1a`, `§2`, `§3`, `§4b`, `§6a`,
`§7`, `§8` in AGENTS.md are the same strings release to release) — target the merge by section,
not by line number.

**Special cases:**

- **`AGENTS.md`** — the canonical merge. The kit's deltas land in named sections (the plan note
  for this file doesn't enumerate them; read the ancestor↔incoming diff to see exactly which
  sections changed). Apply each kit delta into your copy, preserving any project-specific
  additions (extra anti-patterns, stack-specific notes under §2's subheadings, custom §10
  hierarchy). Do not invent deltas the kit didn't make.

- **`SinsGotchasLearnings.md`** — this file is large and the kit rewrites it broadly (metadata
  blocks threaded through every entry, entries merged/renumbered). **Do not merge by hand.** Run
  the structural helper first — it appends the kit's generic entries after yours with fresh
  numbers (avoiding `## N.` collisions) and dedupes by title:

  ```bash
  python .kit-incoming/migrate/merge_sins.py \
      --mine SinsGotchasLearnings.md \
      --incoming SinsGotchasLearnings.md.kit-incoming \
      --out SinsGotchasLearnings.md
  ```

  Then reconcile the result by hand: keep all your project-specific incidents (they're already
  first, verbatim), adopt the kit's new `Scope:`/`Trigger:`/`Digest:`/`Recurrences:` metadata
  shape on entries you share, and drop nothing of yours. This is the one file where a second
  human pass is expected — say so to the user rather than claiming it's automatic.

- **`RepoMapReadFirst.md`** — you curated this; the kit ships a near-empty placeholder. Keep
  yours and regenerate in step 5 (`just map-sync`). Delete the `.kit-incoming` without merging.

**Leave every `.kit-incoming` in place** until the user (or you, in step 6) confirms the merge.
It is the review diff. Removing it early destroys the audit trail.

**Stop and ask on ambiguity** (PROMPTS.md principle #6): if a kit delta and your edit occupy the
same lines and you can't tell which intent wins, surface the conflict to the user with both
versions rather than silently picking.

### 5. Regenerate the generated files

```bash
just sins-sync && just map-sync
```

These rebuild `rules/*.sins.yml`, `rules/.sins-source.sha256`,
`SinsGotchasLearnings_INDEX.md`, and `RepoMapReadFirst.md` from the merged sources. The
GENERATED bucket in the plan listed these — they are never merged by hand.

### 6. Verify — the upgrade is not done until this is green

```bash
just doctor && just verify-all
```

`just doctor` first (proves every configured gate can actually run on this machine — no silent
false-greens, per the v6.5 policy in AGENTS.md §3). Then `just verify-all`. **Both must pass.**
This is where a bad merge surfaces: `dox-check` catches stale path references, `audit-sins`
catches a broken taxonomy, `check-tasks`/`check-prompt-log` catch bookkeeping drift.

If either is red: **stop, report which gate broke and the failing output, do not commit.** Fix
the merge (or the regeneration), re-run. A "successful upgrade" that leaves verify red is worse
than no upgrade — it hides a broken state behind a green-looking tree.

If the toolchain genuinely can't run (no `just`, no `ast-grep`, user can't install), say so
explicitly: "Applied steps 1–5, but I could not run `just verify-all` (missing `<tool>`).
Verification is left to you — do not consider this upgrade complete until it's green."

### 7. Clean up and commit

Once verify is green and the user has eyeballed the merges:

- Delete the `.kit-incoming` sidecars you resolved: `find . -name '*.kit-incoming' -delete`
- Remove the staging dir: `rm -rf .kit-incoming`
- Keep `.kit-backup-<stamp>/` until the user is confident (it's gitignored; they can delete it
  later). It's the out-of-git rollback if the branch needs abandoning.
- Commit on the `migrate-kit-<stamp>` branch:

  ```
  chore(kit): upgrade to v6.6 — swapped N infra, merged AGENTS.md + Sins, regen
  ```

  Then the user merges the branch at their pace.

## Invariants

- **PRESERVE is a hard rule.** STATE.md, PRD.md, GLOSSARY.md, DATA_MODEL.md, ARCHITECTURE.md,
  CONTEXT.md, logs, `src/`, `docs/`, `tests/`, `.git` — the migrator never touches these and
  neither do you during an upgrade. If a merge seems to require editing a PRESERVE file, the kit
  is doing something unexpected: stop and ask.
- **Never hand-diff to decide what's safe to overwrite.** That's the classifier's job, and it's
  exact (hash match against a shipped baseline). Your job is the semantic merges the classifier
  deliberately defers.
- **Never run `--apply` without a clean tree.** The backup + branch are the rollback; uncommitted
  edits defeat both.
- **Never delete a `.kit-incoming` before its merge is verified.** It's the review surface.
- **Never call the upgrade done with verify red.** Red verify = the upgrade isn't finished,
  regardless of how clean the apply looked.
- This ritual edits infrastructure + the named merge files only. It does not change `src/`,
  contracts, or any of the user's accumulated project state.
