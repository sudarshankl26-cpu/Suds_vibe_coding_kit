---
name: handoff
description: End a session or switch tools so the next agent resumes cold with zero loss — checklist for STATE.md, half-done work, unpromoted decisions, and open flags. Use when ending mid-task, switching tools, or past the context-hygiene limits (AGENTS.md §4b).
---

# Skill: handoff — leave the repo so the next agent resumes cold, losing nothing

Adapted from Matt Pocock's `handoff` (skills v1.1.0), rewired to this kit's files: the handoff
document IS `STATE.md` (+ the active `plans/` file) — never a chat summary, never a separate
scratch doc. **Trigger:** the session is ending mid-task; you're switching tools; or a §4b
context-hygiene limit is hit (2 phases done, or you catch yourself re-reading files /
re-deriving decisions). If you're ending exactly at a phase boundary and STATE.md is already
current, there's nothing to do — that's the ideal ending, not a skipped step.

**The test the handoff must pass:** a fresh agent, in a different tool, with ZERO chat
context, reads `CONTEXT.md` → `STATE.md` → the active `plans/` file and can continue within
two minutes — without asking the user anything the two of you already settled.

## The checklist (write, then verify each)

1. **The cursor** — `STATE.md` YAML: `current_phase`, `active_task`, `phase_started_at`,
   `blocked`/`blocker` all true right now, not as of an hour ago.
2. **Half-done work, named exactly.** In `last_session_summary` or the plan file: which files
   are mid-edit and what remains in each ("`src/db/refunds.ts`: schema done, the
   partial-refund branch is unwritten"). A next agent must never have to diff to discover
   what's unfinished.
3. **Unpromoted decisions** → `STATE.md` `open_decisions`: anything settled in conversation
   this session that is NOT yet in a contract file. This is the leakiest spot in any handoff
   — the decision that lives only in the transcript is a decision that will be re-made,
   differently.
4. **Open flags swept** — grep the touched files for `#PLAN_UNCERTAINTY` / `#EXPORT_CRITICAL`
   added this session; list unresolved ones in the plan file's Flags line so they're findable
   without re-reading the diff.
5. **The next command** — end `next_action` with something executable, not a vibe: "run
   `just verify`, then implement phase 3 step 2 (write the failing tests for X)".
6. **Green or honestly red.** Leave `just verify-all` green (§8). If you genuinely can't,
   record the exact failing gate + error in `blocker` — a documented red beats a fake green.
7. **No secrets, no transcript dumps.** The handoff carries state and decisions, never pasted
   conversation, tokens, or credentials.

Then commit (`STATE.md` rides with the phase commit per §5, or as `chore: handoff` if
mid-phase) — an uncommitted handoff doesn't exist for the next tool.
