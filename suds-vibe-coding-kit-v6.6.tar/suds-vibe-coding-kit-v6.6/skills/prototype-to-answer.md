---
name: prototype-to-answer
description: Throwaway prototype that answers a design question — logic → tiny TUI around a pure liftable module; UI → 3 structurally different variants behind ?variant=. Use when a grill/plan question is undecidable on paper; delete the code, keep the answer.
---

# Skill: prototype-to-answer — throwaway code that answers a design question

Adapted from Matt Pocock's `prototype` (skills v1.1.0), condensed. Use when a **grill or plan
question can only be answered by running code** — "would this state machine handle
cancellation mid-fulfilment?", "which of these three layouts works?" — instead of debating it
in prose or burying it as a `#PLAN_UNCERTAINTY` that never resolves. The question decides the
shape.

**Ground rules (all shapes)**

- **Throwaway from day one**, clearly marked (`prototypes/` or an obviously-named route),
  never imported by real code, one command to run, no persistence (state IS what's being
  checked), no polish, no tests.
- Surface the **full state** after every action, so the user can see what the design does.
- When answered: **the answer is the only deliverable.** Capture it where it belongs (the PRD
  decision, an ADR, a `#PATH_DECISION`, the plan file), then delete the prototype — or
  deliberately absorb its logic module (below) into the real codebase. A lingering prototype
  is future confusion.

**Shape A — logic/state question → tiny terminal app.** Clear-and-redraw loop: each tick
prints the pretty-printed state, then single-key actions (`[a] add item … [q] quit`). The one
structural rule: **isolate the logic in a pure, portable module** (reducer / state machine /
pure functions) with the TUI as a thin shell — the shell is throwaway; the logic module is
what gets lifted into the real app if the design wins.

**Shape B — UI question → structurally different variants on one route.** Build ~3 (max 5)
**genuinely different** structures — three tweaked card grids is wallpaper, not a prototype.
Prefer embedding variants in the real page they'd live in (a variant on its own blank route is
a vacuum — everything looks fine in isolation), gated by `?variant=`, with a small floating
switcher (←/→ cycles, URL-persisted, excluded from production builds). The feedback you're
fishing for is "the header from B with the sidebar from C." Variants still follow
`DESIGN_GUIDELINES.md` — comparing three flavors of slop answers nothing.

**Graduating a winner (the one step the "throwaway" framing can obscure).** A prototype
that wins is still throwaway code — built with no tests, no polish (above). Promote it by
**rebuilding it as real code**, not by `git add`-ing the prototype as-is:

- **Shape A (logic module):** the pure reducer / state machine / functions were *designed* to
  lift out. Move that module into the real codebase, then write its evals — if it's the kind of
  hard unit a Shape A prototype usually is (branchy logic, a state machine, validation),
  §4a eval-first applies now that it's real code. The TUI shell is discarded; only the tested
  module is kept. The "no tests" prototype rule was a speed trade-off for throwaway code — it
  ends the moment the code stops being throwaway.
- **Shape B (UI variant):** there is nothing to lift — variants live behind `?variant=`
  *excluded from production builds*. Rebuild the winning structure (or the "header from B +
  sidebar from C" composite) as the real page's production code, then delete the `?variant=`
  scaffold and switcher. It goes through §3 / `just verify` like any UI change.

In both cases the transition is a **new commit on the real branch**, not a rescue of the
prototype commit. If the prototype was never committed (the default), there's nothing to
cherry-pick — rebuild from the recorded answer.

**Fit with the kit:** the grill (`skills/grill-to-prd.md`) may detour here when a branch of
the design tree is genuinely undecidable on paper; §4b plans may include a prototype phase to
kill a risky `#PLAN_UNCERTAINTY` early. Prototypes are exempt from the §3 gates by
construction (never committed / never imported); the moment code stops being throwaway, it
stops being a prototype and everything in AGENTS.md applies (the graduation step above is
where that transition is paid for).
