---
name: deep-modules
description: Design vocabulary for deep modules — interface/seam/adapter/leverage/locality, the deletion test, dependency categories for test strategy, design-it-twice. Use when creating a new module, planning a refactor, or when tests keep coupling to internals.
---

# Skill: deep-modules — design vocabulary + the deletion test

Adapted from Matt Pocock's `codebase-design` / `DEEPENING` / `DESIGN-IT-TWICE` (skills
v1.1.0), condensed. **On-demand**: read this when creating a new module, when a refactor is on
the table, or when tests keep coupling to internals. Agents accelerate entropy — code gets
complex faster than a human codebase ever did — so design attention is not optional polish;
it's what keeps week 3 as fast as day 1.

## The vocabulary (use these words exactly)

- **Module** — any unit behind an interface: a function, class, file, package. Scale-agnostic.
- **Interface** — everything a caller must know to use the module correctly: signature AND
  invariants, error modes, performance characteristics. Not just the type.
- **Deep module** — a lot of behavior behind a small interface. Depth is a property of the
  *interface*, not a lines-of-code ratio (that rewards padding).
- **Seam** — a place where two modules meet and one could be substituted (Feathers). Internal
  seams (between your modules) vs external seams (against the world).
- **Adapter** — a module whose role is translating across a seam. **One adapter means a
  hypothetical seam; two adapters means a real one** — don't build abstraction layers for
  substitutions that will never happen.
- **Leverage** — what callers gain per unit of interface they must learn. **Locality** — what
  maintainers gain: fix it once, it's fixed everywhere.

## Judging a module: the deletion test

Imagine deleting the module. Does its complexity **vanish** (callers barely change — the
module was shallow, pure indirection) or **reappear smeared across N callers** (the module was
deep — it was genuinely absorbing complexity)? Extracted-for-testability pure functions with
one caller usually fail this test; so do "manager"/"util" pass-throughs.

## Testing follows the seam (dependency categories)

- **In-process** dependency (your own module) → don't mock it; test through the composed
  interface. If you feel forced to mock it, the seam is misplaced.
- **Local-substitutable** (DB, filesystem) → substitute a real lightweight instance
  (SQLite/PGLite, temp dir, in-memory FS) — not a mock.
- **Remote but owned** (your own service) → ports & adapters: real adapter in prod, in-memory
  adapter in tests.
- **True external** (third-party API, time, randomness) → this is the ONE place mocks belong
  (AGENTS.md §2 Testing).

**The interface is the test surface.** When a deepening refactor lands, write the tests
against the new interface and DELETE the old implementation-coupled unit tests — replace,
don't layer.

## Design it twice (threshold: 3+ expected callers, or an ADR-worthy trade-off)

This is the COSTLY ceremony in this skill — reserve it for interfaces that many callers will
live with, or where a real trade-off exists (if all three ADR tests would pass, it qualifies).
For everything else: one sketch, a one-line `#PATH_DECISION` if there was a real choice, move
on. When it does apply: sketch **at least two genuinely different designs**
under different constraints — e.g. (a) minimal interface, 1–3 entry points; (b) optimized for
the most common caller; (c) ports-and-adapters. Where the tool has subagents, fan the sketches
out in parallel, one constraint each; otherwise sketch them yourself sequentially. For each:
the interface, one usage example, what's hidden, trade-offs. Compare on depth, locality, and
seam placement — then **be opinionated**: recommend one (grafting the best ideas from the
others), don't present a menu. The chosen design's "why this over the obvious alternative" is
a `#PATH_DECISION` or, if all three ADR tests pass, an ADR (AGENTS.md §1a).

## When to reach for this actively

- A new module/route/component is about to be created (after the §2 reuse-first check).
- The same change keeps touching many files (shotgun surgery) — a seam is missing.
- Tests keep breaking on refactors — tests are on the wrong side of an interface.
- Periodically on a living codebase: scan for shallow modules and seam leaks, apply the
  deletion test, and propose the top 1–3 deepening candidates with before/after sketches —
  as candidates for the user to pick from, not unilateral rewrites.
