---
name: code-review
description: Two-axis phase-end review — Standards (repo rules + smell baseline) and Spec (acceptance criteria, scope creep) as parallel subagents, reported separately. Use before a phase's final commit; skip when ≤2 non-test files changed.
---

# Skill: code-review — two independent axes, reported separately

Adapted from Matt Pocock's `code-review` (skills v1.1.0), rewired for this kit's file-based
contracts. Run at **phase end** (AGENTS.md §5), before the phase's final commit — or on demand
("review this diff"). Skip when the phase changed ≤2 non-test files, or docs/styles/config
only (the AGENTS.md §0a router's condition — same rule, one phrase); a vertical slice (§4b)
keeps the diff small enough that this is cheap.

**Why two axes.** A change can be beautifully written and implement the wrong thing, or
faithfully implement the spec in code that violates every repo rule. One combined review lets
the loud axis mask the quiet one. So: two independent reviews, **never merged or reranked**.

## 0. Fix the diff

Review `git diff <fixed-point>...HEAD` (three-dot). The fixed point is `phase_started_at` in
`STATE.md`'s YAML block (recorded when the phase began). If it's null/missing, fall back to
the last commit before this phase's first commit — and set `phase_started_at` going forward.
Validate the ref exists and the diff is non-empty before doing anything else.

## 1. Standards axis — "does it follow how WE write code?"

Sources of truth, in order: `AGENTS.md` §2/§7 (anti-patterns + conventions), the sins
★ALWAYS block + trigger map for touched areas, `DESIGN_GUIDELINES.md` if UI changed — plus an
always-on **smell baseline** (Fowler): mysterious name, duplicated code, feature envy, data
clumps, primitive obsession, repeated switches, shotgun surgery, divergent change, speculative
generality, message chains, middle man. Two binding rules: **the repo overrides the baseline**,
and **every smell is a judgment call** — name it, quote the hunk, suggest the fix; don't
auto-refactor. Skip anything a gate already enforces (`just verify` covers lint/types/sins —
trust it, per §3).

## 2. Spec axis — "does it do what the phase promised?"

The spec is the phase's acceptance criteria in the `plans/` file or `EXECUTION_PLAN.md`, plus
any `#EXPORT_CRITICAL` constraints in scope. Check: missing or partially-implemented
requirements; **scope creep** (changes nothing asked for); implementations that look wrong
against the contract files (PRD/GLOSSARY/DATA_MODEL). Quote the spec line for each finding.
If no written spec exists for the diff, say "no spec available — Spec axis skipped" rather
than inventing one.

## 3. Run and report

Where the tool has subagents, run both axes as **parallel subagents** (one message, two
tasks), each with only its own brief — the isolation is the point; keep each report under
~400 words, findings cited to file+hunk. No subagents → run the two passes sequentially
yourself, Standards first. Report under two headings, `## Standards` and `## Spec`, findings
kept separate. Fix what's real, then commit. A finding that reveals a repeated failure class
goes through the sins ratchet (AGENTS.md §0a), not just a local fix.
