---
name: diagnose-bugs
description: "Feedback-loop debugging for hard bugs: build a red-capable one-command repro, minimise, ranked falsifiable hypotheses, tagged instrumentation, regression test at a correct seam. Use after ONE failed fix attempt when the symptom persists."
---

# Skill: diagnose-bugs — a feedback loop is the diagnosis; everything else is mechanical

Adapted from Matt Pocock's `diagnosing-bugs` (skills v1.1.0), condensed to kit shape.
**Trigger — crisp, no judgment needed: one fix attempt failed and the symptom persists →
run this skill before attempt 2.** Also for any performance regression, and any bug you can't
reproduce on demand. This is AGENTS.md §6a rung 0 in full. It does NOT apply to a first
attempt at an ordinary failing test — read the error, fix, re-run; don't ceremonialize trivia.

## Phase 1 — build the feedback loop (THE skill; everything after is mechanical)

**Zero-cost shortcut first: if a failing test (or the `just verify` output) already
demonstrates the exact symptom, that IS your loop — Phase 1 is done, build nothing, and move
to Phase 2 with that command.** Only when no existing command shows the symptom do you build
one.

Produce **one command** that demonstrates the bug. It must be:

- **Red-capable** — it asserts the user's exact symptom and FAILS while the bug exists.
- **Deterministic** — same result every run. For flaky bugs, first raise the reproduction
  rate: loop it 100×, run in parallel, add load, inject sleeps at suspected race points —
  until "fails ~always" or "fails N/100" is stable enough to trust.
- **Fast** — seconds, not minutes. A 2-second deterministic loop is a debugging superpower.
- **Agent-runnable** — you can invoke it yourself, repeatedly, without the user.

Ways to build one, roughly in order of preference: a failing test; a curl/httpie script; a CLI
invocation against a fixture with a diffed expected output; a headless-browser (Playwright)
script; replaying a captured trace/HAR; a throwaway harness script; a property/fuzz loop; a
bisection harness (`git bisect run <cmd>`); a differential old-vs-new comparison. Last resort,
when only the user can observe the symptom: a human-in-the-loop script
(`skills/templates/hitl-loop.sh.template`) that prints numbered steps and captures the user's
observations as `KEY=VALUE` answers you can parse.

**Completion criterion:** the command exists, you have RUN it at least once, and you can paste
the invocation + failing output. **No red-capable command → no Phase 2.** If no loop can be
built with what you have, say so and ask for what's missing (env access, a HAR, logs,
permission to instrument) — that request IS the correct output, not a guess.

## Phase 2 — minimise

Shrink the repro until **every remaining element is load-bearing**: fewer steps, less data,
fewer moving parts. Each removal that keeps the bug red teaches you something; the minimal
repro often names the culprit by itself.

## Phase 3 — hypothesize (ranked and falsifiable)

Write **3–5 hypotheses**, ranked by likelihood, each in the falsifiable form:
*"If \<X\> is the cause, then \<changing Y\> will make the bug disappear."*
Show the list to the user (don't block on a reply), then test them top-down — one variable at
a time, re-running the loop after each change. A hypothesis you can't phrase this way isn't a
hypothesis; it's a vibe.

## Phase 4 — instrument

Debugger first if available; else **targeted** logs at the points the current hypothesis
predicts — never "log everything and grep". Tag every debug line with one unique prefix, e.g.
`[DEBUG-4f2a]`, so cleanup is a single grep. For perf regressions: measure the baseline number
first, then bisect (git history or code path) toward the regression.

## Phase 5 — fix + regression test

Write the regression test **before** the fix, at a **correct seam** (the public interface —
AGENTS.md §4a; never a test coupled to the internals you're about to change). If no correct
seam exists for the test, *that is itself a finding* — note it as a design problem
(`skills/deep-modules.md`) rather than forcing a bad test.

## Phase 6 — close out (checklist)

- [ ] Original repro command now green; regression test in `tests/` and green.
- [ ] `grep -r "DEBUG-" …` returns nothing; throwaway harnesses deleted.
- [ ] Commit message states the **confirmed** hypothesis (the actual cause, not the symptom).
- [ ] `SinsGotchasLearnings.md`: new prose entry — or `Recurrences:` bump + ratchet if the
      failure class already exists (AGENTS.md §0a). Ask: what would have *prevented* this bug
      (a type? a gate? a deeper module)? Promote accordingly.
