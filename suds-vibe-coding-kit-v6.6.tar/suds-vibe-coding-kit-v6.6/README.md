# Sud's Vibe Coding Kit

<img src="https://img.shields.io/badge/version-v6.6-1b2430?style=flat-square" alt="version">
<img src="https://img.shields.io/badge/philosophy-suggestions%20%3E%20gates-3b5bdb?style=flat-square" alt="philosophy">
<img src="https://img.shields.io/badge/runtime%20deps-none-2b8a6e?style=flat-square" alt="no runtime deps">
<img src="https://img.shields.io/badge/platform-Windows%2011%20%2B%20WSL-444?style=flat-square" alt="platform">
<img src="https://img.shields.io/badge/macOS%20%2F%20Linux-via%20one%20prompt-7b8494?style=flat-square" alt="mac/linux">
<img src="https://img.shields.io/badge/tested%20with-GLM%20%C2%B7%20DeepSeek%20%C2%B7%20MiMo%20%C2%B7%20MiniMax-7950f2?style=flat-square" alt="tested models">

> **A small set of files you drop into a project _before_ you write code, so AI coding agents
> stop drifting — without spending their budget proving they followed a process.**

A set of project artifacts that prevents the mistakes LLM coding agents make, **and** an
enforcement layer that makes the prevention automatic instead of hopeful. Built for a
multi-tool workflow (Claude Code, Kilo/VSCodium, Zed, OpenCode, Windsurf, Antigravity,
Stagewise, Qoder, Hermes, and others) on Windows 11 + WSL.

**You never "run" the kit; your agent reads it.** Your job is to lay the files down once,
then talk to your agent normally.

---

## Table of contents

- [The 30-second pitch](#the-30-second-pitch)
- [The workflow](#the-workflow)
- [The daily loop](#the-daily-loop)
- [What's in the kit](#whats-in-the-kit)
- [The Sins & Gotchas system](#the-sins--gotchas-system)
- [Why it works](#why-it-works)
- [Quick start (new project)](#quick-start-new-project)
- [Upgrading an existing project](#upgrading-an-existing-project)
- [When to skip files](#when-to-skip-files)
- [Supported tools & models](#supported-tools--models)
- [What's new in v6.6](#whats-new-in-v66)
- [What's new in v6.5](#whats-new-in-v65)
- [Version history](#version-history)

---

## The 30-second pitch

An AI coding agent has **no memory between sessions**, so left alone it *drifts*: it reinvents
your types, forgets yesterday's decisions, quietly redefines your domain words, and announces
"done" without ever running the code. **You can't prompt this away — the forgetting is
structural.** So the kit does the one thing that works:

```mermaid
flowchart LR
  A["AI agent<br/>(no memory between sessions)"] -->|left alone| B["drifts:<br/>reinvents types · forgets decisions<br/>redefines terms · 'done' without running"]
  C["Ground truth on disk<br/>PRD · GLOSSARY · DATA_MODEL · AGENTS.md"] -->|re-read every session| D["builds the right thing"]
  E["just verify / verify-all<br/>(only checks with an objective answer)"] -->|fails the build on regressions| D
```

> **The design rule that keeps it lean:** *gate the product, not the process.* Check things
> with an objective truth (does it compile? does the API exist? does the app boot?). Never
> gate the agent's own bookkeeping — that was the v6 failure mode, where the agent spent ~80%
> of its reasoning proving it had followed the kit. v6.1 removed it; everything since stays
> prose-and-suggestions over enforcement.

---

## The workflow

This is the exact loop the kit is built around. Follow it every time:

```mermaid
flowchart TD
  subgraph P1["Phase 1 — one-time setup · just you · ~5 min · no AI yet"]
    s1["Install mise (once, ever)"] --> s2["Folder = project, extract the kit into it"] --> s3["Double-click scaffold.ps1"]
  end
  subgraph P2["Phase 2 — open your AI agent"]
    f1["First message:<br/>define scope + run grill-to-prd"] --> f2["Agent writes PRD.md + contracts"] --> f3["Builds phase by phase, gated by just verify"]
  end
  s3 --> f1
```

### Phase 1 — one-time setup (Windows)

Don't overthink these; they only put the files in place and nothing here can harm your machine.

```bash
# 1. Install the one prerequisite — once, ever, on your computer:
winget install jdx.mise          # (it quietly installs just/uv/node/pnpm + ast-grep for you)

# 2. Make a folder, name it your project, and extract the kit INTO it (no sub-folder).
#    This folder IS your app.

# 3. Double-click scaffold.ps1   (WSL: bash scaffold.sh)
#    → sets up the toolchain, git, and the safety gates, makes the first commit,
#      and prints your first prompt. Safe to run twice.
```

### Phase 2 — open your AI agent (the first message matters)

Open your coding agent in the folder. **Don't start with "build me a …".** Your first message
defines the **scope** and runs the *grill* — it interviews you one question at a time and turns
your answers into a spec (`PRD.md`), so the agent builds the *right* thing instead of guessing.
**This is the step people skip.**

```text
Read CONTEXT.md and the files it lists. Then run the grill-to-prd skill
(skills/grill-to-prd.md): interview me ONE question at a time, recommending an
answer for each, until the scope is fully clear. Do NOT write code or scaffold
yet. Then write PRD.md and we'll build phase by phase.
```

> Skip the grill and the agent invents the requirements — the #1 way it builds the wrong
> thing. Five minutes of questions here saves hours of rework.

---

## The daily loop

| When you're… | Paste this |
|---|---|
| **Continuing where you left off** | `Read RepoMapReadFirst.md and STATE.md, tell me where we are in two sentences, then continue.` |
| **Adding a feature** | `I want to add <feature>. Update PRD.md / EXECUTION_PLAN.md for it first (separate commit), then build it phase by phase per AGENTS.md.` |
| **Planning a big/complex change** | `This is a large task. Follow AGENTS.md §4b: write a dated plan in plans/, keep phases small, show me the plan, then execute phase by phase.` |
| **Switching to a different AI tool** | `Read CONTEXT.md and the files it lists, then continue from STATE.md, following AGENTS.md.` |
| **Building any UI (avoid "AI slop")** | See `PROMPTS.md` §Q — encodes `DESIGN_GUIDELINES.md` into the build prompt. |
| **After fixing a bug** | `Add it to SinsGotchasLearnings.md as a prose entry (an ast-grep rule only if it's a clean structural pattern).` |

**Commands you'll actually type:**

| Command | What it does |
|---|---|
| `just verify` | Fast **code** gates (lint, types, tests, library checks, schema, sins audit, dox). Run freely. |
| `just verify-all` | Everything in `verify` + tasks + prompt-log + app smoke. Pre-commit / CI. |
| `just doctor` | **v6.5** — harness self-test: every configured gate can actually execute. Run after scaffold / on a new machine. |
| `just sins-triage` | **v6.5** — learning-loop health: promotion candidates, missing triggers, digest budget. |
| `just audit-sins` | ast-grep scan of the taxonomy's rules (self-heals if stale). |
| `just map-sync` | Regenerate RepoMapReadFirst.md (keeps your curated notes). |
| `just state` | Print the current build cursor from STATE.md. |

---

## What's in the kit

| Group | Files | Job |
|---|---|---|
| **Contracts** (ground truth) | `PRD.md` · `GLOSSARY.md` · `DATA_MODEL.md` · `ARCHITECTURE.md` · `DESIGN_GUIDELINES.md` · `types/` | What the app does, every term, the data grain & units, the architecture, the visual standard. |
| **Governance** (how the agent works) | `AGENTS.md` (single source of truth) · `CONTEXT.md` · `EXECUTION_PLAN.md` · `STATE.md` · `MODEL_NOTES.md` · `PROMPTS.md` | Rules, routing, the phased plan, the live cursor, per-model tips, the reusable prompt library. |
| **Memory & gates** (enforced only where objective) | `RepoMapReadFirst.md` · `SinsGotchasLearnings.md` + `rules/*.sins.yml` · `SinsArchive.md` · `OpenTasksMustCompleteAll.md` · `UserPromptLog.md` · `WorkLogAfterEachRun.md` · `justfile` | The repo map, the defect taxonomy (some compiled to ast-grep rules), the sins archive, the anti-drop checklist, passive prompt log, work log, and the gates. |

Every other tool-config file (`CLAUDE.md`, `GEMINI.md`, `.cursor/`, `.kilocode/`,
`.windsurfrules`, `.zed/`, `.rules`, `.codex/`) is a **three-line pointer** back to
`AGENTS.md`, so rules can't drift.

### Order of authoring (unchanged, still matters)

1. `PRD.md` → 2. `GLOSSARY.md` → 3. `DATA_MODEL.md` → 4. `ARCHITECTURE.md` →
5. `AGENTS.md` → 6. `EXECUTION_PLAN.md`. Files 1–4 are *what's built*; 5–6 are *how the
agent builds*. `SinsGotchasLearnings.md` grows during the build, not before it.

---

## The Sins & Gotchas system

Most hard-won lessons are *deterministic checks* trapped in prose. This kit splits them by
enforceability — **push every lesson to the most automatic layer it can reach:**

```mermaid
flowchart LR
  P["Prose<br/>(a doc the agent might skip)"] -->|promote| R["ast-grep rule<br/>(a gate that fails the build)"]
  R -->|promote| T["type / constructor<br/>(the compiler enforces it)"]
  T -->|strongest| H["hook<br/>(fires without the model's cooperation)"]
```

- **Tier 1 — Executable (ast-grep).** A `SinsGotchasLearnings.md` entry may carry an
  `### Audit Rule` (an ast-grep YAML pattern). `just audit-sins` compiles them to
  `rules/*.sins.yml` and runs `ast-grep scan` on every commit — AST-based, so it handles
  multiline/CSS/structural patterns that line-grep never could, and never matches its own
  comment. Rules are **optional**: add one only when the defect is genuinely structural.
- **Tier 2 — Loadable index.** `build_sins_index.py` collapses the full file to
  `SinsGotchasLearnings_INDEX.md`: a **★ALWAYS block** (project digest extending AGENTS §0b),
  a **trigger map** (about to touch `fetch` / `useEffect` / `src/db/**`? → read these §s),
  and enforced entries collapsed out of the read path. Agents read the index at session start
  and open full entries only on demand.
- **Tier 3 — Reconciliation.** `PROMPTS.md` §H and §K force the docs to update themselves
  after each phase / bug, so they don't ossify into stale "lore."

**The recurrence ratchet (v6.5):** a repeat is never re-documented — increment `Recurrences:`,
and at 2+ promotion up the ladder (type → ast-grep rule → test → digest) is mandatory. Run
`just sins-triage` periodically to surface what needs promoting.

---

## Why it works

- **It externalizes the memory the agent doesn't have** — files named so the filename itself
  signals the purpose (`OpenTasksMustCompleteAll`, `RepoMapReadFirst`, `SinsGotchasLearnings`).
- **It converts the few objectively-checkable rules into gates** — a rule in a doc is a
  suggestion; the same rule as a `just verify` check is a wall; a hook that runs whether or
  not the model cooperates is the strongest layer.
- **It uses a real parser for code checks** — ast-grep audits honor the kit's own rule
  ("parse structured text with a real parser").
- **It makes the right thing the cheap thing** — re-orienting from `RepoMapReadFirst.md` is
  ~2k tokens instead of a 50k re-walk; trusting a green gate beats re-checking by hand.

**Naming is part of the prompt.** Evocative, purpose-revealing filenames steer behavior
better than bland ones. Ecosystem-standard names (AGENTS.md, PRD, GLOSSARY) are left alone —
tools match them literally.

---

## Quick start (new project)

```powershell
# 1. make a folder, name it your project, extract the kit files into it (no sub-folder)
# 2. bootstrap (double-click, or):
powershell -ExecutionPolicy Bypass -File .\scaffold.ps1      # Windows
# bash scaffold.sh                                            # WSL / Claude Code
# 3. open your agent in this folder and paste the grill prompt it printed
# 4. just verify       # mid-work: lint + types + tests + library checks + ast-grep sins audit
# 5. just verify-all   # before committing: + task gate + prompt-log + app smoke (pre-commit runs this)
# 6. just doctor       # v6.5: prove every configured gate can actually execute on THIS machine
```

<details>
<summary><b>macOS / Linux — one prompt to adapt the kit</b></summary>

The kit is authored Windows-first (it ships `scaffold.sh` for WSL/Unix already). To adapt the
rest for macOS or Linux, paste this into your agent **after extracting the kit**:

```text
I'm on macOS/Linux. Adapt this kit for my platform WITHOUT changing its rules or philosophy:
1. Use scaffold.sh (not the .ps1). Install the one prerequisite with `curl https://mise.run | sh`
   (macOS alternative: `brew install mise`).
2. When the final phase generates server-control scripts, generate POSIX start-server.sh /
   stop-server.sh (kill-by-port via lsof or fuser) instead of the PowerShell .ps1 templates —
   still reading PORT from .env, never hardcoded.
3. Keep just, uv, pnpm, ast-grep, the justfile, and ALL gates exactly as they are — they're
   already cross-platform via mise.
4. Leave AGENTS.md and every contract file unchanged.
Show me a summary of what you changed.
```

</details>

---

## Upgrading an existing project

Three paths, depending on the folder you're pointing at:

| Your situation | Path | Script | Overwrites your files? |
|---|---|---|---|
| **Empty folder → new project** | scaffold | `scaffold.ps1` / `scaffold.sh` | n/a (fresh) |
| **Existing project built WITHOUT the kit** | adopt | `adopt/adopt_kit.py` | **Never** — only adds missing files |
| **v4 / v5 / early-v6 kit project → v6.6** | migrate | `migrate/migrate_kit.py` | **Never** — stages everything for review |
| **Any kit version → v6.6, hands-off** | **autopilot** | drop kit in `.kit-incoming/`, agent runs `migrate/UPGRADE_AUTOPILOT.md` | **Never** — backup + branch + WIP snapshot first; merges by written rule |
| **v6.4 / v6.5 project → v6.6, by hand** | upgrade skill | `skills/upgrade-kit.md` + `migrate/MIGRATION.md` Path A | **Never** — hash-matched stock swaps; merges staged for review |

Full copy-paste PowerShell walkthroughs for adopt and migrate: **`ADOPT_AND_UPGRADE.md`**.

---

## When to skip files

- **Throwaway script (<200 lines):** `PRD.md` + `AGENTS.md`.
- **Prototype with state:** add `GLOSSARY.md` + `DATA_MODEL.md`.
- `SinsGotchasLearnings.md` only earns its keep once the project is long-lived enough to hit
  repeat bugs. The gates no-op cleanly when their files are absent.

---

## Supported tools & models

### Coding agents (tested)

| Tool | Platform | Config file |
|---|---|---|
| OpenCode Desktop | Windows | `.opencode/` |
| Kilocode (VSCodium extension) | Windows | `.kilocode/` |
| Zed | Windows/WSL | `.zed/` |
| Antigravity | Windows | `GEMINI.md` |
| OpenAI Codex CLI | Win/WSL/macOS | `.codex/` (reads AGENTS.md) |
| Hermes Agent Desktop | Windows | (reads AGENTS.md) |
| Stagewise | Windows | (reads AGENTS.md) |
| Qoder | Windows | (reads AGENTS.md) |
| Claude Code | WSL/macOS | `.claude/` |
| Windsurf/Devin | Windows | `.windsurfrules` |
| Cursor | Windows | `.cursor/rules/` |

### LLM models (tested with the kit)

- **GLM 5.2** · **DeepSeek V4 Pro** · **Xiaomi MiMo 2.5 Pro** · **MiniMax M3** · Claude · Gemini 2.5 Flash

All rules live in `AGENTS.md` — any tool that reads it works. The per-tool files are zero-rule
pointers, so they can't drift from the source of truth. For non-frontier / open-weight models,
see **`MODEL_NOTES.md`** for context-budget, reasoning-effort, and subagent-delegation tips.

> **Concurrent multi-agent use is not supported.** STATE.md is the baton between tools used
> *one at a time*. Running two top-level agents against the same checkout simultaneously will
> corrupt shared state (prompt-log append races, STATE.md last-write-wins, git index lock
> contention). For parallelism, use the §4b subagent firewall from a single orchestrator.

---

## What's new in v6.6

v6.6 is **prose-only** — no new gates, scripts, or per-turn ceremony. It distills the durable
engineering discipline from **Matt Pocock's `skills` library (v1.1.0)** into kit shape,
keeping only what fits a solo, file-contract, gate-the-product workflow:

1. **Test quality has rules now (`AGENTS.md` §2 "Testing specific", §4a).** Four new
   anti-patterns — implementation-coupled tests, tautological tests (expected values must come
   from an independent source), mocking your own modules (mock only true externals; real test
   DB over a mocked data layer), and horizontal test slicing. §4a eval-first now starts by
   **agreeing the seams** ("the interface is the test surface") and runs red→green in vertical
   slices.
2. **Feedback-loop debugging (`skills/diagnose-bugs.md`, §6a rung 0, §0b.14).** For hard
   bugs: build a **red-capable, deterministic, fast, one-command repro** before any hypothesis
   ("no repro command, no Phase 2"), minimise it until every element is load-bearing, then work
   3–5 ranked falsifiable hypotheses with `[DEBUG-<id>]`-tagged instrumentation and finish with
   a regression test at a correct seam. Ships `skills/templates/hitl-loop.sh.template` for
   bugs only the user can observe.
3. **Vertical-slice phasing + expand→contract (§4b, §0b.17).** Each phase is a **tracer
   bullet** — a narrow but complete, demoable path through every layer — never "all models,
   then all routes". Wide mechanical refactors are the exception: **expand → migrate in green
   batches → contract**. Plus a **context-hygiene rule**: hand off via STATE.md before quality
   degrades — observable rules: phase-boundary handoffs, ≤2 completed phases per session; never compact mid-phase.
4. **Two-axis phase-end review (`skills/code-review.md`, §5).** Before a phase's final
   commit: a **Standards** review (repo rules + a Fowler-smell baseline, skipping what gates
   already enforce) and a **Spec** review (acceptance criteria, quoted per finding, scope creep
   flagged) — as parallel subagents where possible, reported separately so one axis can't mask
   the other.
5. **Deep-module design vocabulary (`skills/deep-modules.md`, §2).** Module / interface /
   seam / adapter / leverage / locality, the **deletion test** for shallow modules, "one
   adapter is a hypothetical seam; two is a real one", dependency categories that decide test
   strategy, and **design-it-twice** for non-trivial interfaces.
6. **Handoff as a discipline (`skills/handoff.md`).** The checklist behind the §4b
   context-hygiene rule: cursor current, half-done work named exactly, unpromoted decisions
   into `open_decisions`, flags swept, an executable `next_action`, green-or-honestly-red —
   then committed, because an uncommitted handoff doesn't exist for the next tool.
7. **Zero-steering kit upgrades (`migrate/UPGRADE_AUTOPILOT.md`, `migrate_kit.py --auto`).**
   Drop a newer kit into `.kit-incoming/`, say "upgrade the kit": discovery, backup, branch,
   WIP snapshot, apply, deterministic sins merge, rule-based semantic merges, verify, commit,
   report — zero questions unless a data-loss stop condition fires.
8. **Prototype-to-answer (`skills/prototype-to-answer.md`).** When the grill or a plan hits a
   question paper can't settle, build a throwaway prototype (logic → tiny TUI with the logic
   in a pure liftable module; UI → 3 structurally different variants behind `?variant=`),
   record the **answer**, delete the code. The grill also now records **rejected approaches**
   with reasons, so future sessions don't re-suggest them.

**Rejected, deliberately:** the library's issue-tracker state machine (`triage`), the
`wayfinder` ticket-map machinery, per-tracker label mappings, teach/writing skills, and the
skill-router — team/tracker process weight this kit's file contracts already cover or that
v6.1 removed on purpose. Its `grilling`/`domain-modeling` core was already in the kit as
`skills/grill-to-prd.md`; v6.6 upgrades that with the prototype detour.

---

## What's new in v6.5

v6.5 attacks the three failure modes observed across real builds — **gates that silently
no-op'd, descriptive files that decayed into fiction, and a sins file that documented mistakes
without preventing repeats** — and stays true to v6.1's "gate the product, not the process."

1. **No silent false-greens (`run_gate.py`, `just doctor`).** A gate whose stack is configured
   but whose tool is missing now **FAILS loudly** (exit 3, with the exact setup command)
   instead of printing "skipping" and passing. The JS package manager is **detected from the
   lockfile** (pnpm/npm/yarn/bun — never assumed). New **`just doctor`** self-tests the
   harness so a green `verify` is *earned*.
2. **Docs that can't rot silently (`dox-check`).** Contract docs are scanned for backticked
   repo paths: wholesale rot (≥3 missing and >30%) is a hard failure; `RepoMapReadFirst.md`
   additionally fails on leftover `[fill in]` placeholders once the repo has real source.
3. **The learning loop gets a motor.** Entries carry retrieval metadata
   (`Scope:`/`Trigger:`/`Enforced:`/`Digest:`/`Recurrences:`), the index has a **★ALWAYS
   block** + **trigger map** + enforced entries collapsed out of the read path, and the
   **recurrence ratchet** (a repeat is never re-documented — increment and promote). New
   `just sins-triage` reports loop health.
4. **Subagent economics (§4b).** A **context firewall** (subagents write to gitignored
   `.scratch/<task>/`, return path + 3-line summary + confidence — never raw dumps),
   **handoff packets**, and a stakes/reversibility/ambiguity floor for routing slices.
5. **CRLF-immune gates on Windows.** Every gate normalizes `\r\n` → `\n` on read, so a
   Windows editor that saves CRLF can no longer silently break the `\n`-anchored regexes.

All piggyback on existing gates — **no new per-turn ceremony.**

---

## Version history

<details>
<summary><b>v6.4 — inline flags, reuse-first, anti-AI-slop design standard, friendlier on-ramp</b></summary>

All prose-only — no new gates, no new machinery:

- **§1a inline flags** (`#EXPORT_CRITICAL` / `#PLAN_UNCERTAINTY` / `#PATH_DECISION`) threaded
  through the templates, grill, and §H/§I prompts.
- **§2 reuse-before-reinvent** anti-pattern.
- Built-in **`DESIGN_GUIDELINES.md`** so any UI looks *decided*, not AI-generated (one icon
  set, a neutral base + one accent, a real type hierarchy — copy-paste build prompt in
  `PROMPTS.md` §Q).
- Beginner **"Start here"** onboarding, OpenAI **Codex** support (`.codex/`).

</details>

<details>
<summary><b>v6.3 — tuned for 1M-context open-weight models + phased planning</b></summary>

All suggestions, no new gates:

- **§4b planning protocol** — for long/complex work, write a dated plan file
  (`plans/<slug>-YYYY-MM-DD.md`), phase it to **~300k tokens/phase**, and delegate independent
  slices to **subagents** (Explore → Plan → Execute) where the tool supports it.
- New **`MODEL_NOTES.md`** with per-model operating tips (context budget, reasoning-effort
  tiers) for GLM 5.2 / DeepSeek V4 Pro / MiniMax M3 / MiMo 2.5 Pro.
- **English/UTF-8 output rule** (§7); refined **§6a** ladder that **encourages web search /
  Context7 proactively** to beat the model's knowledge cutoff.
- Prune-defaults nudge (delete inapplicable shipped sins early, keeping the session-start
  index short and the prefix cacheable).

</details>

<details>
<summary><b>v6.2 — eval-first for hard parts + anti-thrash ladder</b></summary>

Two suggestions (not gates) added to `AGENTS.md`, both true to v6.1's "gate the product, not
the process":

- **§4a eval-first** — for genuinely hard units (complex logic, edge cases, validation,
  parsers, money/units math), write the edge-case tests *first*, then implement until
  `just verify` is green (the existing `test` gate does the enforcing — no new gate).
- **§6a escalation ladder** — after ~3 failed attempts on the same test/error, stop guessing
  and autonomously consult whatever's available (LSP/type diagnostics, Context7 MCP, web
  search, a `verify_<lib>` probe).

</details>

<details>
<summary><b>v6.1 — "the overhead is gone"</b></summary>

v6 was correct in spirit but its enforcement layer made the agent spend ~80% of its reasoning
*proving it followed the process* (timestamp whack-a-mole, regex rabbit holes, self-
referential gates). v6.1 keeps every safeguard's intent and removes the make-work:

- **AST audits instead of grep (ast-grep).** The defect taxonomy compiles to `ast-grep` rules
  (`rules/*.sins.yml`), not single-line grep. Multiline, structural, language-aware (incl.
  CSS), and can't match its own comment. Pinned via `mise` (native Windows binary).
- **`just verify` splits in two.** `verify` = code/correctness gates only (stays green while
  you build); `verify-all` = + bookkeeping gates + app smoke (pre-commit / CI).
- **Logs are passive evidence.** Prompt capture is timezone-aware and filters tool-echoes /
  file dumps. The agent never edits the log or re-stamps timestamps.
- **No STALE AUDIT loop.** `audit-sins` self-heals — it regenerates the rules when the
  taxonomy changes.
- **Learnings up front.** `AGENTS.md` §0b carries an always-on digest of the highest-leverage
  failure modes.
- **Run & observe the app.** A portable Playwright `smoke` gate + template replaces the v6
  habit of deferring every GUI check as "[~] can't verify".

</details>

<details>
<summary><b>v3–v6 (foundations)</b></summary>

- **v3** — single cross-platform audit runner; per-line escape hatch; runtime data-contract
  guard (`verification/audit_schema.py` + `types/schema_rules.json`); optional CI workflow.
- **v4** — alignment / anti-drop / traceability / re-orientation: `RepoMapReadFirst.md`,
  `OpenTasksMustCompleteAll.md` + `check-tasks`, `UserPromptLog.md` + `WorkLogAfterEachRun.md`,
  and the `grill-to-prd` interview.
- **v5** — in-place scaffold (no sub-folder); one-prerequisite toolchain via `mise`; shipped
  ~24 debranded default learnings; port-as-a-contract (`.env` `PORT`); generated start/stop
  server scripts; portable justfile + PowerShell fallback; rebranded to *Sud's Vibe Coding Kit*.
- **v6** — deterministic verbatim prompt capture via tool hooks; the closed learning loop; the
  77-entry debranded defect taxonomy; tool pointers for Kilo/Antigravity/Zed. *Its enforcement
  layer became over-heavy — corrected in v6.1.*

</details>

---

<p align="center"><sub>Plain files + two commands. No GitHub, no service, no runtime dependency required.</sub></p>
