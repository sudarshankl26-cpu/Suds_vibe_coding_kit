# STATE.md

Agent-owned build state. This is the **first file read at session start** (AGENTS.md §0) and
the **handoff mechanism between tools**. Keep it accurate. It is *not* a contract file — you
may and should edit it. The block below is the machine-readable part; keep it valid YAML.

```yaml
current_phase: 0
phase_started_at: null   # commit SHA at phase start — the fixed point for skills/code-review.md
active_task: "0.1"
completed_phases: []
blocked: false
blocker: null            # if blocked: true, a one-line description of what's needed
last_session_summary: "Repo initialized from kit. Nothing built yet."
open_decisions: []       # decisions made that aren't yet reflected in a contract file
next_action: "Run setup, fill PRD.md, then start Phase 0 of EXECUTION_PLAN.md."
```

---

## How to use this file

- **Reading (session start):** parse the YAML. `current_phase` + `active_task` tell you where
  to resume without re-reading the whole plan. If `blocked: true`, resolve `blocker` first.
- **Writing (on progress):** when you complete a task or phase, or get blocked, update the
  YAML *in the same commit* as the work it describes. This is the one mutable-by-agent file.
- **`phase_started_at`:** set it to `git rev-parse HEAD` when a phase begins. The phase-end
  review (`skills/code-review.md`) diffs `phase_started_at...HEAD` — without it you'd guess
  the fixed point.
- **`open_decisions`:** a holding pen for choices you've made that still need to be promoted
  into a real contract file (GLOSSARY/DATA_MODEL/etc). When you promote one, remove it here.
  This prevents silent drift — decisions are visible until they're formalized.

## What does NOT go here

- Rules → AGENTS.md
- Domain terms → GLOSSARY.md
- Schema → DATA_MODEL.md / types/
- The plan itself → EXECUTION_PLAN.md

This file only answers "where are we right now and what's next."
