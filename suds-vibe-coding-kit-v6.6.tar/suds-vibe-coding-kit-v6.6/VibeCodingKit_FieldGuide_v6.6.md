# Sud's Vibe Coding Kit — Field Guide (v6.6)

*Concepts, the problems they solve, why they work, and how to run it.*
For solo, multi-tool development (Claude Code, Kilo/VSCodium, Zed, OpenCode, Windsurf,
Antigravity, Hermes, and others) on Windows 11 + WSL.

> **What this is.** A small set of files you drop into a project before you write code. Each
> file closes one specific way AI coding agents go wrong — drifting from requirements,
> inventing APIs, dropping tasks, forgetting structure, repeating a fixed bug. The kit is not
> a framework and adds no runtime dependency; it is plain Markdown plus a handful of
> Python/JS scripts wired to two commands: `just verify` and `just verify-all`.


---

## Start here — the soul of the kit, and how to actually use it

**If you read nothing else, read this.** An AI coding agent has no memory between sessions.
Left alone it drifts: it reinvents your types, forgets yesterday's decisions, quietly redefines
your domain words, and announces "done" without ever running the code. You cannot prompt this
away — the forgetting is structural. So the kit does the one thing that works: it writes the
ground truth to **plain files on disk** that the agent re-reads every session, and — wherever a
check has an objective answer — lets a single command fail the build. You never "run" the kit;
**your agent reads it.** Your job is to lay the files down once, then talk to your agent normally.

**It works in two phases, and beginners only stumble on the boundary between them.**

*Phase 1 — a one-time setup you do yourself, before opening any AI tool (~5 minutes, no terminal
wizardry).* Install `mise` once on your machine (`winget install jdx.mise`, or
`curl https://mise.run | sh` on WSL); make a folder named for your project; extract the kit into
it (**no sub-folder** — that folder IS your app); then double-click `scaffold.ps1` (WSL:
`bash scaffold.sh`). That's the whole setup. These steps only put the files in place and wire up
the safety gates — you don't need to understand them, nothing here can harm your computer, and
you still haven't needed the AI.

*Phase 2 — open your AI coding agent in the folder. The first message is the one people skip.*
Do **not** start with "build me a …". Your first message defines the **scope** and runs the
*grill* interview, which asks you one sharp question at a time and turns your answers into a spec
(`PRD.md`) so the agent builds the *right* thing. Paste this:

> Read CONTEXT.md and the files it lists. Then run the grill-to-prd skill
> (`skills/grill-to-prd.md`): interview me ONE question at a time, recommending an answer for
> each, until the scope is fully clear. Do NOT write code or scaffold yet. Then write PRD.md and
> we'll build phase by phase.

Skip the grill and the agent invents the requirements — the single most common way it builds the
wrong thing. Five minutes of questions here saves hours of rework.

**After that, day to day, you only need a handful of prompts** (the full library is `PROMPTS.md`):

- **Continue where you left off:** "Read RepoMapReadFirst.md and STATE.md, tell me where we are
  in two sentences, then continue."
- **Add a feature:** "I want to add <feature>. Update PRD.md / EXECUTION_PLAN.md for it first (as
  a separate commit), then build it phase by phase per AGENTS.md."
- **Switch to a different AI tool:** "Read CONTEXT.md and the files it lists, then continue from
  STATE.md, following AGENTS.md." (Any tool that reads AGENTS.md works.)
- **After a bug is fixed:** "Add it to SinsGotchasLearnings.md as a prose entry (an ast-grep rule
  only if it's a clean structural pattern)."
- **A bug survived a fix attempt:** "This bug survived a fix. Follow `skills/diagnose-bugs.md`:
  build a one-command repro first (an existing failing test counts), then ranked hypotheses."
- **Upgrade the kit later (v6.6 — zero steering):** unpack the new kit into `.kit-incoming/` in
  your project and tell your agent: "Upgrade the kit — read
  `.kit-incoming/migrate/UPGRADE_AUTOPILOT.md` and execute it end to end." It backs up,
  branches, snapshots dirty work, applies, merges by written rule, verifies, commits, and
  reports — asking you nothing unless a data-loss stop condition fires.

The rest of this guide explains *why* each piece exists. You don't need it to start — it's what
makes the kit make sense once you do.

---

## What's new in v6.6 — engineering discipline, distilled from a real skills library

**The soul of v6.6, in one paragraph.** Every kit version until now hardened the *scaffolding*
around the work — contracts against drift (v4–v6), gates that can't lie (v6.5), a learning
loop with a motor (v6.5). v6.6 is the first version that shapes **the work itself**: it gives
every unit of engineering one through-line and a dispatcher. The through-line: a question the
grill can't settle becomes a *throwaway prototype* instead of a buried assumption → the plan
is cut into **vertical tracer bullets** (each phase demoable end-to-end, never "all models,
then all routes") → a hard unit is built *eval-first at an agreed seam* ("the interface is the
test surface" — the one phrase that connects testing, debugging, review, and design here) →
the moment one fix attempt fails, the agent stops guessing and builds a **red-capable
one-command repro loop** → the phase closes with a **two-axis review** (standards and spec,
never merged, so neither masks the other) → what was learned enters the sins ratchet → the
session hands off clean at a phase boundary through STATE.md. The dispatcher is the **ceremony
router** (AGENTS.md §0a): one table that says which discipline a situation gets, what it
costs, and — as binding as the trigger — when to SKIP it. That last column is the v6.6
insurance against the v6.0 disease: quality machinery is only allowed to fire where its
expected value exceeds its cost, and `sins-triage` step 7 audits the machinery's own weight
over time. Around all of this sits the new **upgrade autopilot**: future kit versions install
themselves with zero steering (drop the folder in, say "upgrade the kit").

v6.6 is **prose-only** (no new gates, no per-turn ceremony). Source material: **Matt Pocock's
`skills` library v1.1.0** — the same library whose `grill-with-docs` seeded this kit's grill.
Six teachings were incorporated and made kit-native; the process-heavy rest was deliberately
rejected. The pieces in detail:

1. **Test-quality rules (`AGENTS.md` §2 "Testing specific" + §4a).** What makes a test worth
   keeping: never implementation-coupled (test observable behavior through the public
   interface — **the interface is the test surface**), never tautological (expected values
   from an independent source, not recomputed the code's way), mock **only** true externals
   (APIs, time, randomness — a real test DB beats a mocked data layer), and never horizontal
   slicing (all-tests-first verifies imagined behavior). §4a eval-first now begins by
   **agreeing the test seams**, then runs red→green one vertical slice at a time.
2. **Feedback-loop debugging (`skills/diagnose-bugs.md`; §6a rung 0; digest #14).** The
   discipline for hard bugs: FIRST build a **red-capable, deterministic, fast, one-command
   repro** — "no repro command, no hypotheses" — minimise it until every element is
   load-bearing, then test 3–5 *ranked, falsifiable* hypotheses ("if X, changing Y makes it
   disappear") with `[DEBUG-<id>]`-tagged logs (cleanup is one grep), and close with a
   regression test at a correct seam + the confirmed cause in the commit message. A
   human-in-the-loop repro script template ships for bugs only the user can see.
3. **Vertical slices + expand→contract (§4b; digest #17).** Every phase is a **tracer
   bullet**: a narrow, complete, demoable path through all layers. The one exception — wide
   mechanical refactors — sequences as expand → migrate (green batches) → contract. And a
   **context-hygiene rule**: reasoning degrades well before the window fills, and a model
   can't measure its own token use — so the rule is observable: hand off through STATE.md at
   phase boundaries, at most ~2 completed phases per session, never compact mid-phase.
4. **Two-axis phase-end review (`skills/code-review.md`; §5).** Standards (repo rules +
   Fowler-smell baseline; skip what `just verify` already gates) and Spec (acceptance
   criteria quoted per finding; scope creep flagged), run as parallel subagents where
   available and **reported separately** — one review merged is one axis masked.
5. **Deep modules (`skills/deep-modules.md`; §2).** A precise design vocabulary (module,
   interface, seam, adapter, leverage, locality), the **deletion test** for shallow
   indirection, "one adapter = hypothetical seam, two = real", dependency categories that
   decide test strategy, and **design-it-twice** (sketch ≥2 genuinely different interfaces,
   then recommend one) for any non-trivial module.
6. **Handoff as a discipline (`skills/handoff.md`).** §4b's context-hygiene rule ("hand off
   at phase boundaries") now has a checklist behind it: cursor current, half-done work named
   file by file, decisions settled in chat promoted to `open_decisions`, flags swept, an
   executable `next_action`, verify green or the red documented — committed, so it exists for
   the next tool. The test: a cold agent resumes within two minutes without asking anything
   already settled.
7. **Zero-steering upgrades (`migrate/UPGRADE_AUTOPILOT.md` + `migrate_kit.py --auto`).**
   Your two actions: drop the new kit in, read the report. Everything between — discovery,
   backup, branch, dirty-tree snapshot, hash-classified apply, deterministic sins merge,
   rule-based semantic merges, doctor + verify-all, commit — runs unattended, with four
   data-loss stop conditions as the only permitted interruptions.
8. **Prototype-to-answer (`skills/prototype-to-answer.md`; grill detour).** A design question
   paper can't settle gets a throwaway prototype — logic questions as a tiny TUI around a
   pure, liftable module; UI questions as ~3 structurally different variants behind
   `?variant=` in the real page. The answer is the deliverable; the code is deleted. The
   grill also records **rejected approaches with reasons** so they aren't re-proposed later.

**Rejected** (as important as what was kept): the issue-tracker triage state machine, the
`wayfinder` shared ticket-map, label mappings, the teach/writing/wizard skills, and the skill
router — tracker- and team-process weight that the kit's file contracts already cover, or
exactly the ceremony v6.1 removed. The library's meta-lesson on skill-writing (leading words,
positive phrasing over prohibitions, pruning no-ops) was applied to the new prose itself.

Digest cost: one rewritten item (#14, the debug ladder) + one new (#17, vertical slices) — the attention budget stays ≤20 with headroom.

---

## What's new in v6.5 — trustworthy gates, docs that can't rot silently, and a learning loop with a motor

v6.5 attacks the three failure modes observed across real builds: gates that silently
no-op'd, descriptive files that decayed into fiction, and a sins file that documented
mistakes without preventing repeats.

1. **No silent false-greens (`run_gate.py`, `just doctor`).** The root cause of a real
   all-gates-skip incident: the runner hardcoded `pnpm`, the project used npm, and every
   gate printed "skipping" and passed. Now the JS package manager is **detected from the
   lockfile** (pnpm/npm/yarn/bun), launchers resolve through `shutil.which` (fixing the
   Windows `.cmd` blindness), and a **configured stack whose tool is missing FAILS** (exit 3,
   with the exact fix command) instead of skipping — `KIT_GATES_LENIENT=1` demotes that to a
   warning for deliberately bare machines. Every gate ends with an accounting line
   (`ran / unconfigured / MISSING`). New **`just doctor`** self-tests the harness — proof
   that every configured gate can actually execute — so a green `verify` is *earned*. Run it
   after scaffold and on any new machine.
2. **Docs that can't rot silently (`dox-check` 5–6).** The descriptive files "didn't work"
   because nothing failed when they stopped matching the code — and an agent that catches one
   stale doc rationally discounts all of them. `dox-check` (already in `just verify`) now
   scans contract docs for backticked repo paths: wholesale rot (≥3 missing and >30%) is a
   hard failure; a few missing paths are informational (mark planned ones
   `<!-- planned -->`). `RepoMapReadFirst.md` additionally fails on leftover `[fill in]`
   placeholders once the repo has real source. §3 gains completion criterion #4: the
   descriptive files still describe reality (`just map-sync` + contract reconciliation).
3. **The learning loop gets a motor (metadata, trigger map, recurrence ratchet,
   `sins-triage`).** A model doesn't learn by writing an entry — an entry only prevents a
   repeat if it's in context at the moment the risky code is written, or enforced by a gate.
   So entries now carry retrieval metadata (`Scope:` / `Trigger:` / `Enforced:` /
   `Digest:` / `Recurrences:`), and the generated index is organized for retrieval at the
   point of action: a **★ALWAYS block** (project digest extending AGENTS §0b, ~20-item
   attention budget), a **trigger map** (about to touch `fetch` / `useEffect` / `src/db/**`?
   → read exactly these §s), and **⚙ enforced entries collapsed out of the read path**
   (trust the gate). The **recurrence ratchet** is the key rule: a repeat is never
   re-documented — increment `Recurrences:`, and at 2+ promotion up the enforcement ladder
   (type → ast-grep rule → regression test → digest) is mandatory. `just sins-triage`
   reports loop health; `skills/sins-triage.md` is the periodic consolidation ritual
   (merge → generalize → promote → collapse). The shipped taxonomy now carries metadata and
   a ★ALWAYS default set out of the box.
4. **Subagent economics (§4b).** Borrowed from a premium-model orchestration harness and
   made tool-agnostic: the **context firewall** (subagents write to gitignored
   `.scratch/<task>/`, return path + 3-line summary + confidence — never raw dumps into the
   orchestrator's context), **handoff packets** (delegated prompts written for zero chat
   context, with scope, output location, verification command, stop conditions), and a
   **stakes / reversibility / ambiguity floor** for routing slices across model tiers
   (detail in `MODEL_NOTES.md`).

Nothing here adds per-turn ceremony: the doctor and triage commands are on-demand, the doc
checks piggyback on the existing `dox-check` gate, and the metadata lines are five short
fields written once per learning. Prompt: `PROMPTS.md` §R (triage ritual).

---

## What's new in v6.4 — inline flags, reuse-first, a design standard, and an easier on-ramp

v6.4 is **prose-only**: no new gates, and no new machinery the agent has to satisfy. Two ideas are
borrowed from a heavyweight team harness (a SAFe-style multi-agent workflow) and kept solo-lean;
one is a new built-in standard; the rest is a friendlier on-ramp.

1. **Inline flags (`AGENTS.md` §1a).** Three text tags written where the thing lives, so the
   agent's reasoning survives between sessions and tools (§8): `#EXPORT_CRITICAL` (a
   non-negotiable constraint — never silently weaken; touching it is a §6 stop-and-ask),
   `#PLAN_UNCERTAINTY` (an assumption made to keep moving — resolved before a phase is "done"),
   and `#PATH_DECISION` (a one-line "why this over the obvious alternative", too small for an
   ADR). Threaded through the PRD / EXECUTION_PLAN / `plans/` templates, the grill, and the §H
   reconciliation + §I drift-audit prompts. Kept rare and real, the way ADRs are. Prompt:
   `PROMPTS.md` §P.
2. **Reuse before reinvent (`AGENTS.md` §2).** One tech-agnostic anti-pattern: before building a
   new route / component / module / query, check `RepoMapReadFirst.md` and grep for an existing
   equivalent, and match its shape — reuse first, create only when nothing fits. It's the
   portable core of "search first, reuse always" with no pattern library to ship.
3. **A built-in anti-"AI-slop" design standard (`DESIGN_GUIDELINES.md`).** When the project
   renders a UI, the agent follows one default visual standard instead of emitting the model's
   tells (emoji-as-icons, saturated colors, mismatched icon sets, gratuitous glassmorphism): one
   icon set at one stroke width, a neutral base + a single muted accent, one type family, and
   structure from whitespace + 1px borders. The principle is *intentional and consistent beats
   default-generated* — a design language defined in the PRD always wins (tag it `#EXPORT_CRITICAL`).
   Wired into §2, the grill, the plan/phase verification, and a copy-paste build prompt
   (`PROMPTS.md` §Q). Pure contract + suggestions; nothing gated.

Plus a much friendlier **on-ramp for beginners**: this guide now opens with a plain-language
"Start here" (the soul, the two-phase setup, and the can't-miss first prompt — define scope and
run the grill); the infographic gains a matching beginner section and an "everyday scenarios"
prompt grid; OpenAI **Codex** is an explicit supported tool (`.codex/`, reads AGENTS.md natively);
and there's a graphical **`GITHUB_README.md`** for publishing the kit.

What was **rejected** matters as much as what was kept: the source harness's 11 role-agents,
exit-state handoff gates, and stack-coupled CI/deploy ceremony — all the process-enforcement
weight v6.1 removed. A manifest-driven upgrade tool was prototyped too, then **cut to stay
prose-only**: the existing migrator already preserves your work, so a new config file wasn't worth
the surface area.

---

## What's new in v6.3 — tuned for 1M-context open-weight models

The kit is increasingly driven by 1M-context, reasoning-effort-tiered, agentic open-weight
models (GLM 5.2, DeepSeek V4 Pro, MiniMax M3, MiMo 2.5 Pro). v6.3 tunes the kit to how that
class of model actually performs best. As always: **suggestions, not gates** — nothing here adds
enforcement overhead.

1. **Phased planning for long/complex work (`AGENTS.md` §4b).** A big window is not a license to
   pour a whole large task into one runaway session — recall, cost, and prompt-cache hit rate all
   degrade as a trajectory bloats. So: for anything large (>3 files, a refactor, >~300k expected
   tokens), write a **dated working plan** `plans/<slug>-YYYY-MM-DD.md` (template in
   `skills/templates/plan.md.template`), phase it so **each phase's execution stays within ~300k
   tokens**, and execute phase by phase (commit + `just verify` each). Distinct from
   `EXECUTION_PLAN.md` (whole-project plan) and `STATE.md` (live cursor).
2. **Subagent delegation (Explore → Plan → Execute).** These models use subagents well. Where the
   tool supports them, an explore (read-only) subagent maps files, the plan step scopes phases,
   and independent slices fan out in parallel when a phase touches ~10+ files or has 3+
   independent pieces. Dependent work stays single-session. Ties into §6a — a stuck subagent
   escalates rather than thrashes.
3. **`MODEL_NOTES.md` (new, on-demand).** Per-model operating tips — context budget, **reasoning-
   effort tiers** (use Max/high for planning and §4a hard units; lower for routine), sampling,
   stable-prefix caching. Kept separate from `AGENTS.md` so the always-read rules stay lean and
   cacheable.
4. **English / UTF-8 output rule (`AGENTS.md` §7).** All code, comments, identifiers, commits and
   docs in English (or the project's language) regardless of the model's strongest language.
5. **Refined §6a escalation ladder + web search encouraged.** The always-available rungs (read
   diagnostics; run a `verify_<lib>` probe / minimal repro) come first so *every* tool has a
   baseline — but **web search and Context7 are actively encouraged, not a last resort**. Because
   the model's training has a cutoff, §4 and §6a now push it to search *proactively* for current
   dependency versions, recent API/breaking changes, and fresh error messages.
6. **Prune-defaults nudge.** Stronger guidance to delete inapplicable shipped sins early, keeping
   the session-start index short and the prefix cacheable — most valuable on a tight budget.

Reusable prompts: `PROMPTS.md` §N (plan a long task) and §O (delegate a phase to subagents).

---

## What's new in v6.2 — eval-first for hard parts, and an anti-thrash ladder

v6.2 adds two **suggestions** (not gates) to `AGENTS.md`. Both follow v6.1's rule — *gate the
product, not the agent's process* — so they steer behavior without adding the bookkeeping v6.1
removed. There is no new script, no marker convention, and no new gate; the existing
`just verify` test gate does all the enforcing.

1. **Eval-first for hard parts (`AGENTS.md` §4a).** Some units are simply harder to build *and*
   to evaluate — complex/branchy logic, edge-case handling, input/data validation, parsers,
   money/units/date math — and that's where bugs ship quietly. For those (and only those —
   trivial code is exempt), the agent enumerates the edge cases, writes them as **failing tests
   first**, then implements until green. The grill marks such capabilities *risk-flagged* and
   `EXECUTION_PLAN.md`'s phase template carries the check. Quality rises exactly where it's
   hardest, and the existing `test` gate proves the evals pass — nothing self-referential added.
2. **Anti-thrash escalation ladder (`AGENTS.md` §6a).** When the same test/error survives ~3
   fix attempts, the agent stops guessing and **autonomously** consults whatever's available —
   LSP/type diagnostics, Context7 MCP for real library docs, web search for the exact error, or
   a `verify_<lib>` probe — using whichever the current tool has. It does *not* interrupt you;
   that's distinct from §6 "stop and ask," which is still reserved for ambiguous *requirements*.

Upgrading from v6.1 is trivial: it's purely a refresh of `AGENTS.md` (plus a few prompt/plan
notes). No infrastructure changed — no script, hook, or toolchain edits.

Reusable prompts for both live in `PROMPTS.md` §L (eval-first) and §M (escalate when stuck).

---

## What's new in v6.1 — the overhead is gone

v6 made two promises real (verbatim prompt capture via hooks; a closed learning loop) — but
its *enforcement* layer became the problem. Observed on a real build: the agent took ~4× longer
and spent roughly **80% of its reasoning proving it had followed the kit**, not doing the work
— timestamp re-stamping, regex rabbit holes, and chasing self-referential gates.

v6.1 keeps every safeguard's intent and removes the make-work:

1. **AST audits, not grep.** The defect taxonomy compiles to **ast-grep** rules
   (`rules/*.sins.yml`) instead of single-line grep. ast-grep matches the *syntax tree*, so
   rules are multiline, structural, language-aware (including **CSS**), and **cannot match
   their own explanatory comment** — the exact trap that caused 15-minute regex detours. One
   native cross-platform binary (pinned via `mise`); the v6 dual `audit_sins.{sh,py}` codegen
   is deleted. Rules are **optional** — most learnings stay as prose.
2. **`just verify` splits in two.** `just verify` runs only the code/correctness gates (lint,
   types, tests, library checks, schema, sins audit, dox) and **stays green while you build**,
   so you can run it as a sanity check and trust the result. `just verify-all` adds the
   bookkeeping gates and an app smoke test, and is what the pre-commit hook and CI run.
3. **Logs are passive evidence.** Prompt capture is timezone-aware and only records *genuine
   prompts* — tool-call echoes and pasted file dumps are filtered out (v6 logged 200-line file
   reads as "prompts"). The agent never edits the log or re-stamps a timestamp; a cross-tool
   out-of-order timestamp is a harmless note, not a build failure.
4. **No STALE-AUDIT loop.** `just audit-sins` self-heals: it regenerates the rules whenever the
   taxonomy changes, so capturing a learning never triggers a sync-then-re-verify dance.
5. **Learnings steer from the start.** `AGENTS.md` §0b holds an always-on digest of the
   highest-leverage failure modes, so the agent avoids the common patterns from the first line;
   the full taxonomy stays on demand via the index, with the structural ones enforced.
6. **Run & observe the app.** A portable Playwright `smoke` gate + template replaces v6's habit
   of deferring every GUI check as "[~] can't verify". "Done" means run-and-observed.

Full upgrade steps: `migrate/MIGRATION.md`.

---

## 1. The core idea

Agents drift; every drift category has a matching artifact that closes it. An agent left alone
reinvents types, hallucinates library calls, redefines your domain terms, declares features
finished without testing, and re-explores your file tree from scratch each session. You can't
prompt these away reliably — the agent has no persistent memory between sessions. So the kit
writes the ground truth to disk and, *wherever a check can be made deterministic*, enforces it
with a gate that fails the build.

**The mechanism in one sentence:** move every lesson to the most automatic layer it can reach —
a hook that fires without the model beats a gate the build runs, which beats a type the
compiler checks, which beats a sentence in a doc the agent might skip.

**The v6.1 corollary:** only make deterministic what has an *objective truth*. Gate the
**product** (does it compile? does the API exist? is this known-bad pattern present? does the
app boot?). Do **not** gate the agent's own **prose** (was the log well-formed? are the
timestamps ordered?) — that creates self-referential loops the agent can only escape by editing
the bookkeeping the gate also polices. v6's worst overhead was exactly this; v6.1 removes it.

---

## 2. The problems it solves

| Failure mode | What closes it | Enforced? |
|---|---|---|
| Builds the wrong thing (misalignment) | grill-to-prd interview → PRD.md | Process |
| Redefines domain terms inconsistently | GLOSSARY.md | Process |
| Invents fields / wrong units (0–1 vs 0–100) | DATA_MODEL.md + audit_schema | Gated |
| Hallucinates a library's API | verification/verify_* | Gated |
| Repeats a bug fixed once before | SinsGotchasLearnings → **ast-grep** rules | Gated |
| Given 3 tasks, completes 2 | OpenTasksMustCompleteAll + check-tasks | Gated (verify-all) |
| Prompt log paraphrased / non-prompts logged | hooks + filters + check-prompt-log | Hook + Gated |
| Ships without ever running the app | `just smoke` (Playwright) | Gated (verify-all) |
| Botches a hard unit (complex logic / edge cases / validation) | eval-first suggestion (AGENTS §4a) + existing `test` gate | Process |
| Thrashes / loops on the same failure | escalation ladder (AGENTS §6a) → probe / Context7 / web | Process |
| Long/complex task blows out context & budget | phased plan file (AGENTS §4b) ~300k/phase + subagents | Process |
| Mid-build mega-task, no resumable structure | `plans/<slug>-DATE.md` + STATE.md per phase | Process |
| Mixed-language code/comments from the model | English/UTF-8 output rule (AGENTS §7) | Process |
| Buries a hard constraint / silently assumes | inline flags #EXPORT_CRITICAL / #PLAN_UNCERTAINTY (AGENTS §1a) | Process |
| Reinvents an existing in-repo solution | reuse-first anti-pattern (AGENTS §2) + RepoMapReadFirst | Process |
| Ships AI-slop UI (emoji icons, harsh colors, glassmorphism) | DESIGN_GUIDELINES.md + AGENTS §2 | Process |
| Re-walks hundreds of files each session | RepoMapReadFirst.md | Process |
| No trace of what was asked vs delivered | UserPromptLog + WorkLog | Hook + git |
| Loses place between sessions/tools | STATE.md | Process |
| Rules drift across tool configs | AGENTS.md + pointer stubs | By design |
| Gate silently no-ops (missing tool, wrong PM) | run_gate v6.5 loud-fail + `just doctor` | Gated |
| Descriptive docs decay into fiction | dox-check doc-refs + map-fresh checks | Gated |
| Same mistake documented, then repeated | trigger map + ★ALWAYS + recurrence ratchet + sins-triage | Process |
| Tests that pass but prove nothing (tautology / mock-your-own) | §2 Testing anti-patterns + §4a seams-first | Process |
| Thrashing on a hard bug without a repro | feedback-loop debugging (skills/diagnose-bugs.md, §6a rung 0) | Process |
| Phases built as horizontal layers, nothing demoable | vertical-slice / tracer-bullet phasing (§4b) | Process |
| Diff drifts from the phase's spec unnoticed | two-axis phase-end review (skills/code-review.md) | Process |
| Shallow pass-through modules accumulate | deep-modules vocabulary + deletion test (skills/deep-modules.md) | Process |

---

## 3. The files, and why each exists

**Contracts — the ground truth (author in order)**
- **PRD.md** — what the app does, who for, and crucially what it deliberately does *not* do.
- **GLOSSARY.md** — one exact definition per domain term; definition drift is a top bug source.
- **DATA_MODEL.md** — entities, grain (what makes a row unique), invariants, explicit units.
- **ARCHITECTURE.md** — components, data flow, tech choices with reasoning, explicit anti-goals.
- **DESIGN_GUIDELINES.md** — the default visual standard (anti-AI-slop); used only when the project renders a UI. A design language pinned in the PRD overrides it.

**Governance — how the agent behaves**
- **AGENTS.md** — the single source of truth for agent rules. §0 session-start protocol, §0a
  lightweight per-turn discipline, **§0b generalized failure-mode digest (always on)**, **§1a
  inline flags**, §2 anti-patterns, §3 the two-command gate, **§4a eval-first for hard parts**, **§4b phased
  planning + subagents** (v6.3), and **§6a the anti-thrash escalation ladder** — all suggestions.
  Every other tool-config file (`CLAUDE.md`, `.windsurfrules`, `.cursor/`, `.kilocode/`,
  `GEMINI.md`, `.rules`) is a three-line pointer back to it, so rules can't drift.
- **MODEL_NOTES.md** (v6.3) — on-demand per-model operating tips (context budget, reasoning-
  effort tiers, sampling, caching) for non-frontier models. Separate from AGENTS.md so the
  always-read surface stays lean.
- **EXECUTION_PLAN.md** — the build in phases, each shippable and verified before the next.
  The plan lives here; the live cursor lives in `STATE.md`. For one large mid-build task, use a
  dated **`plans/<slug>-DATE.md`** working plan (v6.3, §4b) instead of bloating this file.

**Memory & enforcement**
- **UserPromptLog.md** — append-only verbatim record of every instruction. Hooks
  (`.claude/settings.json`, `.opencode/plugins/prompt-logger.js`) capture it outside the
  model's control; in v6.1 they filter out tool-echoes/file-dumps and stamp offset-aware
  timestamps. **Passive evidence — the agent never edits it.**
- **SinsGotchasLearnings.md** — the incident-indexed defect taxonomy (dozens of shipped entries). Each
  entry is prose; a few carry an optional `### Audit Rule` (ast-grep) that `just audit-sins`
  compiles to `rules/*.sins.yml` and runs. The highest-leverage entries are mirrored into
  `AGENTS.md §0b`.
- **SinsGotchasLearnings_INDEX.md** — generated one-line-per-incident index, read at session
  start; open a full entry on demand.
- **OpenTasksMustCompleteAll.md** — the checklist of **real deliverables** for the current unit
  of work; `check-tasks` (in `verify-all`) fails while any is open or deferred without a reason.
  v6.1: process steps are **not** tasks.
- **RepoMapReadFirst.md / STATE.md / WorkLogAfterEachRun.md** — the living codebase map (~2k
  tokens instead of a 50k re-walk), the machine-readable build cursor, and a short
  one-entry-per-session record of what was delivered.
- **types/, verification/, tests/fixtures/, skills/** — code-level contracts, library-API check
  scripts, canonical inputs with planted bugs, the grill-to-prd interview, and the
  `smoke.spec.ts` template for running the app.

---

## 4. Why it works

- **It externalizes memory the agent doesn't have.** The files are the missing memory, named so
  the filename itself signals the purpose.
- **It converts prose into gates — and hooks.** A rule in a doc is a suggestion; the same rule
  as a `just verify` check is a wall; a hook that runs whether or not the model cooperates is
  the strongest layer.
- **It uses a real parser for code checks.** v6.1's ast-grep audits honor the kit's own rule
  ("parse structured text with a real parser") — the v6 grep audits violated it.
- **It makes the right thing the cheap thing.** Re-orienting from `RepoMapReadFirst.md` is
  cheaper than re-walking the tree; trusting a green `just verify` is cheaper than re-checking
  by hand — and in v6.1 the green gate is actually reachable mid-work, so the agent trusts it
  instead of routing around it.

**Naming is part of the prompt.** Evocative, purpose-revealing filenames (SinsGotchasLearnings,
OpenTasksMustCompleteAll, RepoMapReadFirst) steer behavior better than bland ones.
Ecosystem-standard names (AGENTS.md, GEMINI.md, PRD) are left alone — tools match them literally.

---

## 5. How to run it

**First-time setup (new project).** One prerequisite, installed once ever: `mise`
(`winget install jdx.mise`, or `curl https://mise.run | sh`). Then:

1. Make a folder, name it your project, extract the kit files into it (no sub-folder).
2. Double-click `scaffold.ps1` (WSL: `bash scaffold.sh`) — installs the toolchain (incl.
   `ast-grep`), inits git + the gate hooks, makes the first commit, prints your grill prompt.
3. Open your agent in the folder and paste the grill prompt; answer the interview; it writes the
   contracts and then builds phase by phase.

**The daily loop**
- **Start:** "Read RepoMapReadFirst.md and STATE.md, tell me where we are, then continue."
- **While building:** run `just verify` freely — fast code gates that stay green; trust it.
- **Give work:** the hook logs your prompt; the agent pulls the real deliverables into
  OpenTasks. (No placeholders to fill, no process steps to log.)
- **Hit a bug:** fix it, add a prose `SinsGotchasLearnings.md` entry (an ast-grep `### Audit
  Rule` only if it's a clean structural pattern). No sync dance — `audit-sins` self-heals.
- **Before a commit / end of phase:** `just verify-all` must be green (the pre-commit hook runs
  it). It includes the task gate, prompt-log check, and the app `smoke` test.

**Commands you'll actually type**

| Command | What it does |
|---|---|
| `just verify` | Fast **code** gates (lint, types, tests, library checks, schema, sins audit, dox). Run freely. |
| `just verify-all` | Everything in `verify` + tasks + prompt-log + app smoke. Pre-commit / CI. |
| `just doctor` | Harness self-test: every configured gate can actually execute. Run after scaffold / on a new machine / on unexpected skips. |
| `just sins-triage` | Learning-loop health: promotion candidates, missing triggers, digest budget, bloat. |
| `just audit-sins` | ast-grep scan of the taxonomy's rules (self-heals if stale). |
| `just sins-sync` | Explicitly regenerate `rules/` + the index from the taxonomy. |
| `just smoke` | Run & observe the app (Playwright), if a `smoke` script is configured. |
| `just map-sync` | Regenerate RepoMapReadFirst.md (keeps your curated notes). |
| `just state` | Print the current build cursor from STATE.md. |

---

## 6. Which files to reference, and when

| When you're… | Point the agent at… |
|---|---|
| Starting a brand-new project | `skills/grill-to-prd.md` |
| Resuming any session | `RepoMapReadFirst.md` + `STATE.md` |
| Giving multiple tasks | `OpenTasksMustCompleteAll.md` |
| Defining or arguing a term | `GLOSSARY.md` |
| Touching the database / units | `DATA_MODEL.md` + `schema_rules.json` |
| Adding a new library | `verification/` (write `verify_<lib>` first) |
| Right after fixing a bug | `SinsGotchasLearnings.md` (prose; rule if structural) |
| A bug survived one fix attempt | `skills/diagnose-bugs.md` (repro loop before attempt 2) |
| Closing a phase (final commit) | `skills/code-review.md` (two-axis; skip if trivial) |
| Creating a new module/interface | `skills/deep-modules.md` (deletion test) |
| A design question paper can't settle | `skills/prototype-to-answer.md` |
| Ending a session mid-task / switching tools | `skills/handoff.md` |
| Upgrading the kit itself | `migrate/UPGRADE_AUTOPILOT.md` (hands-off) |
| About to start any task | `AGENTS.md` §0b digest, then the INDEX for the area |
| Unsure of the rules | `AGENTS.md` |

---

## 7. Keep in mind

- **Match ceremony to the job.** The logs and task-tracking earn their keep on multi-phase
  builds where tasks get dropped. For a throwaway script, keep `PRD.md` + `AGENTS.md` and delete
  the rest — the gates no-op cleanly when their files are absent.
- **Trust the green gate; don't re-check by hand.** If `just verify` passes, the known-bug
  patterns, library APIs, data contracts, and types are clean. Re-auditing them manually just
  burns tokens.
- **Don't gate your own prose.** If you find yourself editing a log or a timestamp to make a
  gate pass, stop — that's the v6 failure mode. The gate should describe an objective truth
  about the product, or it shouldn't be a hard gate.

The whole kit is `suds-vibe-coding-kit-v6.6.tar`. Nothing here requires GitHub or any service;
it is plain files plus two commands.
