#!/usr/bin/env python3
"""
adopt_kit.py — retrofit Sud's Vibe Coding Kit onto an EXISTING, non-kit project.

Third entry point, alongside scaffold (empty folder) and migrate (existing v4/v5 project).
Use this when you have a project you built WITHOUT the kit and want to adopt it mid-stream.

What it does (mechanical, safe):
  1. Copies kit FILES into your project — but NEVER overwrites a file you already have.
     (Your code and any same-named files win; only missing kit files are added.)
  2. Skips the flow-only files that don't belong in a project (scaffold.*, migrate/,
     adopt/, START_HERE.md, the docs, the example tarball bits).
  3. git init (if needed) + installs the pre-commit gate and post-commit worklog hooks.
  4. Adds .gitignore if absent.
  5. Generates the repo map, audit runner, and sins index from your existing code.
  6. Prints the agent prompt to REVERSE-ENGINEER the contracts from your real code —
     the one part that can't be automated.

What it does NOT do:
  - It does not fill PRD/GLOSSARY/DATA_MODEL/ARCHITECTURE — those describe YOUR project
    and must be drafted from your code (step 6 prompt handles this with your agent).
  - It does not touch your existing source, configs, or any file you already have.

Plan-only by default; --apply to execute (backup + git branch first if it's a git repo).

Usage:
    python adopt/adopt_kit.py --kit <path-to-unpacked-kit> [--plan|--apply]
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

# Files/dirs in the kit that are FLOW-ONLY — never copied into an adopted project.
SKIP_TOP = {
    "scaffold.ps1", "scaffold.sh", "setup.sh", "START_HERE.md",
    "migrate", "adopt", "examples", "src",
    # Kit meta-docs (how to USE the kit) — not project files; don't litter the adopted repo.
    "VibeCodingKit_FieldGuide_v6.5.md", "VibeCodingKit_FieldGuide_v6.6.md",
    "VibeCodingKit_Infographic_v6.4.html", "VibeCodingKit_Infographic_v6.5.html",
    "VibeCodingKit_Infographic_v6.6.html",
    "migrate/MIGRATION.md", "ADOPT_AND_UPGRADE.md",
    ".git",
}


def kit_files(kit: Path) -> list[str]:
    out = []
    for p in sorted(kit.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(kit).as_posix()
        top = rel.split("/", 1)[0]
        if top in SKIP_TOP or "__pycache__" in rel or rel.endswith(".pyc"):
            continue
        out.append(rel)
    return out


def classify(project: Path, kit: Path) -> dict[str, list[str]]:
    plan: dict[str, list[str]] = {"ADD": [], "EXISTS-KEEP": []}
    for rel in kit_files(kit):
        if (project / rel).exists():
            plan["EXISTS-KEEP"].append(rel)
        else:
            plan["ADD"].append(rel)
    return plan


def git(args, cwd):
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)


def install_hooks(project: Path) -> None:
    hooks = project / ".git" / "hooks"
    hooks.mkdir(parents=True, exist_ok=True)
    pre = hooks / "pre-commit"
    pre.write_text(
        "#!/bin/sh\n"
        "# Enforces AGENTS.md §3. Bypass only with --no-verify (and a good reason).\n"
        "# Preferred path runs the full set (code + bookkeeping + smoke); the python\n"
        "# fallback mirrors it gate-by-gate so a bare Windows+Git machine is still gated.\n"
        "if command -v just >/dev/null 2>&1; then exec just verify-all; fi\n"
        'PY=""\n'
        'for c in python python3 py; do command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }; done\n'
        'if [ -n "$PY" ]; then\n'
        '  echo "> pre-commit gate (python fallback; install just for the full runner)"\n'
        '  "$PY" scripts/run_gate.py lint          || exit 1\n'
        '  "$PY" scripts/run_gate.py typecheck     || exit 1\n'
        '  "$PY" scripts/run_gate.py test          || exit 1\n'
        '  "$PY" scripts/run_gate.py verify-libs   || exit 1\n'
        '  "$PY" verification/audit_schema.py      || exit 1\n'
        '  "$PY" scripts/sins.py audit             || exit 1\n'
        '  "$PY" scripts/dox_check.py              || exit 1\n'
        '  "$PY" verification/check_open_tasks.py  || exit 1\n'
        '  "$PY" verification/check_prompt_log.py  || exit 1\n'
        '  "$PY" scripts/run_gate.py smoke         || exit 1\n'
        '  exit 0\n'
        "fi\n"
        'echo "neither just nor python found - gate not run, commit allowed."\n',
        encoding="utf-8",
    )
    post = hooks / "post-commit"
    post.write_text(
        "#!/bin/sh\n"
        'LOG="WorkLogAfterEachRun.md"\n'
        '[ -f "$LOG" ] || exit 0\n'
        "{\n"
        '  echo ""\n'
        '  echo "## $(date -u +%Y-%m-%dT%H:%M:%SZ) - commit $(git rev-parse --short HEAD)"\n'
        '  echo "**Commit:** $(git log -1 --pretty=%s)"\n'
        "} >> \"$LOG\"\n",
        encoding="utf-8",
    )
    try:
        pre.chmod(0o755)
        post.chmod(0o755)
    except OSError:
        pass


def apply(project: Path, kit: Path, plan: dict) -> None:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    is_git = (project / ".git").exists()

    if is_git:
        br = f"adopt-kit-{stamp}"
        r = git(["checkout", "-b", br], project)
        print(f"  ok git branch {br}" if r.returncode == 0
              else f"  ! branch failed ({r.stderr.strip()}); on current branch")
    else:
        r = git(["init"], project)
        print("  ok git init" if r.returncode == 0 else "  ! git init failed")
        if not git(["config", "user.name"], project).stdout.strip():
            git(["config", "user.name", "Vibe Coder"], project)
            git(["config", "user.email", "vibe@localhost"], project)

    for rel in plan["ADD"]:
        s, d = kit / rel, project / rel
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, d)
        print(f"  + {rel}")

    install_hooks(project)
    print("  ok hooks installed (pre-commit gate + post-commit worklog)")

    # Generate living artifacts from the existing code.
    py = sys.executable or "python"
    for desc, args in [
        ("repo map", [py, "scripts/build_repo_map.py"]),
        ("audit runner", [py, "scripts/extract_audits.py"]),
    ]:
        if (project / Path(args[1])).exists():
            subprocess.run(args, cwd=project, capture_output=True)
    if (project / "scripts" / "build_sins_index.py").exists() and (project / "SinsGotchasLearnings.md").exists():
        with (project / "SinsGotchasLearnings_INDEX.md").open("w", encoding="utf-8") as fh:
            subprocess.run([py, "scripts/build_sins_index.py", "SinsGotchasLearnings.md"],
                           cwd=project, stdout=fh)
    print("  ok generated repo map + audit runner + sins index")

    print("\nAdopted. Your existing files were untouched; only missing kit files were added.")
    print("\n=== NEXT: reverse-engineer the contracts from your real code ===")
    print("Open your coding agent in this project and paste:\n")
    print("  Read my existing codebase. From what's actually there, draft:")
    print("    - GLOSSARY.md  (domain terms in use)")
    print("    - DATA_MODEL.md (the real schema / data shapes)")
    print("    - ARCHITECTURE.md (tech choices already made, with brief rationale)")
    print("    - PRD.md (what this app currently does)")
    print("  Then set STATE.md to the current reality (phase, active task).")
    print("  Show me each draft to correct. Do NOT change my source code yet.\n")
    print("Finally:  just verify   (triage what the sins audit flags in existing code;")
    print("          fix it, or put '# ast-grep-ignore' (py/css) / '// ast-grep-ignore'")
    print("          (ts/js) on the line above a confirmed-OK exception, with a reason)")


def main() -> None:
    ap = argparse.ArgumentParser(description="Retrofit the kit onto an existing project.")
    ap.add_argument("--kit", required=True)
    ap.add_argument("--project", default=".")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--plan", action="store_true")
    g.add_argument("--apply", action="store_true")
    args = ap.parse_args()

    project = Path(args.project).resolve()
    kit = Path(args.kit).resolve()
    if not (kit / "AGENTS.md").exists() or not (kit / "justfile").exists():
        print(f"ERROR: {kit} doesn't look like a kit folder.")
        sys.exit(2)
    if kit == project:
        print("ERROR: --kit and --project are the same folder. Unpack the kit elsewhere.")
        sys.exit(2)

    plan = classify(project, kit)
    print(f"Adopt plan for: {project}\n(kit: {kit})\n")
    print(f"## ADD ({len(plan['ADD'])}) — kit files that will be copied in")
    for rel in plan["ADD"]:
        print(f"   + {rel}")
    if plan["EXISTS-KEEP"]:
        print(f"\n## EXISTS — already in your project, will NOT be touched ({len(plan['EXISTS-KEEP'])})")
        for rel in plan["EXISTS-KEEP"]:
            print(f"   = {rel}")

    if args.apply:
        print("\n— applying —")
        apply(project, kit, plan)
    else:
        print("\n(plan only — nothing changed. Re-run with --apply to execute.)")


if __name__ == "__main__":
    main()
