<#
.SYNOPSIS
    Sud's Vibe Coding Kit - in-place scaffold. Run this ONCE, in the folder that
    already contains the kit files (the folder you renamed to your project name).
.DESCRIPTION
    This does the non-agent-friendly bootstrap steps so your coding agent doesn't
    have to (agents are bad at imperative shell orchestration - that's what made
    them loop). It is IN-PLACE: it does NOT create a sub-folder. It is IDEMPOTENT:
    safe to run twice (e.g. double-click again if the first run half-finished).

    Steps:
      1. Derive the project name from THIS folder's name.
      2. Install the toolchain via mise (just, uv, node/pnpm) - best-effort.
      3. git init + install the pre-commit (gate) and post-commit (worklog) hooks.
      4. Strip kit-internal files that shouldn't live in your project.
      5. Generate the audit runner, the sins index, and the repo map.
      6. Make ONE bootstrap commit with --no-verify (the gate can't run until the
         toolchain is in place; every commit AFTER this one is gated).
      7. Print the exact first prompt to paste into your coding agent.

    PREREQUISITE (install once, ever): mise.  In PowerShell:
        winget install jdx.mise
    (or see https://mise.jdx.dev/installing-mise.html). Everything else is automated.
.EXAMPLE
    Double-click scaffold.ps1   (or:  powershell -ExecutionPolicy Bypass -File .\scaffold.ps1)
#>

$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
$Project = Split-Path -Leaf $PSScriptRoot

function Say($msg, $color = "Gray") { Write-Host $msg -ForegroundColor $color }

Say ""
Say "==================================================" Cyan
Say "  Sud's Vibe Coding Kit - scaffolding in place" Cyan
Say "  Project: $Project" Cyan
Say "==================================================" Cyan
Say ""

# -- 1. Sanity: are we actually in a kit folder? -----------------------------
if (-not (Test-Path "AGENTS.md") -or -not (Test-Path "justfile")) {
    Say "[ERROR] This doesn't look like a kit folder (no AGENTS.md/justfile)." Red
    Say "        Run this from the folder you renamed to your project name," Red
    Say "        into which you extracted the kit files." Red
    exit 1
}

# -- 2. Toolchain via mise (the ONE thing you preinstall) --------------------
if (Get-Command mise -ErrorAction SilentlyContinue) {
    Say "[OK] mise found. Installing pinned toolchain (just, uv, node/pnpm)..." Green
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    # mise may print to stderr or prompt to trust the config; that's not a failure.
    # Trust the project config up front so it doesn't block, then install.
    mise trust 2>&1 | Out-Null
    mise install 2>&1 | Out-Null
    mise use --quiet just@latest uv@latest node@lts pnpm@latest 2>&1 | Out-Null
    $ErrorActionPreference = $prevEAP
    Say "[OK] Toolchain step done (re-run 'mise install' manually if a tool is missing)." Green
} else {
    Say "[WARN] mise is not installed - the ONE prerequisite." Yellow
    Say "       Install it once, then re-run this script (double-click again):" Yellow
    Say "         winget install jdx.mise" Yellow
    Say "       (or https://mise.jdx.dev/installing-mise.html)" Yellow
    Say "       Continuing without it; 'just'/'uv'/'pnpm' may be missing until you do." DarkGray
}

# -- 3. git init + hooks -----------------------------------------------------
if (-not (Test-Path ".git")) {
    git init -q
    Say "[OK] git initialized." Green
} else {
    Say "[OK] git already initialized." Green
}

# repo-local identity fallback so the bootstrap commit can't fail on a clean machine
$prevEAP = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
$haveName = (git config user.name 2>$null)
$ErrorActionPreference = $prevEAP
if (-not $haveName) {
    git config user.name  "Vibe Coder"
    git config user.email "vibe@localhost"
    Say "[INFO] Set a repo-local git identity placeholder (change it any time)." DarkGray
}

New-Item -ItemType Directory -Force -Path ".git/hooks" | Out-Null

# pre-commit: run the gate, with a python fallback so it works without 'just'.
# IMPORTANT: written with LF-only line endings. A #!/bin/sh hook with CRLF fails on
# Windows git ("bad interpreter: /bin/sh^M"), so we strip any CR before writing.
$preCommit = @'
#!/bin/sh
# Enforces AGENTS.md gate. Bypass only with --no-verify (and a good reason).
# A commit runs the FULL set (verify-all): code gates + bookkeeping + smoke.
if command -v just >/dev/null 2>&1; then
  exec just verify-all
fi
PY=""
for c in python python3 py; do command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }; done # audit-disable (embedded POSIX sh, not PowerShell)
if [ -n "$PY" ]; then
  echo "- pre-commit gate (python fallback; install 'just' for the full runner)"
  "$PY" scripts/run_gate.py lint          || exit 1
  "$PY" scripts/run_gate.py typecheck     || exit 1
  "$PY" scripts/run_gate.py test          || exit 1
  "$PY" scripts/run_gate.py verify-libs   || exit 1
  "$PY" verification/audit_schema.py      || exit 1
  "$PY" scripts/sins.py audit             || exit 1
  "$PY" scripts/dox_check.py              || exit 1
  "$PY" verification/check_open_tasks.py  || exit 1
  "$PY" verification/check_prompt_log.py  || exit 1
  "$PY" scripts/run_gate.py smoke         || exit 1
  echo "- pre-commit gate passed (python fallback)"
  exit 0
fi
echo "- neither just nor python found - gate not run, commit allowed. Install mise."
'@ -replace "`r", ""
[System.IO.File]::WriteAllText((Join-Path (Get-Location) ".git/hooks/pre-commit"), $preCommit)

# post-commit: append the commit to the worklog (backstop trace). LF-only, #!/bin/sh.
$postCommit = @'
#!/bin/sh
LOG="WorkLogAfterEachRun.md"
[ -f "$LOG" ] || exit 0
{
  echo ""
  echo "## $(date -u +%Y-%m-%dT%H:%M:%SZ) - commit $(git rev-parse --short HEAD)"
  echo "**Commit:** $(git log -1 --pretty=%s)"
} >> "$LOG"
'@ -replace "`r", ""
[System.IO.File]::WriteAllText((Join-Path (Get-Location) ".git/hooks/post-commit"), $postCommit)

Say "[OK] git hooks installed (pre-commit gate + post-commit worklog)." Green

# -- 4. Strip kit-internal files that don't belong in YOUR project -----------
$KitInternal = @("scaffold.ps1", "scaffold.sh", "setup.sh", "examples", "migrate", "adopt", "START_HERE.md")
foreach ($item in $KitInternal) {
    if (Test-Path $item) { Remove-Item -Recurse -Force $item -ErrorAction SilentlyContinue }
}
Say "[OK] Removed kit-internal files (the scaffold scripts themselves)." Green
Say "     (They live in the original kit; your project doesn't need them.)" DarkGray

# -- 5. Ensure standard dirs + generate the living artifacts -----------------
foreach ($d in @("src", "tests/fixtures", "verification", "types", "scripts", "docs/adr", "skills")) {
    New-Item -ItemType Directory -Force -Path $d | Out-Null
}

# Call the Python generators directly (more reliable during bootstrap than going through
# `just`, and avoids PS 5.1 treating the generators' stderr progress text as an error).
# $ErrorActionPreference is briefly relaxed so native stderr output isn't promoted to a
# terminating error (PS 5.1 quirk: any stderr from a native command can raise NativeCommandError).
$prevEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$PYGEN = $null
foreach ($c in @('python','python3','py')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $PYGEN = $cmd.Source; break }
}
if ($PYGEN) {
    & $PYGEN scripts/extract_audits.py 2>&1 | Out-Null
    & $PYGEN scripts/build_sins_index.py SinsGotchasLearnings.md 2>$null | Set-Content -Encoding utf8 "SinsGotchasLearnings_INDEX.md"
    & $PYGEN scripts/build_repo_map.py 2>&1 | Out-Null
}
$ErrorActionPreference = $prevEAP
Say "[OK] Generated audit runner, sins index, and repo map." Green

# -- 6. Bootstrap commit (--no-verify: the gate can't run pre-toolchain) -----
$ErrorActionPreference = 'Continue'
git add -A 2>&1 | Out-Null
git commit -q --no-verify -m "chore: scaffold $Project from Sud's Vibe Coding Kit" 2>&1 | Out-Null
$ErrorActionPreference = $prevEAP
Say "[OK] Bootstrap commit landed (--no-verify; all later commits are gated)." Green

# -- 7. Hand off to the agent ------------------------------------------------
Say ""
Say "==================================================" Green
Say "  Scaffold complete. Now open your coding agent" Green
Say "  in THIS folder and paste the prompt below." Green
Say "==================================================" Green
Say ""
Say "  Read CONTEXT.md and the files it lists. Then run the" White
Say "  grill-to-prd skill (skills/grill-to-prd.md): interview me" White
Say "  ONE question at a time until the design is fully resolved," White
Say "  recommending an answer for each. Do NOT write code or scaffold" White
Say "  anything yet - only interview, then produce PRD.md when done." White
Say ""
Say "  (The grill ends by asking your dev PORT - accept the random" DarkGray
Say "   recommendation or pick your own. Build starts after the PRD.)" DarkGray
Say ""
