# GEMINI.md — pointer for Gemini-family agents (Antigravity, Gemini CLI)

All rules live in `AGENTS.md` at the repo root — read it end-to-end before writing code.
Read, in order: `STATE.md` (orient), `AGENTS.md` (rules), then the contract files it lists.

**This tool has no prompt-capture hooks**, so AGENTS.md §0a applies in its manual form:
append every user instruction to `UserPromptLog.md` VERBATIM (inside the ~~~text fence,
exactly as typed) before starting work — then never edit it. The log is passive evidence;
`just verify-all` only fails on a structurally malformed file, not on timestamp ordering.

Do not add rules here — they would drift from AGENTS.md.
