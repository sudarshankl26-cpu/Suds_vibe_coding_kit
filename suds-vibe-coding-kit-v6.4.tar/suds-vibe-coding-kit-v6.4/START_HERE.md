# START HERE — Sud's Vibe Coding Kit v6.4

> **New in v6.4:** inline flags `#EXPORT_CRITICAL` / `#PLAN_UNCERTAINTY` / `#PATH_DECISION`
> (`AGENTS.md` §1a), a §2 *reuse-before-reinvent* anti-pattern, a built-in anti-AI-slop
> `DESIGN_GUIDELINES.md` (+ copy-paste build prompt `PROMPTS.md` §Q), a beginner "Start here"
> onboarding, and OpenAI Codex support (`.codex/`). All prose-only — no new gates or machinery.
>
> **New in v6.3:** tuned for 1M-context open-weight models. Adds `AGENTS.md` §4b *phased
> planning* (dated `plans/` files, ~300k tokens/phase, subagent delegation), a new
> `MODEL_NOTES.md` (per-model tips for GLM 5.2 / DeepSeek V4 Pro / MiniMax M3 / MiMo 2.5 Pro), an
> English/UTF-8 output rule, and a reordered §6a ladder. All additive — upgrading just refreshes
> `AGENTS.md` (+ the new files).
>
> **New in v6.2:** two suggestions added to `AGENTS.md` — §4a *eval-first for hard parts* and
> §6a the *anti-thrash escalation ladder*. Purely additive (no infra change). Details in the
> Field Guide's "What's new" sections.

This one tar does three jobs. Which path you take depends on the folder you're pointing at.

- **Empty folder -> new project ->** use `scaffold.ps1` (Path A)
- **Existing v4/v5 kit project -> upgrade ->** use `migrate/` (Path B)
- **Existing project built WITHOUT the kit -> adopt ->** use `adopt/` (Path C)
- **Already on v6 -> upgrade to v6.1 ->** see `MIGRATION_v6.1.md` (swap a handful of scripts;
  no data migration — your contracts, learnings, and logs are untouched).

> Prefer a single walkthrough with copy-paste PowerShell for the adopt and upgrade paths?
> See **`ADOPT_AND_UPGRADE_v6.1.md`** — it covers "no kit yet" and "v5/v6 → v6.1" end to end.

You never need two downloads. The `migrate/` folder is upgrade-only; when you scaffold a
new project it is stripped automatically, so new projects stay clean.

**One-time prerequisite (install once, ever, on your machine):**
[`mise`](https://mise.jdx.dev/installing-mise.html) — on Windows `winget install jdx.mise`,
in WSL `curl https://mise.run | sh`. It installs `just`/`uv`/`node`/`pnpm` for you so the
agent never has to. This is what fixed the old setup loops.

---

## Path A — New project

Your existing workflow. v5 only made it reliable.

1. Make a new folder. Rename it to your project name.
2. Extract the kit files **into it directly** — no sub-folder. This folder IS the project root.
3. Double-click **`scaffold.ps1`** (or in WSL: `bash scaffold.sh`). Runs once, in place:
   installs the toolchain, inits git + the verification hooks, makes the first commit, and
   prints your next prompt. Safe to run twice.
4. Open your coding agent in this folder and paste the grill prompt it printed:
   > Read CONTEXT.md and the files it lists. Then run the grill-to-prd skill
   > (skills/grill-to-prd.md): interview me ONE question at a time until the design is
   > fully resolved, recommending an answer for each. Do NOT write code or scaffold
   > anything yet — only interview, then produce PRD.md when done.
5. Answer the grill (it ends by asking your dev port — accept the random recommendation or
   pick your own). It writes `PRD.md`, then the rest of the contracts, then builds phase by
   phase. The final phase generates `start-server.ps1` / `stop-server.ps1`.

That's it. Full detail: `README.md` and `VibeCodingKit_FieldGuide_v6.4.md`.

---

## Path B — Upgrade an existing v4/v5 kit project to v6.1

**Already on v6?** Use `MIGRATION_v6.1.md` (a lighter manual swap of ~15 infra files, no
classification step). The migrator below is for v4/v5 — or any time you want the full
backup + branch safety net.

**Do NOT extract the tar on top of your project** — that would overwrite your work. Extract
it elsewhere and point the migrator at your project. The migrator never touches your state
(contracts, incidents, logs, `src/`, `.env`); it only auto-replaces kit files that are still
byte-identical to stock v4. Anything your agent edited (or any v5/v6 infra) is staged for
review, not overwritten. It makes a git branch + a backup before changing anything, and is
fully reversible.

```bash
# 1. Unpack v6.1 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.4.tar -C /tmp/

# 2. From INSIDE your existing project — see the plan (changes nothing):
python /tmp/suds-vibe-coding-kit-v6.4/migrate/migrate_kit.py --kit /tmp/suds-vibe-coding-kit-v6.4 --plan

# 3. Apply (creates a git branch + backup first; stages judgment-call merges as *.kit-incoming):
python /tmp/suds-vibe-coding-kit-v6.4/migrate/migrate_kit.py --kit /tmp/suds-vibe-coding-kit-v6.4 --apply
```

Windows without WSL — use the launcher instead of calling Python directly:
```powershell
# from inside your project; add -Apply for step 3
C:\temp\suds-vibe-coding-kit-v6.4\migrate\migrate-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.4
```

After `--apply`, the safe changes are done and the judgment-call files sit next to yours as
`*.kit-incoming`. Hand it to your agent:

> Read `migrate/MIGRATION.md` and walk me through each `*.kit-incoming` file one at a time —
> show the diff, tell me what the kit changed, recommend an action, and apply only when I confirm.

For `SinsGotchasLearnings.md.kit-incoming` the agent runs the automated merge
(`migrate/merge_sins.py`) — it keeps your real incidents first and appends the kit's generic
ones renumbered, skipping duplicates. Then install the new toolchain and prove green:

```bash
mise install        # provisions just/uv/node/pnpm + ast-grep (the one new v6.1 prereq)
just sins-sync      # rebuild the ast-grep rules from your taxonomy
just verify-all     # audit-sins self-heals; everything must be green
```

Review the git diff. Keep it by merging the `migrate-kit-*` branch, or roll back via
`git checkout -` (and delete the branch) or by restoring the `.kit-backup-*/` folder.

Full detail: `migrate/MIGRATION.md` (and `ADOPT_AND_UPGRADE_v6.1.md` for the PowerShell walkthrough).

---

## Path C - Adopt the kit into an existing NON-kit project

For a project you built without the kit and want to retrofit. Like migrate, you run a
script from inside your project pointing at the unpacked kit; it copies in the kit
machinery WITHOUT overwriting any file you already have, installs the gate hooks, and
generates the repo map. It does NOT fill your contracts (PRD/GLOSSARY/etc) - those
describe your project and get reverse-engineered from your code (the script prints the
agent prompt for that).

```bash
# 1. Unpack v6.1 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.4.tar -C /tmp/
# 2. From INSIDE your existing project - see the plan (changes nothing):
python /tmp/suds-vibe-coding-kit-v6.4/adopt/adopt_kit.py --kit /tmp/suds-vibe-coding-kit-v6.4 --plan
# 3. Apply (adds missing kit files, installs hooks, generates the map):
python /tmp/suds-vibe-coding-kit-v6.4/adopt/adopt_kit.py --kit /tmp/suds-vibe-coding-kit-v6.4 --apply
```

Windows without WSL: `C:\temp\suds-vibe-coding-kit-v6.4\adopt\adopt-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.4` (add `-Apply`).

After applying, run `mise install` (gets `ast-grep`), then paste the contract-backfill prompt
it printed into your agent (it drafts GLOSSARY/DATA_MODEL/ARCHITECTURE/PRD from your real code
for you to correct). Then `just verify` and triage what the audit flags in your existing code.
Full PowerShell walkthrough: `ADOPT_AND_UPGRADE_v6.1.md`.

---

## The decision in one line

**Empty folder -> `scaffold`. Existing v4/v5 kit project -> `migrate`. Existing non-kit project -> `adopt`.**
