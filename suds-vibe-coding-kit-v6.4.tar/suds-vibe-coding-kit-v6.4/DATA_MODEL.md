# DATA_MODEL

Entities, their grain, their relationships, and their invariants. The agent reads this before writing any data-handling code.

If this app doesn't have persistent state, you can skip this file. But most apps do.

---

## Conventions

- **Grain** for each entity is stated explicitly. "Grain" = the set of columns that uniquely identify a row.
- **Invariants** are constraints the data must always satisfy, beyond what the schema enforces.
- **Units** are stated explicitly for every numeric column. Percentages-as-decimals (0.45) vs percentages-as-percent (45) is the single most common bug class — name your choice.
- **Nullable columns** are explicitly marked, and the semantic of NULL is stated. "NULL means user hasn't completed onboarding" is different from "NULL means we don't have the data."

---

## Entities

### [EntityName, e.g. `users`]

**Grain:** [Which column(s) make a row unique. Example: `(id)` or `(org_id, user_id)`.]

**Columns:**

| Column | Type | Nullable? | Units | Description |
|---|---|---|---|---|
| `id` | int | no | — | Primary key |
| `email` | text | no | — | Unique per org |
| `created_at` | text | no | ISO-8601 UTC | When the user record was created |
| `signup_revenue` | real | yes | USD | NULL when no revenue at signup (free trial) |
| ... | | | | |

**Invariants:**

- [e.g. "`email` is unique within `(org_id, email)`."]
- [e.g. "`created_at` is never in the future."]
- [e.g. "Once `archived_at` is set, no further updates are allowed."]

**Relationships:**

- 1:N with `orders` via `orders.user_id`
- M:N with `roles` via `user_roles`

---

### [Entity 2]

[same structure]

---

## Cross-entity invariants

Constraints that span multiple entities:

- [e.g. "Every row in `orders` has a matching row in `users` via `user_id`."]
- [e.g. "`order.total_amount` == sum of `order_items.amount` for that order."]
- [e.g. "If `order.status = 'refunded'`, there exists a corresponding row in `refunds`."]

---

## Schema-vs-code coupling

[For each layer that has its own representation of the schema, note where it lives:]

- **Database schema:** `migrations/*.sql` (or `prisma/schema.prisma`, or wherever)
- **Code-level types:** `types/models.py` (or `types/schema.ts`)
- **Frontend types:** `frontend/src/api/types.ts` (typically generated, not hand-written)

These must stay in sync. When any layer changes, all three update in the same commit.

---

## Grain hazards specific to this app

[Common joins that can cause fanout if grain isn't respected. Document them here so the agent doesn't have to rediscover.]

- `users` ⋈ `events`: events has grain `(event_id)`, so joining on `user_id` alone fans out. Always pre-aggregate events to user-level before joining users.
- `orders` ⋈ `order_items`: order_items has grain `(order_id, line_no)`. SUM(amount) over a join must DISTINCT on order_id or pre-aggregate.
- [Add your project's hazards here as you find them.]

---

## Units / unit conventions

The single biggest source of silent corruption. Pin these:

- **Percentages:** stored as [decimals 0-1 / integers 0-100]. Column naming convention: [`_pct` for 0-100, `_rate` / `_ratio` for 0-1].
- **Currency:** stored as [cents (int) / dollars (decimal)]. Column naming convention: [`_amount` for dollars, `_cents` for cents]. Single currency or multi?
- **Timestamps:** stored as [ISO-8601 strings / Unix seconds / Unix millis]. Timezone: [UTC always / local with explicit timezone column].
- **Durations:** stored as [seconds / milliseconds / interval string].
- **Distances / sizes:** [meters / feet / bytes / KB].

Inconsistency across tables → automatic finding.
