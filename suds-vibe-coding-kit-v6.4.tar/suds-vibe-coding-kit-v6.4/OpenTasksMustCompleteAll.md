# OpenTasksMustCompleteAll

The authoritative checklist for the CURRENT unit of work. Its name is its rule:
every task here must reach a terminal state before the agent declares the run done.
This exists because agents drop tasks — given 3, they do 2 well and forget the third.
The conversation is not a reliable task store; this file is.

## Protocol

1. Extract only the **real deliverables** the user asked for and add each as a `[ ]` item
   below, before starting. **Do NOT list process steps** ("log the prompt", "update STATE",
   "run verify", "capture a learning") — those are routine, not deliverables, and listing them
   was pure make-work in v6. If it isn't something the user would notice was missing, it's not
   a task.
2. A task moves to a terminal state only when truly resolved:
   - `[x]` done — completed AND verified (ran/observed, not just written).
   - `[~]` deferred — explicitly punted, WITH a reason on the same line.
   - `[!]` blocked — cannot proceed, WITH the blocker on the same line.
3. Before declaring a run complete, reconcile: every item is `[x]`, `[~]`, or `[!]`. An item
   left `[ ]` means the run is NOT done.
4. `just verify-all` runs `check_open_tasks.py`, which fails if any `[ ]` remains or a `[~]`/
   `[!]` has no reason. (It's in `verify-all`, not the mid-work `just verify`, so your own
   in-progress items never make the fast gate red.)

## Task states legend
- `[ ]` open (not allowed at run completion)
- `[x]` done and verified
- `[~]` deferred — reason required
- `[!]` blocked — blocker required

---

## Current tasks

<!-- One [ ] line per discrete task. Example shown; replace. -->
- [x] Example: scaffold the repo — done and verified

<!-- When a unit of work fully closes, move its tasks to the archive below. -->

## Archive (completed units of work)

<!-- Move closed task groups here with a date header, to keep "Current" focused. -->
