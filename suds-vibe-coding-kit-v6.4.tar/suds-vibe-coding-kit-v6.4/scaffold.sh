#!/usr/bin/env bash
# scaffold.sh — Sud's Vibe Coding Kit, in-place scaffold (WSL / Claude Code / mac / Linux).
# Mirror of scaffold.ps1. Run ONCE in the folder that already holds the kit files
# (the folder you renamed to your project name). In-place (no sub-folder), idempotent.
#
# PREREQUISITE (install once, ever): mise — https://mise.jdx.dev/installing-mise.html
#   curl https://mise.run | sh        # then restart shell
# Everything else is automated below.
#
# Usage:  bash scaffold.sh
set -uo pipefail   # NOT -e: we want best-effort steps to warn, not abort the bootstrap

cd "$(dirname "${BASH_SOURCE[0]}")"
PROJECT="$(basename "$PWD")"

say()  { printf '%s\n' "$*"; }
ok()   { printf '[OK] %s\n'   "$*"; }
warn() { printf '[WARN] %s\n' "$*"; }
err()  { printf '[ERROR] %s\n' "$*" >&2; }

say ""
say "=================================================="
say "  Sud's Vibe Coding Kit — scaffolding in place"
say "  Project: $PROJECT"
say "=================================================="
say ""

# ── 1. Sanity check ─────────────────────────────────────────────────────────
if [ ! -f AGENTS.md ] || [ ! -f justfile ]; then
  err "This doesn't look like a kit folder (no AGENTS.md/justfile)."
  err "Run from the folder you renamed to your project name and extracted the kit into."
  exit 1
fi

# ── 2. Toolchain via mise ───────────────────────────────────────────────────
if command -v mise >/dev/null 2>&1; then
  ok "mise found. Installing pinned toolchain (just, uv, node/pnpm)..."
  mise install || warn "'mise install' hit an error; continuing."
  mise use --quiet just@latest uv@latest node@lts pnpm@latest >/dev/null 2>&1 || true
  ok "Toolchain step done."
else
  warn "mise is not installed — the ONE prerequisite."
  warn "Install once, then re-run this script:"
  warn "  curl https://mise.run | sh   (then restart your shell)"
  say  "  Continuing without it; just/uv/pnpm may be missing until you do."
fi

# ── 3. git init + hooks ─────────────────────────────────────────────────────
if [ ! -d .git ]; then git init -q && ok "git initialized."; else ok "git already initialized."; fi

if [ -z "$(git config user.name 2>/dev/null)" ]; then
  git config user.name  "Vibe Coder"
  git config user.email "vibe@localhost"
  say "[INFO] Set a repo-local git identity placeholder (change it any time)."
fi

mkdir -p .git/hooks
cat > .git/hooks/pre-commit << 'HOOK'
#!/bin/sh
# Enforces AGENTS.md §3. Bypass only with --no-verify (and a good reason).
# Robust fallback chain so the gate runs whether or not `just` is installed:
#   1) just verify-all       (preferred — full set: code + bookkeeping + smoke)
#   2) python verify, gate-by-gate   (no just needed — works on bare Windows+Git)
#   3) allow, with a warning (no python either — can't gate yet)
if command -v just >/dev/null 2>&1; then
  exec just verify-all
fi
PY=""
for c in python python3 py; do command -v "$c" >/dev/null 2>&1 && { PY="$c"; break; }; done
if [ -n "$PY" ]; then
  echo "» pre-commit gate (python fallback; install 'just' for the full runner)"
  "$PY" scripts/run_gate.py lint          || exit 1
  "$PY" scripts/run_gate.py typecheck     || exit 1
  "$PY" scripts/run_gate.py test          || exit 1
  "$PY" scripts/run_gate.py verify-libs   || exit 1
  "$PY" verification/audit_schema.py      || exit 1
  "$PY" scripts/sins.py audit             || exit 1
  "$PY" scripts/dox_check.py              || exit 1
  "$PY" verification/check_open_tasks.py  || exit 1
  "$PY" verification/check_prompt_log.py  || exit 1
  "$PY" scripts/run_gate.py smoke         || exit 1
  echo "✓ pre-commit gate passed (python fallback)"
  exit 0
fi
echo "⚠ neither 'just' nor python found — gate not run, commit allowed. Install mise."
HOOK
chmod +x .git/hooks/pre-commit

cat > .git/hooks/post-commit << 'HOOK'
#!/usr/bin/env bash
LOG="WorkLogAfterEachRun.md"
[ -f "$LOG" ] || exit 0
{
  echo ""
  echo "## $(date -u +%Y-%m-%dT%H:%M:%SZ) — commit $(git rev-parse --short HEAD)"
  echo "**Commit:** $(git log -1 --pretty=%s)"
  echo "**Files touched:** $(git show --name-only --pretty=format: HEAD | grep -v '^$' | tr '\n' ' ')"
} >> "$LOG"
HOOK
chmod +x .git/hooks/post-commit
ok "git hooks installed (pre-commit gate + post-commit worklog)."

# ── 4. Strip kit-internal files ─────────────────────────────────────────────
KIT_INTERNAL=("scaffold.ps1" "scaffold.sh" "setup.sh" "examples" "migrate" "adopt" "START_HERE.md")
for item in "${KIT_INTERNAL[@]}"; do [ -e "$item" ] && rm -rf "$item"; done
ok "Removed kit-internal files (the scaffold scripts themselves)."

# ── 5. Standard dirs + generate living artifacts ────────────────────────────
mkdir -p src tests/fixtures verification types scripts docs/adr skills
if command -v just >/dev/null 2>&1; then
  just sins-sync 2>/dev/null || true
  just map-sync  2>/dev/null || true
else
  python3 scripts/extract_audits.py 2>/dev/null || true
  python3 scripts/build_sins_index.py SinsGotchasLearnings.md > SinsGotchasLearnings_INDEX.md 2>/dev/null || true
  python3 scripts/build_repo_map.py 2>/dev/null || true
fi
ok "Generated audit runner, sins index, and repo map."

# ── 6. Bootstrap commit ─────────────────────────────────────────────────────
git add -A 2>/dev/null || true
git commit -q --no-verify -m "chore: scaffold $PROJECT from Sud's Vibe Coding Kit" 2>/dev/null || true
ok "Bootstrap commit landed (--no-verify; all later commits are gated)."

# ── 7. Hand off ─────────────────────────────────────────────────────────────
say ""
say "=================================================="
say "  Scaffold complete. Open your coding agent in THIS"
say "  folder and paste the prompt below."
say "=================================================="
say ""
say "  Read CONTEXT.md and the files it lists. Then run the"
say "  grill-to-prd skill (skills/grill-to-prd.md): interview me"
say "  ONE question at a time until the design is fully resolved,"
say "  recommending an answer for each. Do NOT write code or scaffold"
say "  anything yet — only interview, then produce PRD.md when done."
say ""
say "  (The grill ends by asking your dev PORT — accept the random"
say "   recommendation or pick your own. Build starts after the PRD.)"
say ""
