# MODEL_NOTES.md — operating tips per model

On-demand companion to `AGENTS.md` (kept separate so the always-read rules stay lean and the
prompt prefix stays cache-friendly). Read this once if you're driving this repo with a
non-frontier / open-weight model. **Rules still live in `AGENTS.md`; this file only tunes *how*
you operate a given model.**

> Specs below are as of **June 2026** and will drift — confirm context window, effort tiers, and
> tool/MCP support for your exact model + harness before relying on a number.

## The models this repo is commonly driven with

| Model | Context | Reasoning effort | Notes |
|---|---|---|---|
| **GLM 5.2** | ~1M (usable) | High / Max | Strong tool use; drops into Claude Code/Cline/Roo/Kilo; great for long-horizon SWE + multi-file refactors. |
| **DeepSeek V4 Pro** | ~1M (≥384K for Max) | high / max | Sampling: temperature 1.0, top_p 1.0. Loves hierarchical prompts + explicit file-read order + XML-tagged sections. Caches a stable prefix well. |
| **MiniMax M3** | ~1M (≥512K guaranteed) | — | MoE 428B/22B; autonomous task decomposition; very cheap at long context — good orchestrator/subagent driver. |
| **MiMo 2.5 Pro** | ~1M (131K output) | — | MoE ~1T/42B; built for 1000+ tool-call runs; ~40–60% fewer tokens per trajectory; strong long-horizon agentic. |

## Shared guidance (applies to all of the above)

- **Big window ≠ dump everything in.** Recall, cost, and prompt-cache hit rate all degrade as a
  single trajectory bloats. Keep each unit of work's working set to a **fraction** of the
  window — see `AGENTS.md` §4b: plan long/complex work into phases of **~300k tokens** each.
- **Use the reasoning-effort tier deliberately.** Spend the **higher tier (GLM Max / DeepSeek
  max)** on *planning* and on §4a hard units (complex logic, edge cases, validation, parsers,
  money/units math). Use the **lower tier** for routine, mechanical phases — it saves real
  tokens and latency. (Some harnesses, e.g. Claude Code / OpenCode, auto-select max for agent
  loops.)
- **Protect the prompt cache.** Read the contracts and `RepoMapReadFirst.md` at session start
  and *don't churn that prefix* mid-session — stable system prompt + unchanged files + contracts
  cache across turns. (This is also why §5 forbids editing contracts inside a feature commit.)
- **Read in dependency order.** Start from entry points via `RepoMapReadFirst.md`, then domain
  modules, then utilities — don't re-walk the tree. (Helps DeepSeek especially.)
- **Delegate.** These models use subagents well. For a phase that touches ~10+ files or has 3+
  independent slices, run **Explore → Plan → Execute** with subagents (`AGENTS.md` §4b); keep
  dependent work single-session.
- **Search the web to beat your cutoff — proactively.** Open-weight models ship with a training
  cutoff and the ecosystem moves fast. Use web search (and Context7 where available) *whenever it
  helps* — current dependency versions, recent API/breaking changes, fresh error messages, new
  best practices — not only when stuck (`AGENTS.md` §4, §6a). Don't ration it; a quick search
  beats shipping against a stale API.
- **Capture learnings as prose** (`SinsGotchasLearnings.md`); skip authoring an ast-grep
  `### Audit Rule` unless the pattern is trivially structural — pattern-crafting is a token sink.
- **English, UTF-8 output** for all code/comments/commits/docs regardless of the model's
  strongest language (`AGENTS.md` §7).
- **Prune the shipped default sins early.** Delete the shipped default
  `SinsGotchasLearnings.md` entries that don't apply to your stack so the session-start index
  stays short.

## Per-model one-liners

- **GLM 5.2** — default to High for everyday edits; switch to Max for a hard phase or the plan
  step. Excellent Claude-Code-style agent.
- **DeepSeek V4 Pro** — set temperature 1.0 / top_p 1.0; give it a hierarchical prompt (framing
  → repo map → explicit read order). For Max mode, ensure the harness allots ≥384K context.
- **MiniMax M3** — lean on its task-decomposition; cheap long context makes it a good
  planner/orchestrator that fans work out to subagents.
- **MiMo 2.5 Pro** — token-efficient on long trajectories; comfortable with very long
  tool-call runs, so larger phases are fine, but still checkpoint via `STATE.md` per phase.
