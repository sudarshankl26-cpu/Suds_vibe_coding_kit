# Migrating v6 → v6.1

v6.1 is a **drop-in upgrade**: it changes the *enforcement machinery*, not your content. Your
contracts (PRD/GLOSSARY/DATA_MODEL/ARCHITECTURE), your `SinsGotchasLearnings.md` incidents,
your logs, `STATE.md`, and `src/` are all untouched. There is **no data migration**.

## Why v6.1 exists

v6 was right in spirit ("make the disciplined path the cheap path") but its enforcement layer
inverted it: agents spent ~80% of their reasoning *proving they followed the process*. Three
defects drove that, all fixed here:

1. **Timezone whack-a-mole.** The prompt-log gate compared timestamps as *naive* datetimes,
   while different tools wrote local vs UTC. Any cross-tool interleave looked "out-of-order",
   and the agent "fixed" it by **rewriting the append-only audit trail** — repeatedly.
2. **Grep audits.** A learning's audit had to be a single-line grep that matched the bug,
   dodged its own explanatory comment, and was valid in both bash and Python regex —
   impossible for multiline/CSS, so the model burned huge effort on regex design.
3. **Self-referential gates in the hot path.** `just verify` ran the task gate, so it was RED
   while the current turn's own tasks were open; the agent learned to ignore red.

## What changed (and what to swap)

| Area | v6 | v6.1 |
|---|---|---|
| Audit engine | `verification/audit_sins.{sh,py}` (generated grep) | **ast-grep** rules in `rules/*.sins.yml` |
| Audit authoring | `### Audit Recipe` (grep, required-ish) | `### Audit Rule` (ast-grep YAML, **optional**, prose-first) |
| Stale audit | hard `STALE AUDIT` failure → sync → re-verify | `audit-sins` **self-heals** (auto-regenerates) |
| `just verify` | one command, all gates (red mid-work) | **`verify`** = code gates; **`verify-all`** = + bookkeeping + smoke |
| Prompt log | agent fills "Interpreted as"/"Tasks extracted"; gate hard-fails on order/staleness | **passive evidence**; tz-aware; order/staleness are **notes** |
| Capture hooks | logged any user-role message (incl. tool echoes / file dumps) | **filter** non-prompts + size cap; offset-aware ISO timestamps |
| Tasks file | listed process steps as tasks | **deliverables only** |
| App verification | manual, usually deferred `[~]` | portable **`just smoke`** (Playwright) gate + template |
| New prereq | — | **ast-grep** (pinned in `.mise.toml`) |

### Files to replace (stock kit infra — safe to overwrite)
- `justfile`, `verify.ps1`, `scaffold.ps1`, `scaffold.sh`, `.github/workflows/verify.yml.disabled`
- `scripts/sins.py`, `scripts/extract_audits.py`, `scripts/run_gate.py`, `scripts/log_prompt.py`
- `verification/check_prompt_log.py`
- `.opencode/plugins/prompt-logger.js`, `.claude/settings.json` (unchanged, but re-copy is safe)
- `.mise.toml` (adds `ast-grep`), add `sgconfig.yml`
- **Delete** `verification/audit_sins.sh` and `verification/audit_sins.py`
- Templates/docs: `AGENTS.md` §0a/§0b/§3 wording, `CONTEXT.md`, `START_HERE.md`,
  `UserPromptLog.md`/`WorkLogAfterEachRun.md`/`OpenTasksMustCompleteAll.md` headers
- Add `skills/templates/smoke.spec.ts.template`

> Your `SinsGotchasLearnings.md` keeps all entries. Old `### Audit Recipe` grep blocks simply
> stop being auto-run (the new extractor reads `### Audit Rule`). Convert the few that are
> genuinely structural to ast-grep rules when convenient; leave the rest as prose.

## Steps

```bash
# 1. install ast-grep (one line; or `mise install` after copying the new .mise.toml)
mise use ast-grep@latest        # or: npm i -g @ast-grep/cli  / cargo install ast-grep / pip install ast-grep-cli

# 2. copy the v6.1 infra files listed above over your project (NOT your contracts/logs/STATE)
#    delete verification/audit_sins.sh and verification/audit_sins.py

# 3. reinstall the pre-commit hook so commits run the full set (or re-run the scaffold's hook step)

# 4. regenerate rules + index from your taxonomy, then confirm green
just sins-sync
just verify-all
```

If `just verify-all` is green, you're upgraded. Going forward: run `just verify` freely while
building; `just verify-all` (and the pre-commit hook) before committing.

## New habits (smaller than before)

- Don't fill prompt-log placeholders or list process steps as tasks — both are gone.
- Capture a bug as a prose `## N.` entry; add an `### Audit Rule` only if it's a clean
  structural pattern. No sync-then-re-verify dance.
- Replace deferred GUI checks with a `smoke` script (see `skills/templates/smoke.spec.ts.template`).
