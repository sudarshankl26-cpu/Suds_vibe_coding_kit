# plans/ — working plans for long/complex tasks

Dated, named plan files for one chunk of long or complex work (AGENTS.md §4b). One file per
task: `plans/<meaningful-slug>-YYYY-MM-DD.md` (copy `skills/templates/plan.md.template`).

These are **working plans**, distinct from:
- `EXECUTION_PLAN.md` — the whole-project, phase-by-phase build plan.
- `STATE.md` — the live machine-readable cursor (current phase/task).

Why they exist: large tasks blow out a single session's context budget, recall, and prompt
cache. A plan file phased to ~300k tokens/phase survives context resets and tool/subagent
handoffs, and lets independent slices fan out to subagents (Explore → Plan → Execute).

Keep finished plans here as a record, or delete them once their work is fully shipped and
captured in commits + `WorkLogAfterEachRun.md`.
