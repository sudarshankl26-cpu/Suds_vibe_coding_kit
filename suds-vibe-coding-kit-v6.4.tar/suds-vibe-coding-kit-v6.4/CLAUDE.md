# CLAUDE.md

Claude Code does not read AGENTS.md natively, so this file imports it. All actual rules
live in AGENTS.md — do not add rules here, add them there.

@AGENTS.md

## Claude-Code-only notes
- Run `just verify` (fast code gates) freely while working; run `just verify-all` before a
  commit (the pre-commit hook runs it too). Autonomous, non-interactive.
- Use Plan Mode for any task touching more than ~3 files; show the plan before editing.
- `STATE.md` is your session-start orientation file — read it first (see AGENTS.md §0).
