# UserPromptLog

Append-only record of every instruction the user gives, **verbatim**. Entries marked
`[hook:...]` were captured automatically by a tool hook (Claude Code / OpenCode), outside the
model's control, and are guaranteed verbatim. Entries marked `[agent:...]` were written by the
agent in tools without hook support (Kilo, Zed, Antigravity, Hermes, …) — there the agent
pastes the prompt verbatim inside the fence, never paraphrased, never summarized.

**This file is PASSIVE EVIDENCE — you do not maintain it.** Do not edit or delete past
entries, and **never re-stamp a timestamp**. It is an append-only audit trail for the human.
There are no "interpretation" lines to fill (that was v6 ceremony — removed in v6.1). Pull the
real tasks from the prompt straight into `OpenTasksMustCompleteAll.md`.

`just verify-all` runs `check-prompt-log`, which fails ONLY on a structurally malformed file
(a prompt with no `## <timestamp>` header). Out-of-order timestamps across tools/timezones are
a harmless note — do **not** "fix" them by rewriting entries.

---

<!-- APPEND BELOW. Newest at the bottom. Never edit entries above. -->
