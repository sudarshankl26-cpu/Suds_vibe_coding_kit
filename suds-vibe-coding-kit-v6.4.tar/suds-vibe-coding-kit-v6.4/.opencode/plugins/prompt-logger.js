// prompt-logger.js — deterministic verbatim prompt capture for OpenCode (v6.1).
// Lives in .opencode/plugins/ so it loads automatically at startup.
// Mirrors what the Claude Code UserPromptSubmit hook does: every *genuine* user message is
// appended verbatim to UserPromptLog.md OUTSIDE the model's control, so capture never stops
// and is never paraphrased. The log is PASSIVE evidence — the agent never edits it.
//
// v6.1 changes (fixing the two v6 defects observed in real logs):
//   1. OFFSET-AWARE timestamps (`2026-06-18T12:06:03+05:30`) instead of UTC `Z`, so this and
//      the Python/Claude hook write the same format and cross-tool entries never look
//      "out-of-order".
//   2. NON-PROMPT GUARD + SIZE CAP: tool-call/result echoes and pasted file dumps are skipped;
//      oversized bodies are head-truncated. (v6 logged 200-line file reads as "prompts",
//      bloating the file the agent re-reads each session.)

import fs from "node:fs"
import path from "node:path"

const MAX_CHARS = 4000

const HEADER = `# UserPromptLog

Append-only record of every instruction the user gives, **verbatim**. Entries marked
\`[hook:...]\` were captured automatically by a tool hook (outside the model's control) and are
guaranteed verbatim.

This file is PASSIVE EVIDENCE. **Never edit or delete past entries, and never re-stamp a
timestamp** — it is an append-only audit trail.

---

<!-- APPEND BELOW. Newest at the bottom. Never edit entries above. -->
`

// Patterns that mark a message as a tool echo / pasted file content, not a user prompt.
const NON_PROMPT = [
  /^\s*Called the .{1,60}? tool with/i,
  /^\s*<(path|content|type|file_contents|environment_details)\b/i,
  /<\/(content|file_contents|environment_details)>\s*$/i,
  /^\s*\{["']?(filePath|file_path|path)["']?\s*:/i,
  /^\s*(tool_result|function_results|<tool_use_error>)/i,
]

function isNonPrompt(text) {
  const head = text.replace(/^\s+/, "").split("\n").slice(0, 3).join("\n")
  return NON_PROMPT.some((re) => re.test(head))
}

function clamp(text) {
  if (text.length <= MAX_CHARS) return text
  return text.slice(0, MAX_CHARS) + `\n…[truncated ${text.length - MAX_CHARS} chars by prompt-logger]`
}

// Local offset-aware ISO, seconds precision: 2026-06-18T12:06:03+05:30
function localIso(d = new Date()) {
  const pad = (n) => String(n).padStart(2, "0")
  const off = -d.getTimezoneOffset()
  const sign = off >= 0 ? "+" : "-"
  const abs = Math.abs(off)
  return (
    `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` +
    `T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}` +
    `${sign}${pad(Math.floor(abs / 60))}:${pad(abs % 60)}`
  )
}

function fenceFor(text) {
  let f = "~~~"
  while (text.includes(f)) f += "~"
  return f
}

function lastLoggedPrompt(text) {
  const blocks = [...text.matchAll(/^(~~~+)\w*\n([\s\S]*?)^\1\s*$/gm)]
  return blocks.length ? blocks[blocks.length - 1][2].trim() : ""
}

function extractText(message, parts) {
  const fromParts = (parts || [])
    .filter((p) => p && p.type === "text" && typeof p.text === "string")
    .map((p) => p.text)
    .join("\n")
    .trim()
  if (fromParts) return fromParts
  if (typeof message?.content === "string") return message.content.trim()
  return ""
}

export const PromptLogger = async ({ directory }) => {
  return {
    // Fires when a chat message is created. We only log genuine user-authored prompts.
    "chat.message": async (_input, output) => {
      try {
        const msg = output?.message
        if (!msg) return
        if (msg.role && msg.role !== "user") return
        let text = extractText(msg, output?.parts)
        if (!text) return
        if (isNonPrompt(text)) return // tool echo / pasted file content — not an instruction
        text = clamp(text)

        const file = path.join(directory || process.cwd(), "UserPromptLog.md")
        let existing = ""
        if (fs.existsSync(file)) {
          existing = fs.readFileSync(file, "utf8")
        } else {
          fs.writeFileSync(file, HEADER, "utf8")
          existing = HEADER
        }
        if (lastLoggedPrompt(existing) === text) return // duplicate fire guard

        const f = fenceFor(text)
        const entry =
          `\n## ${localIso()} — [hook:opencode]\n` +
          `**Prompt (verbatim):**\n${f}text\n${text}\n${f}\n`
        fs.appendFileSync(file, entry, "utf8")
      } catch (e) {
        // Never break the session over logging — but never swallow silently either.
        console.error("[prompt-logger] non-fatal:", e?.message || e)
      }
    },
  }
}
