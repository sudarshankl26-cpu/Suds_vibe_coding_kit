# OpenAI Codex CLI — pointer only

Codex CLI reads **`AGENTS.md`** at the repo root **natively** — that is the single source of
truth for all rules (it's the same AGENTS.md every other tool here points to). There are no
Codex-specific rules, and none should be added here: duplicating rules would let them drift.

On session start, Codex should read, in order: `STATE.md` (orient) → `AGENTS.md` (rules) → the
contracts AGENTS.md lists. Codex has no prompt-capture hook, so AGENTS.md §0a applies in its
manual form: append every user instruction to `UserPromptLog.md` verbatim (inside the `~~~text`
fence, exactly as typed) before starting work.
