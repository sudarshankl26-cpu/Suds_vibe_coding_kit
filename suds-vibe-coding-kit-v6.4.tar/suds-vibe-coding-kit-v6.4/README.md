# Sud's Vibe Coding Kit (v6.4)

> **New in v6.4 — inline flags, reuse-first, an anti-AI-slop design standard, and a friendlier
> on-ramp.** All prose-only — no new gates, no new machinery: **§1a inline flags**
> (`#EXPORT_CRITICAL` / `#PLAN_UNCERTAINTY` / `#PATH_DECISION`) threaded through the templates,
> grill, and §H/§I prompts; a **§2 reuse-before-reinvent** anti-pattern; a built-in
> **`DESIGN_GUIDELINES.md`** so any UI looks *decided*, not AI-generated (one icon set, a neutral
> base + one accent, a real type hierarchy — copy-paste build prompt in `PROMPTS.md` §Q); plus a
> beginner **"Start here"** onboarding, OpenAI **Codex** support (`.codex/`), and a graphical
> **`GITHUB_README.md`**. Prompts: `PROMPTS.md` §P / §Q.

> **New in v6.3 — tuned for 1M-context open-weight models + phased planning.** Adds (all
> suggestions, no new gates): a **§4b planning protocol** — for long/complex work, write a dated
> plan file (`plans/<slug>-YYYY-MM-DD.md`), phase it to **~300k tokens/phase**, and delegate
> independent slices to **subagents** (Explore → Plan → Execute) where the tool supports it; a
> new **`MODEL_NOTES.md`** with per-model operating tips (context budget, reasoning-effort
> tiers) for GLM 5.2 / DeepSeek V4 Pro / MiniMax M3 / MiMo 2.5 Pro; an **English/UTF-8 output**
> rule; a refined **§6a** ladder that **encourages web search / Context7 — proactively** — to
> beat the model's knowledge cutoff (current versions, recent API changes); and a prune-defaults
> nudge. Prompts: `PROMPTS.md` §N/§O.

> **New in v6.2 — eval-first for hard parts + an anti-thrash ladder.** Two *suggestions* (not
> gates) added to `AGENTS.md`, both true to v6.1's "gate the product, not the process": (1)
> **§4a eval-first** — for genuinely hard units (complex logic, edge cases, validation, parsers,
> money/units math), write the edge-case tests *first*, then implement until `just verify` is
> green (the existing `test` gate does the enforcing — no new gate); (2) **§6a escalation
> ladder** — after ~3 failed attempts on the same test/error, stop guessing and autonomously
> consult whatever's available (LSP/type diagnostics, Context7 MCP, web search, a `verify_<lib>`
> probe). Purely additive — upgrading from v6.1 is just refreshing `AGENTS.md`. Prompts: see
> `PROMPTS.md` §L/§M.

> **New in v6.1 — the overhead is gone.** v6 was correct in spirit but its enforcement layer
> made the agent spend ~80% of its reasoning *proving it followed the process* (timestamp
> whack-a-mole, regex rabbit holes, self-referential gates). v6.1 keeps every safeguard's
> intent and removes the make-work. See `MIGRATION_v6.1.md` for the full list and how to
> upgrade a v6 project in place. Highlights:
>
> - **AST audits instead of grep (ast-grep).** The defect taxonomy now compiles to
>   `ast-grep` rules (`rules/*.sins.yml`), not single-line grep. Patterns are multiline,
>   structural, language-aware (incl. **CSS**), and **can't match their own explanatory
>   comment** — the exact thing that caused 15-minute regex detours. Pinned via `mise`
>   (native Windows binary); the old dual `audit_sins.{sh,py}` codegen is gone.
> - **`just verify` splits.** `just verify` = code/correctness gates only (lint, types, tests,
>   library checks, schema, sins audit, dox) — stays green while you build, so you can trust
>   it as a sanity check. `just verify-all` adds the bookkeeping gates + an app smoke test and
>   is what the pre-commit hook / CI run.
> - **Logs are passive evidence.** Prompt capture is timezone-aware and only logs *genuine
>   prompts* (tool-echoes and pasted file dumps are filtered). The agent never edits the log
>   or re-stamps timestamps; cross-tool out-of-order is a harmless note, not a build failure.
> - **No more STALE AUDIT loop.** `just audit-sins` self-heals — it regenerates the rules when
>   the taxonomy changes, so capturing a learning never triggers a sync-then-re-verify dance.
> - **Learnings steer from the get-go.** `AGENTS.md` §0b carries an always-on digest of the
>   highest-leverage failure modes; the full taxonomy stays on-demand via the index.
> - **Run & observe the app.** A portable Playwright `smoke` gate + template replaces the v6
>   habit of deferring every GUI check as "[~] can't verify".

> **Inherited from v6:** deterministic verbatim prompt capture via tool hooks
> (`.claude/settings.json`, `.opencode/plugins/prompt-logger.js`); the debranded
> defect taxonomy; tool pointers for `.kilocode/`, `GEMINI.md` (Antigravity), `.rules` (Zed).

A set of project artifacts that prevents the mistakes LLM coding agents make, **and** an
enforcement layer that makes the prevention automatic instead of hopeful. Built for a
multi-tool workflow (Claude Code, Kilo/VSCodium, Zed, OpenCode, Windsurf, Antigravity,
Hermes, and others) on Windows 11 + WSL.

---

## ⭐ The workflow (read this first)

This is the exact loop the kit is built around. Follow it every time:

1. **Create a new folder. Rename it to your project name.** (e.g. `my-cool-dashboard`)
2. **Extract the kit files into it** — directly, no sub-folder. The folder you just named
   IS the project root.
3. **Double-click `scaffold.ps1`** (or, in WSL, `bash scaffold.sh`). This runs the
   non-agent-friendly bootstrap *once, in place*: installs the toolchain (via `mise`),
   inits git + the verification hooks, generates the audit/index/map, makes the first
   commit, and prints your next prompt. It does **not** create a sub-folder.
4. **Open your coding agent in that folder** (any of: OpenCode, Zed, Kilo in VSCodium,
   Windsurf/Devin, Claude Code, Antigravity, Hermes, Minimax, …) and paste this:

   > *Read CONTEXT.md and the files it lists. Then run the grill-to-prd skill
   > (skills/grill-to-prd.md): interview me ONE question at a time until the design is
   > fully resolved, recommending an answer for each. Do NOT write code or scaffold
   > anything yet — only interview, then produce PRD.md when done.*

5. **Answer the grill** (one question at a time; it ends by asking your dev port and
   recommending a random non-standard one). It produces `PRD.md`, then the rest of the
   contracts, then builds phase by phase.
6. **At the end**, the agent generates `start-server.ps1` / `stop-server.ps1` in the root
   (you double-click to run/stop your app).

**The one prerequisite you install once, ever:** [`mise`](https://mise.jdx.dev/installing-mise.html).
On Windows: `winget install jdx.mise`. In WSL: `curl https://mise.run | sh`. Everything
else (`just`, `uv`, `node`, `pnpm`) is installed automatically by the scaffold. If `mise`
is missing, the scaffold still runs and tells you exactly what to install.

> **Note:** As of v6, `pnpm` is installed directly by `mise` — no `corepack` needed. This
> fixes the `corepack is not recognized` error on Node.js 22+ where corepack was removed.

> **Why a scaffold script instead of asking the agent to set up?** Agents are bad at
> imperative shell orchestration with error recovery — that's what made them loop on
> setup. The deterministic, double-clickable script does the mechanical bootstrap; the
> agent does what it's good at (the grill, then the build).

---

## What the kit gives you (the mechanisms)

Three problems with the "just write good docs and tell the agent to read them" approach, and
the mechanism that fixes each:

1. **Config duplication across tools → drift.** Every tool wants rules in its own file.
   Copies drift. **Fix:** `AGENTS.md` is the single source of truth; `CLAUDE.md`,
   `.windsurfrules`, `.cursor/rules/`, `.zed/` are *pointers* containing zero rules, so they
   can't drift.

2. **Re-reading everything every session → token waste.** **Fix:** state lives in `STATE.md`
   (machine-readable, ~200 tokens), separate from the plan. Agents orient from it, not by
   re-ingesting 2,000-line plans.

3. **Your best knowledge is unenforceable prose.** A 5,000-line "lessons learned" file the
   agent is asked to "keep in mind" is a token sink and gets read shallowly. **Fix:** the
   three-tier Sins & Gotchas system below.

## The Sins & Gotchas system (the core upgrade)

Most hard-won lessons are *deterministic checks* trapped in prose. This kit splits them by
enforceability:

- **Tier 1 — Executable (ast-grep, v6.1).** A `SinsGotchasLearnings.md` entry may carry an
  `### Audit Rule` (an `ast-grep` YAML pattern). `just audit-sins` compiles them to
  `rules/*.sins.yml` and runs `ast-grep scan` on every commit — AST-based, so it handles
  multiline/CSS/structural patterns that line-grep never could, and never matches its own
  comment. Rules are **optional**: add one only when the defect is genuinely structural;
  otherwise the lesson lives as prose (most do).
- **Tier 2 — Loadable index.** `build_sins_index.py` collapses the full file to
  `SinsGotchasLearnings_INDEX.md` (one line per incident). Agents read the index at session start and
  open full entries only on demand. (Tested: 5,701 lines → 96.) The very top of the list (the
  highest-leverage behavioral lessons) is mirrored into `AGENTS.md` §0b so it's always loaded.
- **Tier 3 — Reconciliation.** `PROMPTS.md` §H and §K force the docs to update themselves
  after each phase / bug, so they don't ossify into stale "lore."

The promotion principle: every lesson should be pushed to the most automatic enforcement
layer it can reach — `tsc`/`mypy` type > ast-grep rule > prose. Prose is the common form for
capture, and the last resort for *enforcement*.

## v3 additions (cross-platform + data layer)

- **Single cross-platform audit runner (v6.1).** `ast-grep` is one native binary that runs
  identically on Windows, WSL, mac, and Linux — so the v3 dual `audit_sins.{sh,py}` codegen is
  gone. `just audit-sins` self-heals (regenerates `rules/` if the taxonomy changed) and runs
  `ast-grep scan`.
- **Per-line escape hatch.** Put `# ast-grep-ignore` / `// ast-grep-ignore` on the line above
  an approved exception instead of deleting the rule.
- **Runtime data-contract guard.** `verification/audit_schema.py` checks the live DB against
  declarative rules in `types/schema_rules.json` (required tables, fraction-scale columns).
  Catches the 0-1-vs-0-100 and missing-table bug classes a code scan can't see. No-ops with
  no DB/config, so non-DB projects are unaffected.
- **Optional CI.** `.github/workflows/verify.yml.disabled` — rename to enable a server-side
  gate when you have collaborators. Not needed for solo local work (the pre-commit hook
  already runs `just verify`).

## v4 additions (alignment, anti-drop, traceability, re-orientation)

Four mechanisms, all file-based and (where enforceable) gated:

- **`RepoMapReadFirst.md`** — living codebase map (generated skeleton + curated "start
  here"). Agents read it instead of re-walking hundreds of files every cold session
  (~2k tokens vs 50k+). `just map-sync` regenerates; the curated block is preserved.
- **`OpenTasksMustCompleteAll.md` + `check-tasks` gate** — the anti-drop mechanism. Every
  instruction's tasks are logged as `[ ]`; `just verify` FAILS while any task is unresolved
  or deferred/blocked without a reason. Stops "given 3 tasks, did 2."
- **`UserPromptLog.md` + `WorkLogAfterEachRun.md`** — append-only traceability. What was
  asked vs what was delivered, so you can trace a wrong order or unfinished work, and study
  your own prompting patterns. Live-appended by the agent; a git post-commit hook is the
  backstop so the trail survives even if the agent forgets.
- **`skills/grill-to-prd.md`** — relentless one-question-at-a-time requirement interview
  (adapted from Matt Pocock's grill-with-docs), updating GLOSSARY.md inline and offering
  ADRs (`docs/adr/`) only for hard-to-reverse decisions. Run it before writing PRD.md.

### Naming philosophy

Filenames are part of the prompt. Evocative, purpose-revealing names (SinsGotchasLearnings,
OpenTasksMustCompleteAll, RepoMapReadFirst) prime the model toward the right behavior better
than bland ones (learnings, tasks, structure). Cadence is encoded where it helps
(...AfterEachRun, ...ReadFirst, ...MustCompleteAll). Ecosystem-standard files (AGENTS.md,
CLAUDE.md, README.md, CONTEXT.md) and already-clear convention files (PRD, GLOSSARY,
DATA_MODEL, ARCHITECTURE) are NOT renamed — tools match them by literal string, and an LLM
already maps "glossary" correctly.

## Order of authoring (unchanged, still matters)

1. `PRD.md` → 2. `GLOSSARY.md` → 3. `DATA_MODEL.md` → 4. `ARCHITECTURE.md` →
5. `AGENTS.md` → 6. `EXECUTION_PLAN.md`. Files 1–4 are *what's built*; 5–6 are *how the
agent builds*. `SinsGotchasLearnings.md` grows during the build, not before it.

## Files

| File | Purpose |
|---|---|
| `CONTEXT.md` | Pure routing entry point (no rules → can't drift) |
| `AGENTS.md` | **Single source of truth** for agent rules |
| `CLAUDE.md`, `.windsurfrules`, `.cursor/rules/`, `.zed/` | Pointers to AGENTS.md |
| `STATE.md` | Machine-readable build state; cross-tool/session handoff (agent-owned) |
| `PRD / GLOSSARY / DATA_MODEL / ARCHITECTURE` | The contracts (immutable in-phase) |
| `EXECUTION_PLAN.md` | Phased plan (state lives in STATE.md, not here) |
| `SinsGotchasLearnings.md` | Incident-indexed defect taxonomy (source for the two generated files) |
| `SinsGotchasLearnings_INDEX.md` | *Generated* — loadable index |
| `rules/*.sins.yml` + `sgconfig.yml` | *Generated* — ast-grep rules from the taxonomy + its config |
| `verification/verify_*.{py,ts}` | Library-API checks (run before relying on a new lib) |
| `types/` | Code-level contracts (`models.py`, `schema.ts`) |
| `tests/fixtures/` | Canonical inputs with planted bugs |
| `justfile` | `just verify` = code gates (mid-work); `just verify-all` = + bookkeeping + smoke |
| `scripts/` | The learnings generators (rules + index) and gate helpers |
| `skills/templates/smoke.spec.ts.template` | Playwright "run & observe the app" gate template |
| `scaffold.ps1` / `scaffold.sh` | In-place bootstrap (double-click; run once); strips itself after running |
| `.mise.toml` | Toolchain pin (`just`/`uv`/`node`/`pnpm`); `mise install` provisions all |
| `.env.example` | The `PORT` contract (single source of truth) — copy to `.env` |
| `skills/templates/` | start/stop server `.ps1` templates the agent fills per-project |
| `PROMPTS.md` | Reusable prompts for every lifecycle stage |
| `MODEL_NOTES.md` | Per-model operating tips (context budget, reasoning-effort tiers) for non-frontier models |
| `plans/` + `skills/templates/plan.md.template` | Dated working plans for long/complex tasks (AGENTS.md §4b) |

## v5 additions (carried forward)

- **In-place scaffold, no sub-folder.** `scaffold.ps1`/`scaffold.sh` set up the project in
  the folder you already named — replacing the old `setup.sh my-app` flow that created a
  nested `my-app/`. Idempotent (safe to double-click twice), self-diagnosing, and it ends by
  printing your next prompt.
- **One-prerequisite toolchain via `mise`.** `.mise.toml` pins `just`/`uv`/`node`/`pnpm`;
  the scaffold runs `mise install`. Fixes the "agent loops because `just` isn't installed"
  failure at the root. Graceful degradation if `mise` is absent.
- **Shipped, debranded default learnings.** `SinsGotchasLearnings.md` now ships with ~24
  universal defect classes (silent zeros, `?? 0` masking, average-of-averages, 0–1 vs 0–100
  scale, cancel-out rounding, swallowed exceptions, SWR retry storms, regex-on-structured-text,
  port triple-definition, …) — ON by default so the agent avoids them rather than waiting to
  hit them. **Balanced policy:** unambiguous patterns are hard gates; broad ones report as
  informational notes (so day-1 false positives don't train you to `--no-verify`). The
  single highest-leverage one is §2: *every value shown to a user must trace to live data.*
- **Port as a contract.** The grill asks your dev port at the end and recommends a random
  non-standard one; it lives once in `.env` as `PORT`, read by everything. No hardcoded ports.
- **Generated server scripts.** `skills/templates/start-server.ps1.template` +
  `stop-server.ps1.template` → the agent fills them per-project (stack + port from `.env`) in
  the final execution phase. Kill-by-port stop; double-clickable.
- **Encoding-bug fix.** The index generator now forces UTF-8 on read and stdout, fixing the
  Windows mojibake (`┬º`/`ΓÜÖ` → `§`/`⚙`). The audit generator now validates each pattern and
  skips+warns on a non-Python-safe recipe instead of emitting a runner that crashes.
- **Rebranded** to *Sud's Vibe Coding Kit* throughout.
- **Portable justfile + PowerShell fallback.** Recipes now run on native Windows PowerShell
  *and* bash/WSL (`set windows-shell` + Python-helper one-liners, no `#!` shebangs, so no
  `cygpath` needed). If you have no `just` at all, `verify.ps1` and `sync.ps1` run the full
  gate with just PowerShell + Python. `verify-libs` skips a library check whose target isn't
  installed (no day-1 false failures) but still fails on real API drift.

> **Windows `just` gotcha:** if `just --version` shows a Python traceback, a pip package
> named `just` is shadowing the real tool — `pip uninstall just`, then install the real one
> (`mise use -g just@latest` or `winget install --id Casey.Just`). If you see a `cygpath`
> error, you're on an old justfile; this current one doesn't need it. Either way, `verify.ps1` /
> `sync.ps1` work regardless.

## Upgrading an existing kit project

**Already on v6?** It's a drop-in swap of ~15 infra files — see `MIGRATION_v6.1.md`. For
v4/v5 projects, use the migrator below. Either way, see `ADOPT_AND_UPGRADE_v6.1.md` for the
full copy-paste PowerShell walkthrough.

If you have ongoing projects on v4/v5, **don't** hand the tar to your agent and say "update to
the latest" — a blind file copy either destroys your accumulated state (your filled-in contracts,
real `SinsGotchasLearnings.md` incidents, logs) or denies you the latest fixes. Use the migrator
shipped in `migrate/`, which classifies every file and only auto-replaces stock-v4
infrastructure (verified by hash), preserving everything you've created:

```bash
# 1. unpack the kit OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.4.tar -C /tmp/
# 2. from inside your project: see the plan (changes nothing)
python /tmp/suds-vibe-coding-kit-v6.4/migrate/migrate_kit.py --kit /tmp/suds-vibe-coding-kit-v6.4 --plan
# 3. apply (git branch + backup first; stages judgment-call merges as *.kit-incoming)
python /tmp/suds-vibe-coding-kit-v6.4/migrate/migrate_kit.py --kit /tmp/suds-vibe-coding-kit-v6.4 --apply
```

Then have your agent follow `migrate/MIGRATION.md` to resolve each `*.kit-incoming` one at a
time (it walks you through diffs and recommendations). The SinsGotchas merge is automated by
`migrate/merge_sins.py` (keeps your incidents first, appends the kit's generics renumbered,
skips duplicates). Finish with `mise install && just sins-sync && just verify-all`. Fully
reversible via the backup folder or the git branch.

## Quick start (new project)

```powershell
# 1. make a folder, name it your project, extract the kit files into it (no sub-folder)
# 2. bootstrap (double-click, or):
powershell -ExecutionPolicy Bypass -File .\scaffold.ps1      # Windows
# bash scaffold.sh                                            # WSL / Claude Code
# 3. open your agent in this folder and paste the grill prompt it printed
# 4. just verify       # mid-work: lint + types + tests + library checks + ast-grep sins audit
# 5. just verify-all   # before committing: + task gate + prompt-log + app smoke (pre-commit runs this)
```

## Daily loop

- Start: `just state` (or the §F prompt) → resume from STATE.md.
- While building: `just verify` freely (fast code gates; stays green) — trust it, don't re-audit by hand.
- Hit a bug: fix it, add a `SinsGotchasLearnings.md` entry (prose; an ast-grep `### Audit Rule` only if structural). No sync dance — `audit-sins` self-heals.
- End of phase: §H prompt → docs reconciled, STATE.md updated, repo left `just verify-all`-green.

## When to skip files

- Throwaway script (<200 lines): `PRD.md` + `AGENTS.md`.
- Prototype with state: add `GLOSSARY.md` + `DATA_MODEL.md`.
- `SinsGotchasLearnings.md` only earns its keep once the project is long-lived enough to hit repeat bugs.

## Supported tools & models

### Coding agents (tested)
| Tool | Platform | Config file |
|---|---|---|
| OpenCode Desktop | Windows | `.opencode/` |
| Kilocode (VSCodium extension) | Windows | `.kilocode/` |
| Zed | Windows/WSL | `.zed/` |
| Antigravity | Windows | `GEMINI.md` |
| OpenAI Codex CLI | Win/WSL/macOS | `.codex/` (reads AGENTS.md) |
| Hermes Agent Desktop | Windows | (reads AGENTS.md) |
| Stagewise | Windows | (reads AGENTS.md) |
| Claude Code | WSL/macOS | `.claude/` |
| Windsurf/Devin | Windows | `.windsurfrules` |
| Cursor | Windows | `.cursor/rules/` |

### LLM models (tested with the kit)
- GLM 5.2
- Deepseek v4 Pro
- Xiaomi Mimo v2.5 Pro
- Minimax M3
- Claude (Anthropic)
- Gemini 2.5 Flash

All rules live in `AGENTS.md` — any tool that reads it works. The per-tool files are
zero-rule pointers, so they can't drift from the source of truth. For non-frontier /
open-weight models (GLM, DeepSeek, MiniMax, MiMo), see **`MODEL_NOTES.md`** for context-budget,
reasoning-effort, and subagent-delegation tips (v6.3).
