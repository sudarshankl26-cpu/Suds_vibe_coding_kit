# Canonical rules live in /AGENTS.md

Kilo reads AGENTS.md natively; this stub force-loads the pointer for older builds.
Read, in order: STATE.md (orient), AGENTS.md (rules), then the contracts it lists.

**Kilo has no prompt-capture hooks**, so AGENTS.md §0a applies in its manual form:
append every user instruction to UserPromptLog.md VERBATIM (inside the ~~~text fence,
exactly as typed) before starting work. `just verify` fails if the log goes stale.

Do not restate rules here — they would drift from AGENTS.md.
