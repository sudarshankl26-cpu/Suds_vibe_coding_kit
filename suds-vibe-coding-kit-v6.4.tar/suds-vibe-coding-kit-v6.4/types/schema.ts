// Code-level type contracts (TypeScript). DATA_MODEL.md is prose; this enforces.
//
// PLACEHOLDER example showing the patterns AGENTS.md relies on:
//   1. A discriminated union instead of a stringly-typed status field.
//   2. A canonical constructor so objects are never assembled inline.
// Replace `Example` with your real entities. Delete this comment when you do.

export type ExampleStatus = "active" | "archived" | "pending";

export interface Example {
  readonly id: string;
  readonly name: string;
  readonly status: ExampleStatus;
  readonly value: number | null; // null = not yet computed (see DATA_MODEL.md)
}

// Canonical constructor — do not assemble Example objects inline elsewhere.
export const makeExampleId = (name: string): string =>
  `example:${name.toLowerCase().trim()}`;

export const createExample = (
  name: string,
  status: ExampleStatus,
  value: number | null = null,
): Example => ({ id: makeExampleId(name), name, status, value });
