"""Code-level type contracts (Python). DATA_MODEL.md is the prose; this is the enforcement.

This is a PLACEHOLDER example showing the two patterns AGENTS.md relies on:
  1. A canonical constructor/helper, so entities are never built ad hoc (AGENTS.md §2).
  2. Modern type syntax (X | None, list[X]) — no typing.Optional/List.
Replace `Example` with your real entities. Delete this comment when you do.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone


@dataclass(frozen=True, slots=True)
class Example:
    id: str
    name: str
    value: float | None  # None = not yet computed (see DATA_MODEL.md NULL semantics)

    @staticmethod
    def make_id(name: str) -> str:
        # Canonical id construction. Never build Example ids any other way.
        return f"example:{name.lower().strip()}"

    @classmethod
    def create(cls, name: str, value: float | None = None) -> "Example":
        return cls(id=cls.make_id(name), name=name, value=value)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)
