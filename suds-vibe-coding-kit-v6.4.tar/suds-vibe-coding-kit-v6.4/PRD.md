# PRD — [Project Name]

> Fill in every [placeholder]. Delete sections that genuinely don't apply, but think twice — most apply to most projects.

---

## 1. One-sentence pitch

[What this is, in one sentence. If you can't write this, the project isn't well-scoped enough to build yet.]

## 2. The problem

[What's broken in the world right now? Who suffers from it? Be specific — "developers waste time" is not a problem; "developers waste 30 minutes per day reformatting CSV exports because no tool handles the European decimal format" is.]

## 3. Who this is for

- **Primary user:** [Specific role / persona.]
- **Sometimes:** [Adjacent users who might benefit.]
- **Explicitly NOT for:** [Categories of users this is *not* trying to serve. Important — keeps scope honest.]

## 4. What it does (capabilities)

The shipped product can:

- [Capability 1 — verb + object + qualifier. Example: "Audit a project's SQL files for fanout joins."]
- [Capability 2]
- [Capability 3]
- [...]

Each capability should map to at least one phase in EXECUTION_PLAN.md.

## 5. What it deliberately does NOT do (anti-goals)

The shipped product does NOT:

- [Anti-goal 1 — what you're explicitly choosing not to build. Example: "Auto-apply patches; the tool only suggests."]
- [Anti-goal 2]
- [Anti-goal 3]

This section is more important than capabilities. It's what keeps the agent from drifting into scope creep.

> Tag any anti-goal or rule that must never be silently crossed with **`#EXPORT_CRITICAL`** (AGENTS.md §1a) — the agent treats those as non-negotiable and will stop and ask before touching them.

## 6. Success criteria

You will know v1 is successful when:

- [Concrete, measurable criterion 1. Example: "Running the tool on my 3 most complex apps catches at least one real bug I didn't already know about."]
- [Concrete, measurable criterion 2.]
- [Concrete, measurable criterion 3.]

Vague success criteria ("users love it") produce vague software. If you can't define success concretely, define it concretely *enough* to ship one version, knowing it will evolve.

## 7. Out of scope for v1

Features that are explicitly v2+:

- [Future feature 1.]
- [Future feature 2.]

If the agent suggests building one of these in v1, point at this list.

## 8. Constraints

- **Performance:** [What's the latency / throughput budget?]
- **Cost:** [Hard budget on infrastructure, API spend, etc.?]
- **Privacy / security:** [Any constraints on data handling?]  *(tag hard limits `#EXPORT_CRITICAL`)*
- **Platform:** [Specific OS, browser, runtime requirements?]
- **Distribution:** [Solo use, sharing with friends, public release?]

## 9. Open questions

[Genuinely unanswered things. Different from "TODO." These are things you need to decide before or during the build. If the agent has to assume one of these to keep moving, it leaves a **`#PLAN_UNCERTAINTY`** tag at the assumption (AGENTS.md §1a) and resolves it before the phase is done.]

- [ ] [Question 1.]
- [ ] [Question 2.]

## 10. Glossary

The full glossary lives in GLOSSARY.md. List here only the terms that appear in this PRD for cross-reference.

- **[Term 1]** — see GLOSSARY.md
- **[Term 2]** — see GLOSSARY.md
