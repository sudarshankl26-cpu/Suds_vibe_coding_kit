# ARCHITECTURE

How the pieces fit together. Read after PRD/GLOSSARY/DATA_MODEL — this answers "how", not "what" or "why."

---

## 1. Components

[List the major components. For each: one sentence on what it does. Be specific — "the backend" is not a component; "FastAPI server exposing /api/* and serving the React SPA from /" is.]

- **[Component 1]:** [Role.]
- **[Component 2]:** [Role.]
- **[Component 3]:** [Role.]

## 2. Data flow

[How does a request / event flow through the components? Number the steps. Optionally a diagram.]

1. User opens UI → React fetches `/api/foo`
2. FastAPI handler reads from SQLite, calls `module_x.do_thing()`
3. `module_x` returns a `Result` object
4. FastAPI serializes `Result` to JSON, returns to React
5. React renders.

For event-driven flows or batch flows, document them separately.

## 3. Technology choices and rationale

Each major choice with the reasoning. "We chose X because [non-obvious reason]." This document is for future-you, and for the agent that might otherwise suggest swapping.

| Choice | What | Why |
|---|---|---|
| Backend | [e.g. FastAPI / Express / Rails] | [Reason — likely the most important column] |
| Frontend | [React + Vite / SvelteKit / plain HTML] | [Reason] |
| DB | [SQLite / Postgres / DuckDB] | [Reason] |
| State mgmt | [None / Redux / Zustand / Tanstack Query] | [Reason] |
| Styling | [Tailwind / CSS Modules / vanilla] | [Reason] |
| Build / packaging | [uv + pipx / npm / Docker] | [Reason] |
| Testing | [pytest / vitest / jest] | [Reason] |
| LLM provider | [DeepSeek / OpenAI / Anthropic / local] | [Reason] |

If you change one of these mid-project, that's a separate commit modifying this file with a CHANGE: note.

## 4. Anti-goals (non-decisions)

What we are explicitly choosing NOT to do, and why. The agent will sometimes suggest these — point at this section.

- **No [pattern X]:** [Reason. Example: "No microservices — single-process app, deployment simplicity beats theoretical scaling."]
- **No [feature Y]:** [Reason. Example: "No real-time sync — it's a tool used by one person at a time."]
- **No [framework Z]:** [Reason.]

## 5. Trust boundaries

Where can untrusted data enter the system, and how is it sanitized?

- **User input from web UI:** [Validated at the API boundary by Pydantic schemas / Zod / etc.]
- **File uploads:** [Validated for type, size, contents. Path-traversal protection.]
- **LLM responses:** [Always validated against a JSON schema. Never executed as code.]
- **Third-party API responses:** [Validated; failures handled.]

If the app has any cross-user data (multi-tenant), this section also lists how tenant isolation is enforced.

## 6. Failure modes

What can go wrong, what happens when it does, and what the user sees.

| Failure | Detection | Behavior | User-visible |
|---|---|---|---|
| DB locked | [How detected] | [Action] | [Message shown] |
| LLM API down | Connection error | Skip LLM detectors; finish run | "LLM unavailable; deterministic checks only" |
| File parse error | sqlglot ParseError | Record as parse_failure finding | Coverage warning in UI |
| Out of budget | Counter exceeds cap | Stop LLM calls; emit budget-exhausted finding | "Budget hit; N detectors skipped" |

## 7. Performance budgets

| Operation | Budget | Why |
|---|---|---|
| [e.g. Full audit on medium project (100 SQL files)] | [<60s] | [Interactive feel] |
| [API response] | [<200ms p95] | [Snappy UI] |
| [Cold start] | [<3s] | [Solo dev workflow] |

If an operation exceeds budget, that's a bug — not a feature.

## 8. Out-of-scope architectural concerns

Things this document doesn't cover and won't be planned for in v1:

- [Multi-region deployment]
- [Horizontal scaling]
- [Real-time collaboration]
- [Mobile native apps]
