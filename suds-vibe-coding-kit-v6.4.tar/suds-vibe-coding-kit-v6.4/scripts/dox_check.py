#!/usr/bin/env python3
"""
dox_check.py — enforce the integrity of an OPTIONAL hierarchical AGENTS.md layer.

The kit's root AGENTS.md is the single source of truth for GLOBAL rules. For larger,
modular repos you may add a child AGENTS.md inside a durable subsystem folder (e.g.
backend/, frontend/, etl/). Child docs hold LOCAL contracts only — they must point back to
root for global rules and may only ADD constraints, never weaken a root rule.

DOX (the framework this is inspired by) states these as prose discipline. This script makes
them an enforced gate, which is the kit's whole philosophy: push every rule to the most
automatic enforcement layer it can reach.

Checks (each a hard failure unless noted):
  1. INDEXED      — every non-root AGENTS.md is listed in the "Child DOX Index" of the
                    NEAREST ancestor AGENTS.md.
  2. POINTS-TO-ROOT — every child AGENTS.md contains the marker line declaring root as the
                    source of global rules (default: a line containing "global rules" and
                    "root AGENTS.md", case-insensitive). Keeps children from re-stating
                    global rules (which would drift).
  3. NO-WEAKEN    — a child must not re-permit something the root forbids. Heuristic: for
                    each root "❌ <thing>" anti-pattern, if a child says "✅ <same thing>"
                    or "allowed"/"ok to" + that thing, fail. (Best-effort; catches the
                    obvious reversals DOX only warns about in prose.)
  4. SHAPE        — informational: child has the expected section headers.

If the repo has NO child AGENTS.md (the flat default), this is a clean no-op.

Usage:  python scripts/dox_check.py
Exit 0 = clean (or no hierarchy), 1 = integrity violation.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

ROOT = Path(".")
EXCLUDE_DIRS = {".git", "node_modules", ".next", "dist", "build", "__pycache__",
                ".venv", "venv", "migrate", "adopt", "examples"}
POINTS_TO_ROOT_RE = re.compile(r"global rules.*root AGENTS\.md|root AGENTS\.md.*global rules",
                               re.IGNORECASE | re.DOTALL)
EXPECTED_SECTIONS = ["Purpose", "Local Contracts"]  # minimal required shape for a child


def find_agents() -> list[Path]:
    out = []
    for p in ROOT.rglob("AGENTS.md"):
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        out.append(p)
    return out


def nearest_ancestor_agents(child: Path, all_agents: set[Path]) -> Path | None:
    """The closest AGENTS.md strictly above child's directory."""
    for parent in child.parent.parents:
        cand = parent / "AGENTS.md"
        if cand in all_agents:
            return cand
    root_doc = ROOT / "AGENTS.md"
    return root_doc if root_doc in all_agents and child != root_doc else None


def root_forbidden_phrases(root_text: str) -> list[str]:
    """Extract the short phrase after each root '❌' anti-pattern bullet."""
    phrases = []
    for m in re.finditer(r"❌\s*\*?\*?([^.\n*]{4,60})", root_text):
        phrases.append(m.group(1).strip().lower())
    return phrases


def check_verify_parity() -> list[str]:
    """Ensure verify.ps1 (the no-just PowerShell fallback) runs the same gates as the
    justfile's `verify:` chain. Two hand-maintained gate lists drift; this catches it.
    Best-effort: only runs if both files exist."""
    problems: list[str] = []
    jf, ps = Path("justfile"), Path("verify.ps1")
    if not jf.exists() or not ps.exists():
        return problems
    m = re.search(r"^verify:\s*(.+)$", jf.read_text(encoding="utf-8"), re.M)
    if not m:
        return problems
    just_gates = [g for g in m.group(1).split() if g not in ("&&", "@echo")]
    ps_text = ps.read_text(encoding="utf-8")
    for g in just_gates:
        # verify.ps1 references each gate via a Gate "name" label
        if f'Gate "{g}"' not in ps_text:
            problems.append(f"PARITY: `just verify` runs '{g}' but verify.ps1 does not — "
                            f"the PowerShell fallback would skip it. Add it to verify.ps1.")
    return problems


def main() -> None:
    agents = find_agents()
    root_doc = ROOT / "AGENTS.md"

    # Always run the verify.ps1<->justfile parity check (independent of the hierarchy).
    parity = check_verify_parity()

    if root_doc not in agents:
        if parity:
            print("FAIL: dox-check found gate-parity problems:")
            for p in parity:
                print(f"  x {p}")
            sys.exit(1)
        print("» dox-check: no root AGENTS.md — skipping hierarchy checks")
        sys.exit(0)

    children = [a for a in agents if a != root_doc]
    if not children and not parity:
        print("» dox-check: flat layout (no child AGENTS.md) — nothing to enforce")
        sys.exit(0)
    if not children and parity:
        print("FAIL: dox-check found gate-parity problems:")
        for p in parity:
            print(f"  x {p}")
        sys.exit(1)

    print(f"» dox-check: {len(children)} child AGENTS.md found")
    failures: list[str] = list(parity)
    all_set = set(agents)
    root_text = root_doc.read_text(encoding="utf-8")
    forbidden = root_forbidden_phrases(root_text)

    for child in sorted(children):
        rel = child.as_posix()
        text = child.read_text(encoding="utf-8")

        # 1. INDEXED in nearest ancestor's Child DOX Index
        anc = nearest_ancestor_agents(child, all_set) or root_doc
        anc_text = anc.read_text(encoding="utf-8")
        idx_m = re.search(r"#+\s*(?:\d+[.)]?\s*)?Child DOX Index(.*)", anc_text,
                          re.DOTALL | re.IGNORECASE)
        child_dir = child.parent.as_posix()
        indexed = idx_m and (child_dir in idx_m.group(1) or rel in idx_m.group(1)
                             or child.parent.name in idx_m.group(1))
        if not indexed:
            failures.append(f"NOT INDEXED: {rel} is not listed in {anc.as_posix()}'s "
                            f"'## Child DOX Index'")

        # 2. POINTS-TO-ROOT marker
        if not POINTS_TO_ROOT_RE.search(text):
            failures.append(f"NO ROOT POINTER: {rel} must state that global rules live in "
                            f"the root AGENTS.md (add a line referencing 'global rules' + "
                            f"'root AGENTS.md').")

        # 3. NO-WEAKEN: child re-permits a root-forbidden thing
        low = text.lower()
        for ph in forbidden:
            if not ph:
                continue
            # child explicitly allows what root forbids
            if (f"✅ {ph}" in low or f"allowed: {ph}" in low
                    or f"ok to {ph}" in low or f"it is fine to {ph}" in low):
                failures.append(f"WEAKENS ROOT: {rel} appears to re-permit a root-forbidden "
                                f"rule: '{ph}'")

        # 4. SHAPE (informational)
        missing = [s for s in EXPECTED_SECTIONS if f"## {s}" not in text and f"# {s}" not in text]
        if missing:
            print(f"  i {rel}: missing recommended section(s): {', '.join(missing)}")

    if failures:
        print("\nFAIL: dox-check found hierarchy integrity violations:")
        for f in failures:
            print(f"  x {f}")
        print("\nFix: index every child under its parent's '## Child DOX Index', add the "
              "root-pointer line, and ensure children only ADD rules (never re-permit a "
              "root ❌). See AGENTS.md §10.")
        sys.exit(1)

    print("OK: dox-check clean (hierarchy indexed, root-pointed, no weakening)")
    sys.exit(0)


if __name__ == "__main__":
    main()
