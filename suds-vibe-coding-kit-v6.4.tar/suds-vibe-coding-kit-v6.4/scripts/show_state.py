#!/usr/bin/env python3
"""show_state.py — print the yaml block at the top of STATE.md (replaces a sed one-liner
so `just state` works on Windows too)."""
from __future__ import annotations

import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

p = Path("STATE.md")
if not p.exists():
    print("no STATE.md")
    sys.exit(0)

inside = False
try:
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip().startswith("```"):
            if not inside:
                inside = True
                continue
            break
        if inside:
            print(line)
except BrokenPipeError:
    pass
