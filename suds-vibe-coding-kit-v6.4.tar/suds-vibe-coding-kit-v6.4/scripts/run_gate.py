#!/usr/bin/env python3
"""
run_gate.py — cross-platform runner for the toolchain gates (lint/typecheck/test/fmt/
verify-libs). Replaces the bash-shebang justfile recipes so `just` works identically on
native Windows PowerShell, Git Bash, and WSL — no cygpath, no bash required.

Each gate is "configured-aware": it only runs a tool if that tool's config/manifest is
present (pyproject.toml → ruff/mypy/pytest; package.json/tsconfig.json → eslint/tsc/vitest).
A tool that IS configured must pass — its exit code propagates (AGENTS.md §3: no `|| true`).
A tool that is NOT configured is skipped cleanly. This is the same policy the old recipes
intended, made portable.

Usage:
    python scripts/run_gate.py <gate>
    gate ∈ {lint, typecheck, test, fmt, verify-libs}
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass


def have(name: str) -> bool:
    return shutil.which(name) is not None


def run(label: str, args: list[str]) -> int:
    """Run a command, streaming output. Return its exit code (0 if the launcher is absent)."""
    print(f"» {label}")
    launcher = args[0]
    if not have(launcher):
        print(f"  ({launcher} not on PATH — skipping {label})")
        return 0
    try:
        proc = subprocess.run(args, capture_output=True, text=True)
    except FileNotFoundError:
        print(f"  ({launcher} not runnable — skipping {label})")
        return 0
    out = (proc.stdout or "") + (proc.stderr or "")
    # A configured tool whose actual binary isn't installed yet (e.g. pyproject.toml
    # exists but `uv sync` hasn't run, so `ruff`/`mypy`/`pytest` are absent). That's a
    # SETUP gap, not a code failure — skip it visibly rather than failing the gate, so a
    # bare machine isn't blocked. A genuine tool failure (lint errors, test failures)
    # still propagates.
    #
    # Only treat this as a spawn-failure when we launched via `uv run X` / `pnpm exec X`
    # AND the runner reported it couldn't find/spawn X. We deliberately do NOT skip on a
    # bare "not found" anywhere in output, so a test that PRINTS "not found" still fails.
    subtool = args[2] if len(args) > 2 and args[0] in ("uv", "pnpm") else None
    spawn_failed = bool(
        subtool
        and proc.returncode != 0
        and (
            f"Failed to spawn: `{subtool}`" in out
            or f"Failed to spawn: {subtool}" in out
            or (f"{subtool}: command not found" in out)
            or ("No such file or directory (os error 2)" in out and "Failed to spawn" in out)
        )
    )
    if spawn_failed:
        print(f"  !! {label.upper()} SKIPPED: {subtool} is not installed, but this stack "
              "is configured to use it.")
        print("     This gate is NOT actually checking anything. Run `just setup` "
              "(or uv sync / pnpm install) to enable it.")
        return 0
    # Stream the tool's own output so failures are visible.
    if out.strip():
        sys.stdout.write(out if out.endswith("\n") else out + "\n")
    return proc.returncode


def first_failure(*codes: int) -> int:
    for c in codes:
        if c != 0:
            return c
    return 0


def gate_lint() -> int:
    codes = []
    if Path("pyproject.toml").exists():
        codes.append(run("ruff", ["uv", "run", "ruff", "check", "."]))
    if Path("package.json").exists():
        codes.append(run("eslint", ["pnpm", "exec", "eslint", "."]))
    return first_failure(*codes)


def gate_typecheck() -> int:
    codes = []
    # Scope to src/ when present: the kit's example verification/verify_*.py files
    # intentionally import libraries that may not be installed (they're exercised by
    # `verify-libs`, which runs them, not type-checked here). Type-checking `.` would
    # fail on those example imports for a fresh project. Fall back to `.` if no src/.
    py_target = "src" if Path("src").is_dir() else "."
    if Path("pyproject.toml").exists():
        codes.append(run("mypy", ["uv", "run", "mypy", py_target]))
    if Path("tsconfig.json").exists():
        codes.append(run("tsc", ["pnpm", "exec", "tsc", "--noEmit"]))
    return first_failure(*codes)


def gate_test() -> int:
    codes = []
    if Path("pyproject.toml").exists():
        rc = run("pytest", ["uv", "run", "pytest", "-q"])
        # pytest exit 5 = "no tests collected". A fresh project legitimately has no tests
        # yet; that must not fail the gate. Real test failures (exit 1) still propagate.
        codes.append(0 if rc == 5 else rc)
    if Path("package.json").exists():
        rc = run("vitest", ["pnpm", "exec", "vitest", "run", "--passWithNoTests"])
        codes.append(rc)
    return first_failure(*codes)


def gate_fmt() -> int:
    codes = []
    if Path("pyproject.toml").exists():
        codes.append(run("ruff format", ["uv", "run", "ruff", "format", "."]))
    if Path("package.json").exists():
        codes.append(run("prettier", ["pnpm", "exec", "prettier", "--write", "."]))
    return first_failure(*codes)


def gate_verify_libs() -> int:
    """Run every verification/verify_*.py and verify_*.ts — proves library APIs.

    A verify_*.py whose TARGET library isn't installed is SKIPPED (nothing to verify on
    this machine), not failed — otherwise the shipped example scripts fail the gate on a
    fresh machine. A script that imports fine but whose ASSERTIONS fail (real API drift)
    still fails the gate, which is the whole point of the protocol.
    """
    codes = []
    vdir = Path("verification")
    if not vdir.is_dir():
        print("library checks done")
        return 0
    for f in sorted(vdir.glob("verify_*.py")):
        if not have("uv"):
            print(f"» {f}\n  (uv not on PATH — skipping)")
            continue
        print(f"» {f}")
        r = subprocess.run(["uv", "run", "python", str(f)], capture_output=True, text=True)
        if r.returncode == 0:
            if r.stdout.strip():
                print("  " + r.stdout.strip().replace("\n", "\n  "))
            continue
        # Distinguish "library not installed" (skip) from "API assertion failed" (fail).
        if "ModuleNotFoundError" in r.stderr or "No module named" in r.stderr:
            print(f"  (target library not installed — skipping {f.name})")
            continue
        print("  " + (r.stderr.strip() or r.stdout.strip()).replace("\n", "\n  "))
        codes.append(r.returncode)
    for f in sorted(vdir.glob("verify_*.ts")):
        codes.append(run(str(f), ["pnpm", "exec", "tsx", str(f)]))
    print("library checks done")
    return first_failure(*codes)


def gate_smoke() -> int:
    """Actually run & observe the app (AGENTS.md §3). Runs the `smoke` script from
    package.json if present (typically a Playwright e2e that launches the app and asserts
    something real / takes a screenshot). No-ops cleanly when not configured, so it never
    blocks a project that hasn't wired one up yet — but once present, it FAILS the gate on a
    broken app, replacing the v6 habit of deferring every GUI check as '[~] cannot verify'."""
    import json
    pkg = Path("package.json")
    if pkg.exists():
        try:
            scripts = json.loads(pkg.read_text(encoding="utf-8")).get("scripts", {})
        except (ValueError, OSError):
            scripts = {}
        if "smoke" in scripts:
            return run("smoke", ["pnpm", "run", "smoke"])
    print("» smoke: no `smoke` script configured — skipping (add one to actually run the app; "
          "see skills/templates/smoke.spec.ts.template)")
    return 0


GATES = {
    "lint": gate_lint,
    "typecheck": gate_typecheck,
    "test": gate_test,
    "fmt": gate_fmt,
    "verify-libs": gate_verify_libs,
    "smoke": gate_smoke,
}


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in GATES:
        print(f"usage: python scripts/run_gate.py {{{'|'.join(GATES)}}}")
        sys.exit(2)
    sys.exit(GATES[sys.argv[1]]())


if __name__ == "__main__":
    main()
