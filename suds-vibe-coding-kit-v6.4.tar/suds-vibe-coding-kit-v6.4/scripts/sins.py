#!/usr/bin/env python3
"""
sins.py — sins-sync / audit-sins for v6.1 (ast-grep based; no bash, no dual codegen).

  sync   regenerate rules/ (ast-grep rule files) + SinsGotchasLearnings_INDEX.md from
         SinsGotchasLearnings.md.
  audit  run `ast-grep scan` over the project. If rules/ is STALE vs SinsGotchasLearnings.md,
         it auto-regenerates first (idempotent) and prints a note — so a captured learning is
         always enforced, with NO "STALE AUDIT, go run sins-sync, re-verify" loop (the v6
         friction). A rule with `severity: error` fails the gate; warning/info are notes.

Usage:
    python scripts/sins.py sync
    python scripts/sins.py audit
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import extract_audits  # noqa: E402  (local helper; shares the staleness logic)


def py() -> str:
    return sys.executable or "python"


def find_ast_grep() -> str | None:
    for name in ("ast-grep", "sg"):
        if shutil.which(name):
            return name
    return None


def regenerate() -> int:
    """Regenerate rules/ + index from the taxonomy."""
    if not Path("SinsGotchasLearnings.md").exists():
        print("no SinsGotchasLearnings.md — skipping")
        return 0
    extract_audits.main()
    idx = Path("SinsGotchasLearnings_INDEX.md")
    with idx.open("w", encoding="utf-8") as fh:
        r = subprocess.run(
            [py(), str(HERE / "build_sins_index.py"), "SinsGotchasLearnings.md"], stdout=fh
        )
    if r.returncode != 0:
        return r.returncode
    print("» regenerated rules/ + SinsGotchasLearnings_INDEX.md")
    return 0


def sync() -> int:
    return regenerate()


def audit() -> int:
    if not Path("SinsGotchasLearnings.md").exists():
        print("» no SinsGotchasLearnings.md — sins audit skipped")
        return 0
    # Self-healing: keep the generated rules current with the taxonomy, no manual sync needed.
    if extract_audits.is_stale():
        print("  i rules/ was stale vs SinsGotchasLearnings.md — regenerating before scan")
        if regenerate() != 0:
            return 1

    if not Path("rules").exists() or not any(Path("rules").glob("*.yml")):
        print("» no ast-grep rules to run (add `### Audit Rule` blocks to SinsGotchasLearnings.md)")
        return 0

    sg = find_ast_grep()
    if sg is None:
        print("  i ast-grep not found on PATH — sins audit SKIPPED (non-fatal).")
        print("    Install it: `mise install` (it's pinned in .mise.toml), or "
              "`npm i -g @ast-grep/cli`, `cargo install ast-grep`, `brew install ast-grep`.")
        return 0

    print(f"» sins audit (ast-grep scan via '{sg}')")
    # `ast-grep scan` reads sgconfig.yml, applies rules/, and exits non-zero on error-severity
    # findings. Suppress a single approved line with a `# ast-grep-ignore` comment above it.
    return subprocess.run([sg, "scan"]).returncode


def main() -> None:
    cmd = sys.argv[1] if len(sys.argv) == 2 else ""
    if cmd == "sync":
        sys.exit(sync())
    elif cmd == "audit":
        sys.exit(audit())
    else:
        print("usage: python scripts/sins.py {sync|audit}")
        sys.exit(2)


if __name__ == "__main__":
    main()
