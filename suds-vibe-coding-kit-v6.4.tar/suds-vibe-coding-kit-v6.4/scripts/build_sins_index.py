#!/usr/bin/env python3
"""
build_sins_index.py — Tier 2 of the learnings system.

Collapses SinsGotchasLearnings.md (which can be thousands of lines) into SinsGotchasLearnings_INDEX.md:
one line per entry = number, title, and the first sentence of its Rule. Agents read
the index at session start (~cheap) and only open the full entry when an audit hit
references it. Turns a 5,000-line "please remember everything" file into ~80 lines
of orientation plus on-demand depth.

Usage: python scripts/build_sins_index.py SinsGotchasLearnings.md > SinsGotchasLearnings_INDEX.md
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

# Force UTF-8 on stdout. On Windows the default is cp1252, which turns the
# `§`/`⚙` glyphs into mojibake (┬º / ΓÜÖ) when this script's output is redirected
# with `>` into the index file. (See SinsGotchasLearnings: "Windows stdout encoding".)
try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]  # py3.7+
except (AttributeError, ValueError):
    pass

def main() -> None:
    md = Path(sys.argv[1]).read_text(encoding="utf-8")
    entries = re.split(r"\n(?=## \d+\. )", md)
    out = ["# SinsGotchasLearnings_INDEX",
           "",
           "Generated from SinsGotchasLearnings.md. One line per incident. Read this to orient; open the",
           "full entry in SinsGotchasLearnings.md (`## N.`) only when you need the detail or an audit hit",
           "cites it. Regenerate with `just sins-sync`.",
           ""]
    for e in entries:
        m = re.match(r"## (\d+)\.\s+(.+)", e)
        if not m:
            continue
        num, title = m.group(1), m.group(2).strip()
        rule = ""
        rm = re.search(r"### Rule[^\n]*\n+\*?\*?(.+?)(?:\n|$)", e)
        if rm:
            rule = re.sub(r"[*`]", "", rm.group(1)).strip()
            rule = rule.split(". ")[0][:130]
        has_audit = "### Audit Rule" in e
        tag = " ⚙" if has_audit else ""   # ⚙ = has an ast-grep rule run by audit-sins
        out.append(f"- **§{num}{tag}** {title}" + (f" — {rule}" if rule else ""))
    out += ["", "⚙ = has an ast-grep `### Audit Rule` enforced by `just verify` (audit-sins)."]
    sys.stdout.write("\n".join(out) + "\n")

if __name__ == "__main__":
    main()
