#!/usr/bin/env python3
"""
setup_devtools.py — install the per-language dev tools the verification gate needs,
for whatever stack the grill actually set up. Run via `just setup` AFTER the grill has
created pyproject.toml and/or package.json.

It is stack-aware (installs only what's present), idempotent (safe to re-run), and honest
(reports exactly what it installed/skipped). It does NOT guess a stack — if neither
manifest exists yet, it tells you to run the grill first.

  Python  (pyproject.toml present): adds ruff, mypy, pytest as dev deps via `uv add --dev`,
          then `uv sync` so they're installed in the project env.
  Node/TS (package.json present):   adds eslint, typescript, vitest, tsx as devDependencies
          via `pnpm add -D`, then `pnpm install`.

Usage:
    python scripts/setup_devtools.py
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

PY_DEVTOOLS = ["ruff", "mypy", "pytest"]
TS_DEVTOOLS = ["eslint", "typescript", "vitest", "tsx"]


def have(name: str) -> bool:
    return shutil.which(name) is not None


def run(args: list[str]) -> int:
    print(f"  $ {' '.join(args)}")
    try:
        return subprocess.run(args).returncode
    except FileNotFoundError:
        print(f"  ({args[0]} not on PATH)")
        return 127


def setup_python() -> int:
    if not have("uv"):
        print("  uv not on PATH — install the toolchain first (mise install). Skipping Python.")
        return 1
    print(f"» Python: adding dev tools ({', '.join(PY_DEVTOOLS)}) via uv")
    rc = run(["uv", "add", "--dev", *PY_DEVTOOLS])
    if rc != 0:
        return rc
    return run(["uv", "sync"])


def setup_node() -> int:
    pnpm = "pnpm" if have("pnpm") else None
    if not pnpm:
        print("  pnpm not on PATH — install the toolchain first (mise install). Skipping Node.")
        return 1
    print(f"» Node/TS: adding dev tools ({', '.join(TS_DEVTOOLS)}) via pnpm")
    rc = run(["pnpm", "add", "-D", *TS_DEVTOOLS])
    if rc != 0:
        return rc
    return run(["pnpm", "install"])


def main() -> None:
    py = Path("pyproject.toml").exists()
    ts = Path("package.json").exists()

    if not py and not ts:
        print("No pyproject.toml or package.json found.")
        print("Run the grill (skills/grill-to-prd.md) and Phase 0 first so the project's")
        print("stack is initialized, then re-run `just setup`.")
        sys.exit(1)

    worst = 0
    if py:
        worst = setup_python() or worst
    if ts:
        worst = setup_node() or worst

    print()
    if worst == 0:
        print("Dev tools installed. `just verify` will now actually run lint/typecheck/test")
        print("(not skip them). Run `just verify` to confirm a real green.")
    else:
        print("Some installs did not complete cleanly (see above). Fix, then re-run `just setup`.")
    sys.exit(worst)


if __name__ == "__main__":
    main()
