#!/usr/bin/env python3
"""
build_repo_map.py — generates RepoMapReadFirst.md, the living codebase map.

Purpose: kill codebase re-orientation cost. Without this, a cold agent session
re-walks hundreds of files ("let me understand the structure...") burning 50-150k
tokens to rebuild a map it had last session. This file is that map, ~2k tokens,
read first. Regenerate with `just map-sync`; it's cheap and always current.

TWO LAYERS:
  1. AUTO SKELETON (regenerated every run): directory tree to a sane depth, file
     counts by type, detected entry points, and per-top-level-dir one-liners.
  2. CURATED "START HERE" (preserved across regenerations): a human/agent-written
     block between the CURATED markers. The generator never overwrites it — a
     pure tree-walk can't know which 5 files actually matter; that's judgment the
     agent records and we protect.

The script reads any existing RepoMapReadFirst.md, lifts out the curated block,
regenerates the skeleton, and stitches the curated block back in.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

EXCLUDE = {".git", "node_modules", ".next", "dist", "build", "__pycache__",
           ".venv", "venv", ".turbo", "coverage", ".pytest_cache", ".mypy_cache"}
CODE_EXTS = {".ts", ".tsx", ".js", ".jsx", ".py", ".sql", ".css", ".scss",
             ".rs", ".go", ".java", ".rb"}
ENTRY_HINTS = ("main.py", "index.ts", "index.tsx", "app.py", "app.ts", "main.ts",
               "__main__.py", "server.py", "server.ts", "cli.py", "index.js",
               "App.tsx", "main.tsx", "manage.py", "wsgi.py", "asgi.py")

CURATED_START = "<!-- CURATED:START -->"
CURATED_END = "<!-- CURATED:END -->"
DEFAULT_CURATED = f"""{CURATED_START}
## Start here (curated — generator preserves this block)

The agent maintains this section. When you learn which files actually matter,
record them here so the next session doesn't have to rediscover them.

- **Entry point:** [fill in: where execution starts]
- **Core domain logic:** [fill in: the 2-3 files that hold the real complexity]
- **Where to add a new feature:** [fill in: the typical touch-points]
- **Gotcha files:** [fill in: anything surprising — see SinsGotchasLearnings.md]

_Last meaningful structural change:_ [fill in date + one line]
{CURATED_END}"""


def _tree(root: Path, max_depth: int = 3) -> list[str]:
    lines: list[str] = []
    root = root.resolve()
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE and not d.startswith("."))
        rel = Path(dirpath).resolve().relative_to(root)
        depth = 0 if str(rel) == "." else len(rel.parts)
        if depth > max_depth:
            dirs[:] = []
            continue
        if str(rel) != ".":
            lines.append("  " * (depth - 1) + f"{rel.parts[-1]}/")
        # show a few representative files at shallow depth only (avoid noise)
        if depth <= 1:
            shown = sorted(f for f in files if Path(f).suffix in CODE_EXTS)[:6]
            for f in shown:
                lines.append("  " * depth + f)
    return lines


def _counts(root: Path) -> dict[str, int]:
    c: dict[str, int] = {}
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in EXCLUDE and not d.startswith(".")]
        for f in files:
            ext = Path(f).suffix
            if ext in CODE_EXTS:
                c[ext] = c.get(ext, 0) + 1
    return dict(sorted(c.items(), key=lambda kv: -kv[1]))


def _entry_points(root: Path) -> list[str]:
    found: list[str] = []
    for dirpath, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in EXCLUDE and not d.startswith(".")]
        for f in files:
            if f in ENTRY_HINTS:
                rel = (Path(dirpath) / f).resolve().relative_to(root.resolve())
                found.append(str(rel))
    return sorted(found)[:12]


def _top_dirs(root: Path) -> list[str]:
    out = []
    for p in sorted(root.iterdir()):
        if p.is_dir() and p.name not in EXCLUDE and not p.name.startswith("."):
            n = sum(1 for _ in p.rglob("*") if _.is_file())
            out.append(f"- `{p.name}/` — {n} files")
    return out


def _extract_curated(text: str) -> str:
    m = re.search(re.escape(CURATED_START) + r".*?" + re.escape(CURATED_END), text, re.DOTALL)
    return m.group(0) if m else DEFAULT_CURATED


def main() -> None:
    root = Path(".")
    existing = Path("RepoMapReadFirst.md")
    curated = _extract_curated(existing.read_text(encoding="utf-8")) if existing.exists() else DEFAULT_CURATED

    counts = _counts(root)
    counts_str = ", ".join(f"{n} {ext}" for ext, n in counts.items()) or "no code files yet"
    entries = _entry_points(root)
    entries_str = "\n".join(f"- `{e}`" for e in entries) or "- (none detected)"
    tops = "\n".join(_top_dirs(root)) or "- (empty)"
    tree = "\n".join(_tree(root)) or "(empty)"

    out = f"""# RepoMapReadFirst

> **Agents: read this before walking the file tree.** It is the living map of this
> repo, regenerated by `just map-sync`. The skeleton below is auto-generated; the
> "Start here" block is curated and preserved. Reading this (~2k tokens) replaces
> re-discovering the structure by reading hundreds of files (50k+ tokens) every
> cold session. If something here looks stale, run `just map-sync` — don't re-walk.

{curated}

---

## Top-level layout (auto-generated)

{tops}

## Detected entry points (auto-generated)

{entries_str}

## Code inventory (auto-generated)

{counts_str}

## Directory skeleton (auto-generated, depth 3)

```
{tree}
```

---
_Auto-generated section regenerated by `just map-sync`. Do not hand-edit below the
curated block; edits will be overwritten. Record durable knowledge in the curated
block instead._
"""
    Path("RepoMapReadFirst.md").write_text(out, encoding="utf-8")
    print(f"» RepoMapReadFirst.md regenerated ({len(entries)} entry points, "
          f"{sum(counts.values())} code files)")


if __name__ == "__main__":
    main()
