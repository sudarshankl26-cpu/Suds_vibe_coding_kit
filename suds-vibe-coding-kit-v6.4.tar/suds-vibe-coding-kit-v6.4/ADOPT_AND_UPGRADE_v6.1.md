# Installing / upgrading to Vibe Coding Kit v6.1

Two jobs, two scripts, one safety model:

| Your situation | Path | Script | Overwrites your files? |
|---|---|---|---|
| **A project with no kit** (built without it, partially done) | **Adopt** | `adopt/adopt_kit.py` | **Never** — only adds missing files |
| **A v6 kit project** → v6.1 | **Swap** | manual (`MIGRATION_v6.1.md`) | only stock infra you swap yourself |
| **A v5 kit project** → v6.1 | **Migrate** | `migrate/migrate_kit.py` | **Never** — stages everything for review |

The non-negotiable rule for both: **unpack the v6.1 tar somewhere OUTSIDE your project**
(e.g. `C:\temp`) and point the script *at* your project. Never extract the tar on top of an
existing project — that is the only way to lose work, and these scripts exist precisely so you
don't have to.

> All commands below are Windows PowerShell (your environment). The kit file is a plain
> `.tar`, so `tar -xf` (no `z`). WSL/macOS users: same commands, swap `C:\temp` for `/tmp`.

---

## One-time prerequisite (install once, ever)

[`mise`](https://mise.jdx.dev) is the single gateway tool. It reads `.mise.toml` and installs
`just`, `uv`, `node`, `pnpm`, and **`ast-grep`** (new in v6.1) at pinned versions — so the agent
never burns a turn installing toolchain.

```powershell
winget install jdx.mise      # Windows
# WSL:  curl https://mise.run | sh
```

If you can't use mise, install the one new prerequisite directly:
`pip install ast-grep-cli` *(or `npm i -g @ast-grep/cli`, or `cargo install ast-grep`)* — it has
a native Windows binary. Everything else (`just`, `uv`, `pnpm`) you likely already have.

---

# Scenario 1 — Adopt the kit into an existing NON-kit project

Use this for a project you've already partially built and now want to steer with the kit.
`adopt_kit.py` **only adds files you don't already have** — it cannot overwrite your source,
configs, or anything else present. It git-inits if needed, installs the gate hooks, and
generates the repo map + sins index from your real code.

### Steps

```powershell
# 0. (once) make sure mise + ast-grep are installed — see prerequisite above

# 1. Unpack v6.1 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.4.tar -C C:\temp

# 2. From INSIDE your project, DRY-RUN the plan (changes nothing):
cd C:\path\to\your\project
python C:\temp\suds-vibe-coding-kit-v6.4\adopt\adopt_kit.py --kit C:\temp\suds-vibe-coding-kit-v6.4 --plan
#   (PowerShell launcher equivalent — no -Apply means plan-only:)
#   C:\temp\suds-vibe-coding-kit-v6.4\adopt\adopt-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.4
```

Read the plan. `ADD` = kit files that will be copied in. `EXISTS-KEEP` = your files it will
**not** touch. Nothing has changed yet.

```powershell
# 3. Apply (creates a git branch first if the repo is already git):
python C:\temp\suds-vibe-coding-kit-v6.4\adopt\adopt_kit.py --kit C:\temp\suds-vibe-coding-kit-v6.4 --apply
#   or:  ...\adopt-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.4 -Apply

# 4. Provision the toolchain (reads .mise.toml: just/uv/node/pnpm/ast-grep)
mise install

# 5. Reverse-engineer the contracts from YOUR code.
#    The script prints a prompt — paste it into your coding agent. It drafts
#    GLOSSARY / DATA_MODEL / ARCHITECTURE / PRD from what's actually there for you to correct,
#    then sets STATE.md to your current reality. It does NOT change your source.

# 6. Baseline the gates against your existing code:
just verify        # fast code gates; triage what the sins audit flags
just verify-all    # adds bookkeeping + smoke
```

For anything the audit legitimately flags but you've decided is OK, put `# ast-grep-ignore`
(Python/CSS) or `// ast-grep-ignore` (TS/JS) on the line above it with a reason in the commit —
don't weaken the rule.

### Going forward
Drive every session with **Prompt F** in `PROMPTS.md` (reads `STATE.md` → does the task →
`just verify` while working, `just verify-all` before done). Capture each non-trivial bug as a
`## N.` entry in `SinsGotchasLearnings.md` (prose first; an `### Audit Rule` only if it's
genuinely structural).

### One thing to know
`adopt` installs the **full `just verify-all`** pre-commit hook (parity with a scaffolded
project — code + bookkeeping + smoke), with a gate-by-gate python fallback for bare machines.
It copies the kit's `README.md` and `docs/` skeleton into your repo but **skips the meta-docs**
(field guide, infographic, `MIGRATION_v6.1.md`, this guide) so they don't litter the project.
Anything you already have is kept; only missing files are added.

---

# Scenario 2 — Upgrade an existing kit project to v6.1

**The golden rule that guarantees no loss:** your *content* is never the thing that changes.
v6.1 swaps the **enforcement machinery** (scripts, gates, hooks), not your contracts
(PRD/GLOSSARY/DATA_MODEL/ARCHITECTURE), your `SinsGotchasLearnings.md` incidents, your logs,
`STATE.md`, `types/`, or `src/`. There is **no data migration**.

Before either path, take the two free safety nets:

```powershell
git add -A; git commit -m "checkpoint before v6.1 upgrade"   # if it's a git repo
git checkout -b upgrade-v6.1
Copy-Item -Recurse -Force . "..\$(Split-Path -Leaf (Get-Location))-backup-v6.1"   # belt and suspenders
```

## 2a. From v6 → v6.1  (the clean, tested path)

This is a **drop-in swap of ~15 infra files**. Full detail lives in the kit's
`MIGRATION_v6.1.md`; the mechanical version:

```powershell
# 1. unpack v6.1 outside your project
tar -xf suds-vibe-coding-kit-v6.4.tar -C C:\temp
$KIT = "C:\temp\suds-vibe-coding-kit-v6.4"

# 2. copy the enforcement files over your project (these are stock infra — safe to overwrite).
#    Adjust the destination if you're not standing in the project root.
$infra = @(
  "justfile","verify.ps1","scaffold.ps1","scaffold.sh","sgconfig.yml",".mise.toml",
  "scripts\sins.py","scripts\extract_audits.py","scripts\run_gate.py","scripts\log_prompt.py",
  "verification\check_prompt_log.py",
  ".opencode\plugins\prompt-logger.js",".claude\settings.json",
  ".github\workflows\verify.yml.disabled",
  "skills\templates\smoke.spec.ts.template"
)
foreach ($f in $infra) {
  New-Item -ItemType Directory -Force (Split-Path $f) | Out-Null
  Copy-Item -Force (Join-Path $KIT $f) $f
}

# 3. delete the retired v6 grep audit engine (replaced by ast-grep)
Remove-Item -Force verification\audit_sins.sh, verification\audit_sins.py -ErrorAction SilentlyContinue

# 4. refresh the governance WORDING. If you never customized these, just copy v6.1's versions:
#    AGENTS.md (new §0a/§0b/§3), CONTEXT.md, START_HERE.md, PROMPTS.md, README.md, and the
#    template headers UserPromptLog.md / WorkLogAfterEachRun.md / OpenTasksMustCompleteAll.md.
#    If you DID customize AGENTS.md, diff it against the kit's and hand-merge §0a/§0b/§3 only.

# 5. install ast-grep + reinstall the commit hook to run the full set (see below)
mise install

# 6. regenerate the ast-grep rules from your taxonomy, then prove green
just sins-sync
just verify-all
```

Your `SinsGotchasLearnings.md` keeps every entry. Old `### Audit Recipe` (grep) blocks simply
stop being auto-run — the new extractor reads `### Audit Rule` (ast-grep). Convert the few that
are genuinely structural when convenient; leave the rest as prose.

## 2b. From v5 → v6.1  (use the migrator, then accept v6.1)

The `migrate` script is the safest tool here: it **backs up, branches, and overwrites nothing**.
Because it detects "stock" files against a **v4** baseline, a v5 project's infra won't match —
so instead of auto-replacing, it stages the v6.1 versions next to yours as `*.kit-incoming` for
you to review. Your state (STATE/PRD/GLOSSARY/DATA_MODEL/ARCHITECTURE/logs/`src`/`tests`/`docs`)
is in the PRESERVE set and is never touched.

```powershell
# 1. unpack v6.1 outside your project
tar -xf suds-vibe-coding-kit-v6.4.tar -C C:\temp
$KIT = "C:\temp\suds-vibe-coding-kit-v6.4"

# 2. from INSIDE your v5 project, dry-run (changes nothing):
cd C:\path\to\your\project
python $KIT\migrate\migrate_kit.py --kit $KIT --plan
#   launcher:  $KIT\migrate\migrate-kit.ps1 -Kit $KIT

# 3. apply — creates .kit-backup-<stamp>\ + a git branch, stages merges as *.kit-incoming:
python $KIT\migrate\migrate_kit.py --kit $KIT --apply
#   launcher:  $KIT\migrate\migrate-kit.ps1 -Kit $KIT -Apply
#   add --remove-retired to also delete setup.sh + the old verification/audit_sins.{sh,py}
```

Then resolve the staged files (nothing of yours was overwritten — the v6.1 copy sits *beside*
yours):

```powershell
# 4. hand each *.kit-incoming to your agent, one at a time:
#    > Read migrate/MIGRATION.md. Walk me through each *.kit-incoming file: show the diff,
#    > tell me what changed, recommend an action, apply only when I confirm.
#    For SinsGotchasLearnings.md.kit-incoming it runs migrate/merge_sins.py — your real
#    incidents stay first, v6.1's generic ones are appended + renumbered, dupes skipped.

# 5. finish the enforcement swap (v5 had no ast-grep):
Copy-Item -Force $KIT\sgconfig.yml .                       # ast-grep project config (new)
Copy-Item -Force $KIT\.mise.toml .                         # adds the ast-grep pin
#   accept the staged justfile/verify.ps1/scripts*.kit-incoming from step 4 to get the
#   verify/verify-all split + the new audit engine. (--remove-retired in step 3 already
#   deleted the old verification/audit_sins.{sh,py}; otherwise delete them now.)

# 6. toolchain, hook, rebuild, prove green
mise install
just sins-sync
just verify-all
```

---

## Make the commit hook run the full set (mainly for the upgrade path)

`scaffold` and `adopt` both install the full `just verify-all` pre-commit hook. The **migrate**
script does *not* touch hooks — your existing v4/v5 hook stays, which may still run the old
code-only `just verify`. After migrating, overwrite the hook so commits run the bookkeeping +
smoke gates too:

```powershell
@"
#!/bin/sh
if command -v just >/dev/null 2>&1; then exec just verify-all; fi
echo "just not found - gate not run, commit allowed."
"@ | Set-Content -NoNewline .git\hooks\pre-commit
```

(Pure code-gate-on-commit is a defensible choice too — it keeps commits fast and pushes the
bookkeeping/smoke checks to CI. Pick one and be consistent.)

---

## How to know it worked (run after either scenario)

```powershell
ast-grep --version          # the one new prerequisite is on PATH
just verify                 # code gates: lint/typecheck/test/verify-libs/verify-schema/audit-sins/dox-check
just verify-all             # + check-tasks/check-prompt-log/smoke  → all green
Test-Path rules             # ast-grep rules dir exists (sins-sync populated it)
Test-Path sgconfig.yml      # ast-grep project config present
```

Green `just verify-all` = you're on v6.1. Reversibility: `git checkout -` (delete the branch),
or restore from `.kit-backup-<stamp>\` / your manual backup copy — nothing is one-way.
