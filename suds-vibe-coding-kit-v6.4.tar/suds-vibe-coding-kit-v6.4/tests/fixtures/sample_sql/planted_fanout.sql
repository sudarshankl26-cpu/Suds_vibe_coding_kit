-- PLANTED BUG: joins events at row grain -> fanout, then SUMs -> double counts
-- expected finding: fanout_join on users<->events
SELECT u.id, SUM(e.amount) total
FROM users u
JOIN events e ON e.user_id = u.id
GROUP BY u.id;
