-- known-clean: pre-aggregates events before joining users (no fanout)
SELECT u.id, e.cnt
FROM users u
JOIN (SELECT user_id, COUNT(*) cnt FROM events GROUP BY user_id) e
  ON e.user_id = u.id;
