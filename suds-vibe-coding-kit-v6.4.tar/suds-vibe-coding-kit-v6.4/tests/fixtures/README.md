# Fixtures
Each processor feature gets: one clean input (must produce zero findings) and one input with
exactly one planted bug (must produce exactly that finding). The planted bug is documented in
a comment at the top of the file with `expected finding:`. This forces features to work on
real-shaped data, not synthetic data the agent invented.
