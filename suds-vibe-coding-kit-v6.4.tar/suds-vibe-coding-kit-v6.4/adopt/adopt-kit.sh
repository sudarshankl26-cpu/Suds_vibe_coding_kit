#!/usr/bin/env bash
# Retrofit Sud's Vibe Coding Kit onto an EXISTING, non-kit project (WSL/mac/Linux).
# Run from INSIDE your existing project. Plan-only by default; --apply to execute.
#   tar -xf suds-vibe-coding-kit-v6.4.tar -C /tmp/
#   bash adopt/adopt-kit.sh --kit /tmp/suds-vibe-coding-kit-v6.4            # plan
#   bash adopt/adopt-kit.sh --kit /tmp/suds-vibe-coding-kit-v6.4 --apply    # apply
set -uo pipefail

KIT=""; MODE="--plan"
while [ $# -gt 0 ]; do
  case "$1" in
    --kit) KIT="$2"; shift 2;;
    --apply) MODE="--apply"; shift;;
    *) echo "unknown arg: $1"; exit 2;;
  esac
done
[ -z "$KIT" ] && { echo "usage: bash adopt/adopt-kit.sh --kit <path-to-unpacked-kit> [--apply]"; exit 2; }

PROJECT="$(pwd)"  # your project = where you are standing, not where the kit is
PY="$(command -v python3 || command -v python)"
[ -z "$PY" ] && { echo "[ERROR] Python not found in PATH."; exit 1; }

"$PY" "$KIT/adopt/adopt_kit.py" --kit "$KIT" --project "$PROJECT" $MODE
