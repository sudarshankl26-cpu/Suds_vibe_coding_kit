#!/usr/bin/env python3
"""
migrate_kit.py — safely migrate an ongoing v4/v5 project onto the current Sud's Vibe
Coding Kit (v6.1).

Design principle: a migration must NEVER overwrite your accumulated project state, and
must NEVER blindly trust that kit-infrastructure files are stock (your coding agent may
have edited them). So every file is CLASSIFIED, not assumed:

  PRESERVE      — your state. Never touched. (STATE.md, logs, PRD/GLOSSARY/DATA_MODEL/
                  ARCHITECTURE, .env, src/, docs/adr/*, types/* you filled, fixtures…)
  OVERWRITE     — pure kit infrastructure that is byte-identical to stock *v4* in your
                  repo (verified by hash against migrate/v4_baseline.sha256). Safe to
                  replace silently. NOTE: a v5/v6 project's infra won't match the v4
                  baseline, so it falls through to MERGE/DRIFTED below and is *staged*,
                  not auto-replaced — safer, just one extra review step.
  ADD           — new in this kit, absent in your repo. Copied in.
  MERGE         — needs judgment: either the kit changed it AND you (or your agent) may
                  have too, or it carries content that must be combined
                  (SinsGotchasLearnings.md). The migrator does NOT auto-resolve these. It
                  writes the kit version next to yours as `<file>.kit-incoming` and lists
                  it for the agent/you to merge.
  SKIP-DRIFTED  — infrastructure the kit would overwrite, BUT your copy differs from stock
                  v4 (agent edited it, or you're on v5/v6). Treated as MERGE to be safe:
                  the kit version lands as `.kit-incoming`.

Nothing is applied in place without a git branch + a full backup first. Idempotent:
re-running detects already-migrated files and no-ops.

Usage:
    python migrate/migrate_kit.py --kit <path-to-unpacked-kit> [--plan|--apply]
        --plan   (default) classify and print the plan; touch nothing.
        --apply  create branch + backup, then apply OVERWRITE/ADD and stage MERGE files.
        --remove-retired   also delete files this kit retires (setup.sh, the old grep
                           audit engine verification/audit_sins.{sh,py}).
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]  # avoid Windows cp1252 mojibake
except (AttributeError, ValueError):
    pass

# ── Classification policy ───────────────────────────────────────────────────
# PRESERVE: project state / contracts you fill in. NEVER touched by the migrator.
PRESERVE = {
    "STATE.md", "PRD.md", "GLOSSARY.md", "DATA_MODEL.md", "ARCHITECTURE.md",
    "UserPromptLog.md", "WorkLogAfterEachRun.md", "OpenTasksMustCompleteAll.md",
    "CONTEXT.md",  # routing file; if you somehow edited it, keep yours
}
# Whole directory trees that are yours — never traversed for overwrite.
PRESERVE_DIRS = {"src", "docs", "tests", ".git"}

# MERGE: combine content / always needs human-or-agent judgment.
MERGE_ALWAYS = {
    "SinsGotchasLearnings.md",   # append the kit's generic entries after yours, renumbered
    "AGENTS.md",                 # the kit added §0a/§0b/§3 rules; your agent may have appended too
    "EXECUTION_PLAN.md",         # the kit fixed Phase 0 + added the server-script/smoke phase
    "skills/grill-to-prd.md",    # the kit added the port question
    "RepoMapReadFirst.md",       # has your curated block; regenerate, don't overwrite
}
# Generated — never migrate; regenerate after with `just sins-sync` / `just map-sync`.
GENERATED = {
    "SinsGotchasLearnings_INDEX.md",
}
# Files this kit retires — offer to remove (superseded), but only on --apply with consent.
#   setup.sh                      → superseded by scaffold.* (v5)
#   verification/audit_sins.{sh,py} → superseded by ast-grep rules in rules/ (v6.1)
RETIRED = {"setup.sh", "verification/audit_sins.sh", "verification/audit_sins.py"}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load_baseline(kit: Path) -> dict[str, str]:
    mf = kit / "migrate" / "v4_baseline.sha256"
    out: dict[str, str] = {}
    if not mf.exists():
        return out
    for line in mf.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        h, _, rel = line.partition("  ")
        out[rel] = h
    return out


def in_preserve_dir(rel: str) -> bool:
    top = rel.split("/", 1)[0]
    return top in PRESERVE_DIRS


def classify(project: Path, kit: Path) -> dict[str, list[tuple[str, str]]]:
    """Return {action: [(rel, note), ...]}."""
    baseline = load_baseline(kit)
    plan: dict[str, list[tuple[str, str]]] = {
        "PRESERVE": [], "OVERWRITE": [], "ADD": [], "MERGE": [],
        "SKIP-DRIFTED": [], "RETIRE": [], "GENERATED": [],
    }

    kit_files = sorted(
        str(p.relative_to(kit)).replace("\\", "/")
        for p in kit.rglob("*") if p.is_file()
    )

    for rel in kit_files:
        # Never migrate the migrator's own folder, VCS, or Python bytecode caches.
        if (rel.startswith("migrate/") or rel.startswith(".git/")
                or "__pycache__" in rel or rel.endswith(".pyc")):
            continue

        proj_path = project / rel
        kit_path = kit / rel
        name = rel

        # Project-state files: preserve if present; add the template only if missing.
        if name in PRESERVE or in_preserve_dir(rel):
            if proj_path.exists():
                plan["PRESERVE"].append((rel, "your state — untouched"))
            else:
                plan["ADD"].append((rel, "missing; kit template added"))
            continue

        if name in GENERATED:
            plan["GENERATED"].append((rel, "regenerated after migrate (just sins-sync)"))
            continue

        if name in MERGE_ALWAYS:
            if not proj_path.exists():
                plan["ADD"].append((rel, "missing; kit version added"))
            elif kit_path.exists() and proj_path.exists() and sha256(proj_path) == sha256(kit_path):
                plan["PRESERVE"].append((rel, "already identical to this kit"))
            else:
                plan["MERGE"].append((rel, "combine your content with this kit's changes"))
            continue

        # Everything else = kit infrastructure (scripts, generators, configs, templates…).
        if not proj_path.exists():
            plan["ADD"].append((rel, "new in this kit"))
            continue

        if sha256(proj_path) == sha256(kit_path):
            plan["PRESERVE"].append((rel, "already identical to this kit"))
            continue

        # Differs from the kit. Is your copy stock v4 (safe to overwrite) or drifted
        # (agent edited it, or you're on v5/v6)?
        base_h = baseline.get(rel)
        if base_h is not None and sha256(proj_path) == base_h:
            plan["OVERWRITE"].append((rel, "stock v4 → this kit (bugfixes)"))
        else:
            plan["SKIP-DRIFTED"].append((rel, "differs from v4 baseline (your edits / v5-v6) — staged as .kit-incoming"))

    # Retired files present in the project.
    for name in sorted(RETIRED):
        if (project / name).exists():
            plan["RETIRE"].append((name, "retired by this kit (superseded)"))

    return plan


def git(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)


def apply(project: Path, kit: Path, plan: dict, remove_retired: bool) -> None:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

    # 1. Backup (outside git, always recoverable even if not a git repo).
    backup = project / f".kit-backup-{stamp}"
    backup.mkdir(exist_ok=True)
    for action in ("OVERWRITE", "MERGE", "SKIP-DRIFTED", "RETIRE"):
        for rel, _ in plan[action]:
            src = project / rel
            if src.exists():
                dst = backup / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
    print(f"  ✓ backup written to {backup.name}/")

    # 2. Branch (only if it's a git repo and working tree is clean enough).
    if (project / ".git").exists():
        br = f"migrate-kit-{stamp}"
        r = git(["checkout", "-b", br], project)
        print(f"  ✓ git branch {br}" if r.returncode == 0
              else f"  ! could not branch ({r.stderr.strip()}); continuing on current branch")

    def copy_in(rel: str) -> None:
        s, d = kit / rel, project / rel
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, d)

    # 3. OVERWRITE + ADD (safe).
    for rel, _ in plan["OVERWRITE"]:
        copy_in(rel)
        print(f"  ~ overwrote {rel}")
    for rel, _ in plan["ADD"]:
        copy_in(rel)
        print(f"  + added     {rel}")

    # 4. MERGE + SKIP-DRIFTED → stage kit version as .kit-incoming (never clobber yours).
    staged: list[str] = []
    for action in ("MERGE", "SKIP-DRIFTED"):
        for rel, _ in plan[action]:
            inc = project / (rel + ".kit-incoming")
            inc.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(kit / rel, inc)
            staged.append(rel)
            print(f"  ⚑ staged    {rel}.kit-incoming  (merge needed)")

    # 5. Retired files.
    if remove_retired:
        for rel, _ in plan["RETIRE"]:
            (project / rel).unlink(missing_ok=True)
            print(f"  ✗ removed   {rel} (retired)")
    elif plan["RETIRE"]:
        print("  (RETIRE files left in place — re-run with --remove-retired to delete them.)")

    print("\nApplied. Nothing of yours was overwritten; merges are staged as .kit-incoming.")
    if staged:
        print("Next: resolve each .kit-incoming (see MIGRATION.md), then regenerate:")
        print("  just sins-sync && just map-sync   (or the python scripts directly)")
    print("Then prove green:  just verify-all")
    print(f"Rollback anytime: restore from {backup.name}/ or `git checkout -` + delete the branch.")


def print_plan(plan: dict) -> None:
    order = ["MERGE", "SKIP-DRIFTED", "OVERWRITE", "ADD", "RETIRE", "PRESERVE", "GENERATED"]
    label = {
        "MERGE": "MERGE — needs your/agent judgment (staged as .kit-incoming)",
        "SKIP-DRIFTED": "DRIFTED — your edits / v5-v6; kit staged as .kit-incoming",
        "OVERWRITE": "OVERWRITE — stock v4 → this kit, bugfixes (safe)",
        "ADD": "ADD — new files in this kit",
        "RETIRE": "RETIRE — superseded by this kit (removed only with consent)",
        "PRESERVE": "PRESERVE — your state, untouched",
        "GENERATED": "GENERATED — regenerated after migrate",
    }
    for a in order:
        items = plan[a]
        if not items:
            continue
        print(f"\n## {label[a]}  ({len(items)})")
        for rel, note in items:
            print(f"   {rel:<42} {note}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Migrate a v4/v5 project onto the current kit (v6.1) safely.")
    ap.add_argument("--kit", required=True, help="path to the unpacked kit folder")
    ap.add_argument("--project", default=".", help="path to your project (default: cwd)")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--plan", action="store_true", help="classify only (default)")
    g.add_argument("--apply", action="store_true", help="apply OVERWRITE/ADD, stage MERGE")
    ap.add_argument("--remove-retired", action="store_true",
                    help="also delete retired files (setup.sh, verification/audit_sins.*) on --apply")
    args = ap.parse_args()

    project = Path(args.project).resolve()
    kit = Path(args.kit).resolve()
    if not (kit / "migrate" / "v4_baseline.sha256").exists():
        print(f"ERROR: {kit} doesn't look like a kit folder (no migrate/v4_baseline.sha256).")
        sys.exit(2)
    if kit == project:
        print("ERROR: --kit and --project are the same folder. Unpack the kit elsewhere.")
        sys.exit(2)

    plan = classify(project, kit)
    print(f"Migration plan for: {project}\n(kit: {kit})")
    print_plan(plan)

    if args.apply:
        print("\n— applying —")
        apply(project, kit, plan, args.remove_retired)
    else:
        print("\n(plan only — nothing changed. Re-run with --apply to execute.)")


if __name__ == "__main__":
    main()
