#!/usr/bin/env python3
"""
merge_sins.py — deterministically merge the kit's generic SinsGotchasLearnings entries
INTO your project's file, AFTER your real incidents, renumbered to avoid collisions.

Why a dedicated tool: both files number entries `## N.` starting at 1, so a naive
concatenation produces duplicate numbers that break the index/audit generators. This
appends the kit's entries with fresh sequential numbers continuing from your highest, and
skips any incoming entry whose title you already have (so re-running is idempotent and you
don't get two "Silent-Zero" entries if yours already covers it).

Your entries are kept verbatim and FIRST — your project incidents are the point of the
file; the generic kit ones are backstops appended below.

Usage:
    python migrate/merge_sins.py --mine SinsGotchasLearnings.md \
                                 --incoming SinsGotchasLearnings.md.kit-incoming \
                                 [--out SinsGotchasLearnings.md] [--dry-run]
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

ENTRY_RE = re.compile(r"(?ms)^## (\d+)\.\s+(.+?)(?=\n## \d+\.|\Z)")


def split_entries(md: str) -> tuple[str, list[tuple[int, str, str]]]:
    """Return (preamble_before_first_entry, [(num, title, full_block), ...])."""
    first = ENTRY_RE.search(md)
    preamble = md[: first.start()] if first else md
    entries = []
    for m in ENTRY_RE.finditer(md):
        num = int(m.group(1))
        title = m.group(2).splitlines()[0].strip()
        entries.append((num, title, m.group(0).rstrip()))
    return preamble, entries


def norm_title(t: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", t.lower()).strip()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mine", required=True)
    ap.add_argument("--incoming", required=True)
    ap.add_argument("--out")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    mine_md = Path(args.mine).read_text(encoding="utf-8")
    inc_md = Path(args.incoming).read_text(encoding="utf-8")

    preamble, mine_entries = split_entries(mine_md)
    _, inc_entries = split_entries(inc_md)

    mine_titles = {norm_title(t) for _, t, _ in mine_entries}
    max_num = max((n for n, _, _ in mine_entries), default=0)

    appended, skipped = [], []
    next_num = max_num + 1
    for _, title, block in inc_entries:
        if norm_title(title) in mine_titles:
            skipped.append(title)
            continue
        # renumber the entry's header to next_num
        renum = re.sub(r"^## \d+\.", f"## {next_num}.", block, count=1)  # ast-grep-ignore (markdown line-scan, sanctioned)
        appended.append(renum)
        next_num += 1

    print(f"yours: {len(mine_entries)} entries (max #{max_num})")
    print(f"kit incoming: {len(inc_entries)} entries")
    print(f"  → appending {len(appended)} (renumbered #{max_num+1}–#{next_num-1})")
    if skipped:
        print(f"  → skipping {len(skipped)} already covered by title:")
        for t in skipped:
            print(f"      · {t}")

    if not appended:
        print("\nNothing to append (all incoming entries already covered). No change.")
        return

    banner = (
        "\n\n---\n\n"
        "<!-- ===== kit generic backstop entries (appended by migrate/merge_sins.py) =====\n"
        "     These are the universal defaults shipped with Sud's Vibe Coding Kit (v6.1).\n"
        "     Your project-specific incidents are ABOVE. Delete any of these that don't\n"
        "     apply to this project. -->\n\n"
    )
    merged = preamble.rstrip() + "\n\n" + "\n\n".join(b for _, _, b in
             [(n, t, blk) for n, t, blk in mine_entries]) + banner + "\n\n".join(appended) + "\n"

    if args.dry_run:
        print("\n(dry-run — not written. Re-run without --dry-run to write.)")
        return

    out = Path(args.out or args.mine)
    out.write_text(merged, encoding="utf-8")
    print(f"\n✓ wrote {out} ({len(mine_entries)+len(appended)} entries total)")
    print("Now run:  just sins-sync   (regenerates the audit runner + index)")
    print(f"Then delete the staged file: {args.incoming}")


if __name__ == "__main__":
    main()
