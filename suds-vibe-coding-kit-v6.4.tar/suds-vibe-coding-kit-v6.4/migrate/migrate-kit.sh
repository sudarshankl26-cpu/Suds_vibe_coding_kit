#!/usr/bin/env bash
# Migrate an ongoing v4/v5 project onto the current Sud's Vibe Coding Kit — safely.
# Run from INSIDE your existing project. Plan-only by default; --apply to execute.
#
#   Step 1: unpack the kit tar OUTSIDE this project:
#       tar -xf suds-vibe-coding-kit-v6.4.tar -C /tmp/
#   Step 2 (plan):   bash migrate/migrate-kit.sh --kit /tmp/suds-vibe-coding-kit-v6.4
#   Step 3 (apply):  bash migrate/migrate-kit.sh --kit /tmp/suds-vibe-coding-kit-v6.4 --apply
set -uo pipefail

KIT=""; MODE="--plan"; EXTRA=""
while [ $# -gt 0 ]; do
  case "$1" in
    --kit) KIT="$2"; shift 2;;
    --apply) MODE="--apply"; shift;;
    --remove-retired) EXTRA="--remove-retired"; shift;;
    *) echo "unknown arg: $1"; exit 2;;
  esac
done
[ -z "$KIT" ] && { echo "usage: bash migrate/migrate-kit.sh --kit <path-to-unpacked-kit> [--apply]"; exit 2; }

PROJECT="$(pwd)"  # your project = where you are standing, not where the kit is
PY="$(command -v python3 || command -v python)"
[ -z "$PY" ] && { echo "[ERROR] Python not found in PATH."; exit 1; }

"$PY" "$KIT/migrate/migrate_kit.py" --kit "$KIT" --project "$PROJECT" $MODE $EXTRA
