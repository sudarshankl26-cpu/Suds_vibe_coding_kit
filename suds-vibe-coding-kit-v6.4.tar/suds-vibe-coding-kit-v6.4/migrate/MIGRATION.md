# MIGRATION.md — upgrading an ongoing v4/v5 project onto the current kit (v6.1)

> Read this fully before running anything. The migration is deterministic and reversible,
> but the MERGE steps need your judgment. This file is written for the coding agent to
> follow with the user; a human can follow it directly too.
>
> **Already on v6?** Use the lighter manual swap in `MIGRATION_v6.1.md` instead — it's a
> drop-in replacement of ~15 infra files with no classification step. This migrator is for
> v4/v5 projects (or any time you want the full classify + backup + branch safety net).

## What the migration guarantees

- **Your work is never overwritten.** Project state and contracts (`STATE.md`, `PRD.md`,
  `GLOSSARY.md`, `DATA_MODEL.md`, `ARCHITECTURE.md`, your `SinsGotchasLearnings.md`, all
  logs, `.env`, `src/`, `docs/adr/`, `tests/`) are PRESERVED untouched.
- **Only stock-v4 infrastructure is auto-upgraded.** A kit script is overwritten *only if
  your copy is byte-identical to the original v4* (checked by hash against
  `migrate/v4_baseline.sha256`). If your agent edited it — or you're already on v5/v6 — it is
  NOT overwritten; the new version is staged for review as `.kit-incoming` instead.
- **Reversible.** `--apply` first makes a timestamped backup folder AND a git branch.
- **Idempotent.** Re-running is safe; already-migrated files are detected and skipped.

## What this kit (v6.1) adds (so you know what you're gaining)

- **ast-grep audits** replace the old single-line grep recipes (`rules/*.sins.yml` +
  `sgconfig.yml`); CSS/multiline defects are now expressible, and a rule can't match its own
  comment. The old `verification/audit_sins.{sh,py}` are retired.
- **`just verify` / `just verify-all` split** — code gates stay green mid-work; bookkeeping +
  `smoke` run on commit/CI. No more red-while-you-build.
- **Passive, timezone-aware prompt log** — ordering is a note, not a failure; capture hooks
  filter out tool-echoes and file dumps. (Kills the v6 "rewrite the timestamps" time-sink.)
- **Self-healing sins audit** (`audit-sins` auto-regenerates; no STALE-AUDIT loop), the
  always-on failure-mode digest in `AGENTS.md` §0b, `mise` toolchain pin, and a portable
  Playwright `smoke` gate + template.

## Procedure

### 1. Unpack the kit OUTSIDE the project
```bash
tar -xf suds-vibe-coding-kit-v6.4.tar -C /tmp/        # → /tmp/suds-vibe-coding-kit-v6.4
```
(The `migrate/` folder, including this guide and the tools, lives inside that unpacked kit.
You can run the tools from there even though they're not in your project yet.)

### 2. See the plan (changes nothing)
```bash
python /tmp/suds-vibe-coding-kit-v6.4/migrate/migrate_kit.py \
    --kit /tmp/suds-vibe-coding-kit-v6.4 --project . --plan
```
Read every line. The categories: PRESERVE (untouched), OVERWRITE (safe bugfix), ADD
(new files), MERGE / DRIFTED (need you), RETIRE (superseded), GENERATED (rebuilt after).

> On a v5/v6 project, expect most infra to land under DRIFTED rather than OVERWRITE — that's
> the safe path (nothing auto-replaced; everything staged for you to accept). It just means a
> few more `.kit-incoming` files to wave through in step 4.

### 3. Apply (branch + backup, then auto-apply the safe parts)
```bash
python /tmp/suds-vibe-coding-kit-v6.4/migrate/migrate_kit.py \
    --kit /tmp/suds-vibe-coding-kit-v6.4 --project . --apply
#   add --remove-retired to also delete setup.sh and the old verification/audit_sins.{sh,py}
```
After this: OVERWRITE + ADD are done. Each MERGE/DRIFTED file has its kit version sitting
next to yours as `<file>.kit-incoming`. Nothing of yours is gone.

### 4. Resolve each `.kit-incoming` — the judgment part

**Agent: walk the user through these ONE AT A TIME. For each, show a diff, explain what the
kit changed, recommend an action, apply only on confirmation.**

- **`SinsGotchasLearnings.md.kit-incoming`** — use the dedicated merge tool (don't hand-merge):
  ```bash
  python /tmp/suds-vibe-coding-kit-v6.4/migrate/merge_sins.py \
      --mine SinsGotchasLearnings.md \
      --incoming SinsGotchasLearnings.md.kit-incoming
  ```
  It keeps your incidents first and verbatim, appends the kit's generic entries below them
  with fresh numbers, and skips any entry whose title you already cover. Then delete the
  `.kit-incoming` file.

- **`AGENTS.md.kit-incoming`** — v6.1 rewrote §0a (lightweight per-turn loop), added §0b (the
  always-on failure-mode digest) and the §3 verify/verify-all split. Diff against yours and
  pull those sections in; keep any project-specific anti-patterns you added. Then delete
  `.kit-incoming`.

- **`EXECUTION_PLAN.md.kit-incoming`** — take the in-place Phase 0 and the server-script /
  `smoke` phase; keep all your real project phases. Then delete `.kit-incoming`.

- **`skills/grill-to-prd.md.kit-incoming`** — usually safe to take wholesale unless you
  customized the grill. Then delete `.kit-incoming`.

- **`RepoMapReadFirst.md.kit-incoming`** — do NOT take the kit's (it's an empty skeleton).
  Keep yours; just delete the `.kit-incoming`. Regenerate later with `just map-sync`.

- **Any other `*.kit-incoming` (DRIFTED)** — kit infrastructure (scripts, justfile, verify.ps1,
  hooks, configs). On a v5/v6 project the v6.1 versions here are what give you ast-grep + the
  verify split, so you'll usually accept them; diff first if you'd customized one.

### 5. Finish the enforcement swap + adopt the v6.1 bits
- Install `mise` once (`winget install jdx.mise` / `curl https://mise.run | sh`), then
  `mise install` in the project (provisions `just`/`uv`/`node`/`pnpm`/**`ast-grep`**).
- Delete the retired grep engine if it's still around (or you skipped `--remove-retired`):
  `rm -f verification/audit_sins.sh verification/audit_sins.py`.
- Confirm `sgconfig.yml` and `.mise.toml` landed (they're added/staged above).
- Reinstall the commit hook to run the full set: re-run the scaffold's hook step, or write
  `.git/hooks/pre-commit` to `exec just verify-all`.

### 6. Regenerate and verify
```bash
just sins-sync && just map-sync     # rebuild ast-grep rules, index, repo map
just verify-all                      # everything must be green before you keep the branch
```

### 7. Keep or roll back
- Keep: merge the `migrate-kit-*` branch into your main branch.
- Roll back: `git checkout -` and delete the branch, or restore from `.kit-backup-*/`.
  Then delete leftover `*.kit-incoming` and the backup folder.

## The one rule for the agent

Do not auto-resolve MERGE files. Do not overwrite anything outside what the migrator's
`--apply` already did. Your job in step 4 is to diff, explain, recommend, and apply only on
the user's confirmation — one file at a time.
