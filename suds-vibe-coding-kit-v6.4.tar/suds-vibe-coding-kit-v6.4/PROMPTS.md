# PROMPTS.md — the reusable prompt library

Copy-paste prompts for each stage. The design principle behind all of them: **make the agent
produce a contract artifact, not prose.** Prose you read once; a contract the agent re-reads
every session. Every prompt below ends by writing or updating a file in this repo, which is
what makes the documentation *living* instead of a one-time dump.

---

## K. Learnings system (turn every bug into a durable safeguard)

**Capture a new bug as a learning (run right after fixing any non-trivial bug):**

> We just fixed <bug>. Add it to `SinsGotchasLearnings.md` as a new numbered entry using the
> structure Incident / Why It's Dangerous / Rule. Capture it as **prose** — that's the default.
> Then ask: can this be enforced higher up — as a type in `types/`, a `tsc`/`mypy` rule, or a
> GLOSSARY/DATA_MODEL fact? If so, do that. Only if the defect is a clean *structural* code
> pattern, add an optional `### Audit Rule` (an ast-grep YAML; prefer a simple `pattern:`). Do
> NOT engineer a pattern to dodge false matches — if it's not obvious, leave it prose. No need
> to run sins-sync (audit-sins self-heals). Do not invent an incident that didn't happen.

**Use the learnings at session start (cheap):**

> The always-on digest is `AGENTS.md` §0b. For anything deeper, read
> `SinsGotchasLearnings_INDEX.md` and open the full entry only for areas you're about to touch.
> The ⚙ entries are already enforced by `just verify` (ast-grep), so don't re-check them by
> hand — trust the gate.

**Handle an approved exception (don't weaken the gate):**

> A sins audit flags a line that is an intentional, architecture-approved exception. Do NOT
> delete the rule. Put `# ast-grep-ignore` (Python/CSS) or `// ast-grep-ignore` (TS/JS) on the
> line above it and justify it in the commit message.

**Keep data contracts in sync:**

> I'm changing a DB column's scale/unit or adding/removing a table the app relies on. Update
> `types/schema_rules.json` to match, in the same commit, so `just verify-schema` stays green.
> If a `*_rate` column will legitimately exceed 1.0, fix the column name or the contract — do
> not just raise max_value to hide a real unit bug.

**Triage audit failures:**

> `just verify` failed on the sins audit (rule `<id>`). Open the matching entry in
> `SinsGotchasLearnings.md`, confirm whether the flagged code is a real instance of the defect
> or a false positive. If real, fix the code. If the rule is genuinely too broad, lower its
> `severity:` to `warning` (a note) or refine the ast-grep pattern — do not delete the rule to
> make the build pass.

---

## G0. Grill me into a PRD (run before any new project/feature)

> Run `skills/grill-to-prd.md`: interview me one question at a time, recommend an answer
> for each, walk the dependency tree, sharpen vague terms into GLOSSARY.md inline, probe
> edge cases with concrete scenarios, and offer an ADR only for hard-to-reverse, surprising,
> real-trade-off decisions. When every branch is resolved, write PRD.md with a long
> exhaustive user-story list, then proceed in authoring order.

## G1. Re-orient cheaply (instead of re-walking the tree)

> Read `RepoMapReadFirst.md` to understand the structure. Do not walk the file tree to
> rediscover it. If the map looks stale, run `just map-sync`, then read it.

## A. Requirement gathering (before any code)

> You are a product engineer interviewing me to fill in `PRD.md`. Do NOT write code or the PRD
> yet. Ask me the smallest set of questions that would change the design, **one cluster at a
> time**, starting with: who the single primary user is, the one job they hire this for, and
> the sharpest anti-goal (what it must NOT do). When you have enough to write a section, draft
> just that section, show it, and wait for my correction before moving on. We are filling the
> contract, not brainstorming.

Why it works: forces elicitation before generation (your AGENTS.md §6 ethos), and the output
lands in the contract file, not the chat.

---

## B. Pressure-test the PRD (catch scope creep early)

> Read `PRD.md`. Act as a skeptical staff engineer. List the three assumptions in here most
> likely to be wrong or to explode scope, and for each, the cheapest experiment or the
> smallest scope cut that de-risks it. Then propose any anti-goals I should add to §5. Output
> as edits to PRD.md, not loose commentary.

---

## C. Glossary extraction (kills definition drift — the #1 subtle-bug source)

> Read `PRD.md`. Extract every domain noun and verb that has a specific meaning. For each,
> draft a `GLOSSARY.md` entry: definition, canonical code identifier, aliases to avoid, one
> concrete example, one "NOT" line. Flag any term used with two different meanings — those are
> drift bugs waiting to happen; propose two distinct names. Write to GLOSSARY.md.

---

## D. User stories → execution phases (the bridge most people skip)

> Read `PRD.md` §4 and `GLOSSARY.md`. Turn capabilities into user stories in the form
> "As a <persona>, I can <capability> so that <outcome>", each with 2–4 acceptance criteria
> phrased as testable assertions (not feelings). Then group the stories into the smallest
> sequence of shippable phases where each phase is independently verifiable, and write them
> into `EXECUTION_PLAN.md` using the phase template already in that file. Each phase must name
> its manual verification step. Do not write code.

---

## E. Data model from stories (grain + units pinned)

> Read `EXECUTION_PLAN.md` and `GLOSSARY.md`. Propose the entities needed for Phases 0–N.
> For each: grain (the columns that make a row unique), every column with its **units stated
> explicitly** (decimals-vs-percent, cents-vs-dollars, UTC), nullability + the *meaning* of
> NULL, and invariants beyond the schema. List grain hazards (joins that fan out). Write to
> `DATA_MODEL.md` and the corresponding `types/`. Stop and ask on any ambiguity rather than
> picking a unit silently.

---

## F. Start / resume a build session (the token-saver)

> Read `CONTEXT.md`, then `STATE.md`. Tell me in two sentences where we are and what the next
> task is. Then execute that task per `EXECUTION_PLAN.md`, following `AGENTS.md`. Update
> `STATE.md` when the task is done or blocked. Run `just verify` while working and
> `just verify-all` before claiming done.

This is the everyday driver. Because it reads `STATE.md` first, the agent spends ~200 tokens
orienting instead of re-ingesting the whole plan.

---

## G. New library (enforces the verification protocol)

> Before using <library>, follow AGENTS.md §4: run `just add-<py|ts> <library>`, then write
> `verification/verify_<library>.<py|ts>` exercising the exact API surface you'll use, run it,
> and only then write real code. Show me the verification output first.

---

## H. Living-documentation sync (run at the end of every phase)

> A phase just completed. Reconcile the docs with reality, as separate commits from the code:
> (1) Does any new term need a `GLOSSARY.md` entry? (2) Did the schema or `types/` shape
> change — if so, is there an explicit migration and is `DATA_MODEL.md` updated? (3) Did any
> ARCHITECTURE tech choice change — add a `CHANGE:` note. (4) Update `STATE.md`'s YAML block
> and clear any `open_decisions` you've now formalized. (5) Sweep the phase's files for
> `#PLAN_UNCERTAINTY` tags (AGENTS.md §1a) — resolve each (validate it, make it a PRD open
> question, or write an ADR) and remove the tag; flag any `#EXPORT_CRITICAL` you had to touch.
> Report what you changed in one line each. Do not invent changes that didn't happen.

This is the mechanism that keeps docs *living*. Without a scheduled reconciliation prompt,
docs rot the moment code moves past them.

---

## I. Drift audit (run weekly or when something feels off)

> Audit this repo for contract drift, read-only, propose fixes as a list I approve before you
> apply: (1) terms in code absent from `GLOSSARY.md`; (2) fields in `types/` absent from
> `DATA_MODEL.md` or vice versa; (3) any `any`/`Optional`/`List` legacy types; (4) `try/except
> pass` or empty catches; (5) regex parsing of SQL/JSON/HTML/TS; (6) `STATE.md` claims that
> don't match the actual code state; (7) any `#PLAN_UNCERTAINTY` tags still unresolved, or an
> `#EXPORT_CRITICAL` constraint the code now violates (AGENTS.md §1a). Output a table: issue ·
> file · proposed fix.

---

## J. Handoff between tools

> I'm switching from <tool A> to <tool B>. Update `STATE.md` so the next agent can resume cold:
> current phase/task, anything half-done, anything blocked, and any decision made this session
> not yet in a contract file (put those in `open_decisions`). Leave the repo `just verify-all`-green.

---

## L. Eval-first for a hard unit (raise quality where it's hardest)

Use this before implementing any unit with complex/branchy logic, edge-case handling, input/
data validation, a parser, or money/units/date math (AGENTS.md §4a).

> Before you implement <unit>, treat it as a hard part (AGENTS.md §4a). First, list the edge
> cases that matter as a short table — empty/null, zero vs missing, boundary values, malformed
> input, the tricky state transition. Write those as **failing tests** in `tests/` (pytest /
> vitest). Then implement until `just verify` is green, and leave the edge-case list next to the
> test. Do not declare done until the tests pass.

---

## M. You're stuck — escalate instead of thrashing

Use this when the same test/error has resisted ~3 fix attempts (AGENTS.md §6a).

> The same test/error has failed ~3 times. Stop guessing and follow AGENTS.md §6a: read the
> full error + LSP/type-checker output (`mypy`/`tsc`); run a tiny `verification/verify_<lib>`
> probe; and **search the web / Context7 freely** — your training has a cutoff, so look up the
> exact error string, the library's *current* API, and any recent breaking changes (don't ration
> the search). Use whichever of these this environment has. Tell me what you found, then make the
> next attempt — do not stop to ask me unless it turns out to be an ambiguous requirement rather
> than a solvable bug.

---

## N. Plan a long/complex task (phased plan file)

Use this before starting anything large — >3 files, a refactor, or >~300k expected tokens
(AGENTS.md §4b).

> This is a long/complex task. Before coding, follow AGENTS.md §4b: write a working plan to
> `plans/<meaningful-slug>-YYYY-MM-DD.md` (use `skills/templates/plan.md.template`). Break it
> into phases so each phase's execution stays within ~300k tokens, is independently shippable,
> and ends green on `just verify`. For exploration use a read-only pass first; use the higher
> reasoning-effort tier for the planning step. Show me the plan before executing, then execute
> phase by phase, committing and updating STATE.md after each.

## O. Delegate a phase to subagents (if the tool supports it)

Use this when a phase touches ~10+ files or has 3+ independent slices (AGENTS.md §4b).

> Execute this phase using the Explore → Plan → Execute pattern. First, an explore (read-only)
> subagent maps the relevant files and returns a summary. Then fan the independent slices out to
> parallel subagents (e.g. one writes the migration, one updates tests, one drafts docs), each
> with a specific task subject and its own budget; keep any dependent work in a single session.
> A stuck subagent runs the §6a ladder (and may spawn a debugger subagent up to ~3×) rather than
> thrashing. If this tool has no subagents, just run the slices sequentially.

## P. Flag constraints & assumptions inline (don't lose them between sessions)

Use whenever you must assume something to keep moving, or you hit a rule that must never be
crossed (AGENTS.md §1a). Cheaper than a transcript nobody re-reads.

> As you work, mark three things inline with text tags (AGENTS.md §1a), kept rare and real:
> tag a non-negotiable constraint `#EXPORT_CRITICAL` next to where it lives and never silently
> weaken it; when you assume rather than ask, drop a `#PLAN_UNCERTAINTY` at the assumption and
> resolve it before the phase is done; leave a one-line `#PATH_DECISION` when you pick a road
> with a real trade-off that's too small for an ADR. Don't tag trivia — only the few things
> that would bite the next agent (or the next tool — §8).

---

## Q. Build UI without "AI slop" (paste alongside any visual build task)

Use whenever the agent will produce a visual surface — an app screen, a dashboard, a generated
HTML report, a slide. It encodes `DESIGN_GUIDELINES.md` into the build prompt so the model makes
*decided* choices instead of emitting its defaults. (If the PRD already defines a design language,
say "follow the PRD design language" and keep only the consistency clause.)

> Build this UI to look **intentional and consistent**, not AI-generated. Follow
> `DESIGN_GUIDELINES.md`. Specifically:
> • **Icons:** one professional SVG set only (Lucide / Phosphor / Heroicons), one stroke width
>   (~1.5px), one size scale. **No emojis, ASCII art, or OS glyphs as icons.**
> • **Color:** a neutral base (one grey scale — zinc/slate/neutral) for ~90% of the UI + exactly
>   one muted accent for primary actions. No saturated primaries, no rainbow gradients. Off-white
>   (`#FAFAFA`) light mode; dark-grey (never pure black) dark mode.
> • **Type:** one clean sans (Inter / Geist / system-ui), strict hierarchy, constrained weights
>   (regular body, medium/semibold headings). No decorative fonts.
> • **Layout:** structure from whitespace + subtle 1px borders, not filled colored blocks.
>   Consistent radii (one or two values); fully-round only for avatars/pills. Subtle shadows only
>   on floating elements (modals/dropdowns) — not every card. No gratuitous glassmorphism or
>   neo-brutalism unless I asked for it.
> Before you call it done, run the "is this slop?" checklist in `DESIGN_GUIDELINES.md`.

---

## Prompt-design principles (so you can write your own)

1. **End in an artifact.** "Write to GLOSSARY.md" beats "tell me the terms."
2. **One cluster of questions at a time.** Elicitation, not interrogation.
3. **Acceptance criteria as assertions**, never as adjectives ("loads in <200ms", not "fast").
4. **Read STATE.md first** in any resume prompt — it's the cheapest orientation.
5. **Separate doc-edits from code** in the instruction itself, so commits stay clean.
6. **"Stop and ask on ambiguity"** in any generative prompt — cheaper than rework.
