<#
.SYNOPSIS
    Run the verification gate with NO `just` and NO bash - pure PowerShell + Python.
.DESCRIPTION
    Equivalent to `just verify` (code gates only). Use this on a Windows machine where `just`
    isn't installed or is misbehaving. Runs each gate via the cross-platform Python helpers;
    fails (non-zero exit) if any configured tool fails, matching the real gate's semantics.

    By default it runs the CODE gates (lint/typecheck/test/libs/schema/sins/dox) — the same as
    `just verify`, safe to run mid-work. Add -All to also run the bookkeeping gates (tasks +
    prompt log) and the app smoke test — the same as `just verify-all`, what the pre-commit
    hook runs before a commit.

    Run from your PROJECT ROOT:   .\verify.ps1        (code gates)
                                  .\verify.ps1 -All   (everything, pre-commit set)
#>
param([switch]$All)

$ErrorActionPreference = "Continue"

$py = $null
foreach ($c in @('python','python3','py')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $py = $cmd; break }
}
if (-not $py) { Write-Host "[ERROR] Python not found on PATH." -ForegroundColor Red; exit 1 }
$PY = $py.Source

$fail = 0
function Gate($label, [scriptblock]$cmd) {
    Write-Host "== $label ==" -ForegroundColor Cyan
    & $cmd
    if ($LASTEXITCODE -ne 0) { $script:fail = $LASTEXITCODE; Write-Host "  FAILED ($label)" -ForegroundColor Red }
}

# --- Code / correctness gates (always) ---
Gate "lint"          { & $PY scripts/run_gate.py lint }
Gate "typecheck"     { & $PY scripts/run_gate.py typecheck }
Gate "test"          { & $PY scripts/run_gate.py test }
Gate "verify-libs"   { & $PY scripts/run_gate.py verify-libs }
Gate "verify-schema" { & $PY verification/audit_schema.py }
Gate "audit-sins"    { & $PY scripts/sins.py audit }
Gate "dox-check"     { & $PY scripts/dox_check.py }

# --- Bookkeeping + smoke gates (only with -All / pre-commit / CI) ---
if ($All) {
    Gate "check-tasks"      { & $PY verification/check_open_tasks.py }
    Gate "check-prompt-log" { & $PY verification/check_prompt_log.py }
    Gate "smoke"            { & $PY scripts/run_gate.py smoke }
}

if ($fail -ne 0) {
    Write-Host "`nVerification FAILED." -ForegroundColor Red
    exit $fail
}
$scope = if ($All) { "All verification gates passed." } else { "Code gates passed (run .\verify.ps1 -All before committing)." }
Write-Host "`n$scope" -ForegroundColor Green
exit 0
