# {Short title of the decision}

{1-3 sentences: what's the context, what did we decide, and why.}

<!-- Optional, only if they add value:
Status: proposed | accepted | deprecated | superseded by ADR-NNNN
Considered options: ...
Consequences: ...
-->
