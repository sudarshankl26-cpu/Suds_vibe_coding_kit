# WorkLogAfterEachRun

Append-only record of what the agent actually delivered. Write **one short entry per session
that shipped something** — not one per micro-step. Pairs with UserPromptLog.md: that captures
what was *asked*, this captures what was *delivered*. The gap between them is the audit trail.
(The post-commit git hook also appends a one-line commit stamp here as a backstop.)

Keep it terse — a few lines, not a transcript:

```
## <ISO date time> — <phase/task>
**Did:** <what was built/changed, 1–3 sentences>
**Deferred/blocked + why:** <explicit; "none" only if truly none — this is the anti-drop check>
**Verify:** <`just verify-all` pass/fail>
**Next:** <the single next action>
```

---

<!-- APPEND BELOW. Newest at the bottom. Never edit entries above. -->
