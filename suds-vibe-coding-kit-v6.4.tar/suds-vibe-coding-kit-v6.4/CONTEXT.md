# CONTEXT — START HERE

You are an AI agent working on this repo. This file routes you; it contains no rules of its
own (so it can't drift). The rules live in `AGENTS.md`.

## Do this, in order

1. **`RepoMapReadFirst.md`** — the living codebase map. Read this instead of re-walking
   the file tree. ~2k tokens vs 50k+ to rediscover structure.
2. **`STATE.md`** — where the build is right now. ~200 tokens.
3. **`AGENTS.md`** — the rules you must follow. §0 is the session-start protocol.
4. Then the contracts, as needed for your task:
   - `PRD.md` — what & why
   - `GLOSSARY.md` — exact term meanings (never invent terms)
   - `DATA_MODEL.md` — entities, grain, invariants (never invent fields)
   - `ARCHITECTURE.md` — how it fits, tech choices, anti-goals
   - `DESIGN_GUIDELINES.md` — default visual standard (anti-AI-slop), if the project has a UI
   - `types/` — code-level contracts
5. **`EXECUTION_PLAN.md`** — the phase named in `STATE.md`. Execute one phase at a time.
6. **Big or complex task?** (more than a handful of files / a refactor / won't fit one focused
   session) write a dated working plan in `plans/` and execute it in phases, delegating to
   subagents where supported (AGENTS.md §4b).
7. **Non-frontier model?** (GLM / DeepSeek / MiniMax / MiMo) skim `MODEL_NOTES.md` once for
   context-budget and reasoning-effort tips.

## Per-turn discipline (lightweight — see AGENTS.md §0a)

Prompts log themselves verbatim via hooks (Claude Code/OpenCode) — `UserPromptLog.md` is
passive evidence you never edit or re-stamp; only in a hook-less tool do you append it
yourself, inside the fence, exactly as typed. Put the real **deliverables** (not process
steps) in `OpenTasksMustCompleteAll.md` as `[ ]` and reconcile them before "done". Skim §0b
of AGENTS.md (and `SinsGotchasLearnings_INDEX.md` for the area you touch) before coding.
Capture a new learning as a prose `SinsGotchasLearnings.md` entry (an ast-grep `### Audit
Rule` only if structural). One short `WorkLogAfterEachRun.md` entry per shipping session. For
new projects/features, run the `skills/grill-to-prd.md` interview before writing PRD.md.

## The one rule that matters most

`STATE.md` is yours to edit. The contract files are not — changing them is a separate,
deliberate commit (AGENTS.md §5). When in doubt, **stop and ask** (AGENTS.md §6).

## Commands

`just verify` (fast code gates — run freely) · `just verify-all` (everything; pre-commit) ·
`just test` · `just lint` · `just typecheck` · `just add-py <pkg>` · `just add-ts <pkg>`
