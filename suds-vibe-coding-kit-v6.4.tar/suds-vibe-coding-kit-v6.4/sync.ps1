<#
.SYNOPSIS
    Regenerate the kit's living artifacts with NO `just` and NO bash - pure PowerShell + Python.
.DESCRIPTION
    Equivalent to `just sins-sync` followed by `just map-sync`. Run after editing
    SinsGotchasLearnings.md, or whenever the audit runner / index / repo map need rebuilding.

    Run from your PROJECT ROOT:  .\sync.ps1
#>
$ErrorActionPreference = "Stop"

$py = $null
foreach ($c in @('python','python3','py')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $py = $cmd; break }
}
if (-not $py) { Write-Host "[ERROR] Python not found on PATH." -ForegroundColor Red; exit 1 }
$PY = $py.Source

Write-Host "== sins-sync ==" -ForegroundColor Cyan
& $PY scripts/sins.py sync

if (Test-Path scripts/build_repo_map.py) {
    Write-Host "== map-sync ==" -ForegroundColor Cyan
    & $PY scripts/build_repo_map.py
}

Write-Host "`nArtifacts regenerated." -ForegroundColor Green
