# DESIGN_GUIDELINES.md — the default visual standard (anti "AI-slop")

> **Applies only if this project renders a UI** — web, desktop, mobile, or any visual surface,
> including generated HTML reports, dashboards, and slide decks. For a CLI, a library, or a data
> pipeline, ignore this file. It is a **contract**: treat it like PRD / DATA_MODEL — don't edit
> it inside a feature commit, and if the project needs a different look, change *this file first*
> (a separate commit) so the standard and the code never drift.

## The one principle

**Good design reads as *intentional and consistent*; "AI slop" reads as *the model's defaults*.**
The tells listed below aren't bad because minimalism is the only good taste — they're bad because
they're what a model emits when nobody decided anything. So: either follow the defaults here, or
make a **deliberate, documented, consistent** choice in the PRD's design language and apply it
everywhere. The real defect is incoherence, not any single color or radius.

If the PRD / grill already defined a design language (brand colors, a chosen aesthetic, a
component library), **that wins.** Tag the non-negotiable parts `#EXPORT_CRITICAL` (AGENTS.md
§1a) and follow them. The defaults below apply **only when nothing else was specified.**

## Defaults when nothing else is specified

**Icons & graphics.** One professional SVG icon set (e.g. Lucide, Phosphor, Heroicons) and
nothing else — one consistent stroke width (~1.5px) and one size scale. **No emojis, ASCII art,
or default OS/emoji glyphs standing in for icons.** (Emojis inside user *content* or copy are
fine when the product calls for it; this rule is about interface chrome.)

**Color.** A restrained, mostly-neutral base — a single grey scale (zinc / slate / neutral) for
~90% of the surface — plus **exactly one** muted accent for primary actions. Avoid pure saturated
primaries (`#0000FF`, `#FF0000`), rainbow gradients, and uncalibrated defaults. Light mode: white
or a soft off-white (`#FAFAFA`), not stark. Dark mode: a dark grey — **never pure black.**

**Typography.** One clean modern sans (Inter, Geist, or `system-ui`) with a strict hierarchy and
constrained weights (regular body; medium/semibold headings). No decorative or novelty faces. Set
line-height and line-length for reading, not for filling space.

**Layout & effects.** Build structure from **whitespace and subtle 1px borders**, not from filled
colored blocks. Consistent corner radii (one or two values, e.g. `rounded-md`/`rounded-lg`);
fully-round only for things that mean it (avatars, pills). Shadows are **subtle and reserved for
genuinely floating layers** (modals, dropdowns, popovers) — not on every card. Avoid gratuitous
glassmorphism, neo-brutalism, and heavy drop shadows unless the design language explicitly asks
for them.

**Motion.** Subtle, fast, purposeful (≤ ~200ms, ease-out), only where it aids comprehension. No
gratuitous bounce, parallax, or autoplaying movement.

## The "is this slop?" checklist (run before calling a UI phase done)

- [ ] One icon set, one stroke width — no emoji / ASCII / OS glyphs as icons.
- [ ] One neutral base + one accent; no saturated primaries or rainbow gradients.
- [ ] One sans family, constrained weights, a real type hierarchy.
- [ ] Structure from spacing + 1px borders; consistent radii; shadows only on floating layers.
- [ ] Dark mode (if any) is dark grey, not pure black.
- [ ] The whole screen looks **decided**, not defaulted — and matches the PRD design language.
