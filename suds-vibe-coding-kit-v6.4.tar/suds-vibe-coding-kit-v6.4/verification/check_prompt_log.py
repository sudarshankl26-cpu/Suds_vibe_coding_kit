#!/usr/bin/env python3
"""
check_prompt_log.py — the prompt-audit gate (v6.1: timezone-aware, logs are passive).

UserPromptLog.md is an append-only, hook-captured record. The agent never edits it. This
gate checks the FILE's structural integrity only — it never asks the agent to "fix" content:

  HARD FAIL (real file corruption):
    1. MALFORMED entries — a `## ` line that isn't a parseable `## <ISO timestamp>` header.
    2. ORPHAN prompts — more `**Prompt` blocks than headers (a prompt pasted without a header).

  NOTE only (informational; never fails the build):
    3. OUT-OF-ORDER timestamps — across tools/timezones/clock skew this is normal. v6 made
       this a hard fail AND compared timestamps naively, so cross-tool UTC-vs-local interleave
       looked out-of-order, and the agent "fixed" it by REWRITING the append-only trail. That
       was the single biggest time-sink in v6. It is now a note, and re-stamping is forbidden
       (AGENTS.md). Timestamps are compared as timezone-aware INSTANTS.
    4. STALE vs WorkLog — with hook capture the log can't silently stop; surfaced as a note.

This gate runs in `just verify-all` (and the pre-commit hook), not the mid-work `just verify`.
No-ops cleanly if UserPromptLog.md is absent.
"""
from __future__ import annotations

import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

PROMPT_LOG = Path("UserPromptLog.md")
WORK_LOG = Path("WorkLogAfterEachRun.md")

# Header timestamp: ISO date+time, optionally with seconds and an offset (+05:30 / Z).
HDR = re.compile(
    r"^## (\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?(?:Z|[+-]\d{2}:?\d{2})?)",
    re.MULTILINE,
)


def parse_ts(s: str) -> datetime | None:
    """Parse an ISO timestamp to a timezone-AWARE datetime (normalized to UTC).

    Accepts offset-aware (`2026-06-18T12:06:03+05:30`), UTC `Z`, and naive forms. A naive
    timestamp is assumed to be in the machine's local zone, so cross-tool logs that mix local
    and UTC entries still compare as correct instants instead of tripping a false reorder.
    """
    s = s.strip().replace(" ", "T")
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt: datetime | None = None
    try:
        dt = datetime.fromisoformat(s)
    except ValueError:
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M"):
            try:
                dt = datetime.strptime(s, fmt)
                break
            except ValueError:
                continue
    if dt is None:
        return None
    if dt.tzinfo is None:  # naive -> assume local zone, then compare in UTC
        dt = dt.astimezone()
    return dt.astimezone(timezone.utc)


def body_after_marker(text: str) -> str:
    """Only entries below the APPEND marker are audited; the template header is exempt."""
    m = re.search(r"<!-- APPEND BELOW.*?-->", text)
    return text[m.end():] if m else text


def main() -> None:
    if not PROMPT_LOG.exists():
        print("» no UserPromptLog.md — skipping prompt-log gate")
        return

    text = body_after_marker(PROMPT_LOG.read_text(encoding="utf-8"))
    problems: list[str] = []   # hard fails
    notes: list[str] = []      # informational only

    headers = HDR.findall(text)
    timestamps = [parse_ts(h) for h in headers]

    # 1. Malformed headers: a `## ` line in the body that isn't a parseable timestamp header.
    for line in text.splitlines():
        if line.startswith("## ") and not HDR.match(line):
            problems.append(f"malformed entry header (no ISO timestamp): {line[:90]!r}")
    if None in timestamps:
        problems.append("an entry header timestamp failed to parse as ISO datetime")

    # 2. Orphan prompts: more `**Prompt` markers than headers => a prompt without its header.
    prompt_marks = len(re.findall(r"^\*\*Prompt", text, re.MULTILINE))
    if prompt_marks > len(headers):
        problems.append(
            f"{prompt_marks} prompt blocks but only {len(headers)} entry headers — "
            "at least one prompt was logged without its '## <timestamp>' header"
        )

    # 3. Monotonic order — NOTE only (timezone-aware instants; cross-tool skew is expected).
    ok_ts = [t for t in timestamps if t is not None]
    for a, b in zip(ok_ts, ok_ts[1:]):
        if b < a:
            notes.append(
                f"out-of-order entries ({b.isoformat()} after {a.isoformat()}) — cross-tool "
                "clock skew; this is fine. Do NOT edit past entries to 'fix' it."
            )
            break

    # 4. Staleness vs WorkLog — NOTE only, timezone-aware (hooks make a true stop unlikely).
    lag_min = int(os.environ.get("PROMPTLOG_MAX_LAG_MIN", "240"))
    if lag_min > 0 and WORK_LOG.exists():
        wl_text = body_after_marker(WORK_LOG.read_text(encoding="utf-8"))
        wl_ok = [t for t in (parse_ts(h) for h in HDR.findall(wl_text)) if t is not None]
        if wl_ok and ok_ts:
            lag = (max(wl_ok) - max(ok_ts)).total_seconds()
            if lag > lag_min * 60:
                notes.append(
                    f"prompt log may be stale: newest work entry is {lag/60:.0f} min newer "
                    f"than newest prompt entry (>{lag_min}m). Check the capture hook is firing "
                    "(set PROMPTLOG_MAX_LAG_MIN=0 to silence)."
                )

    print(f"» prompt-log gate: {len(headers)} entries, {len(problems)} problems, {len(notes)} notes")
    for n in notes:
        print(f"  i {n}")
    if problems:
        for p in problems:
            print(f"  x {p}")
        print("FAIL: UserPromptLog.md is structurally malformed (see above). Fix the file shape; "
              "never rewrite past entry content or timestamps.")
        sys.exit(1)
    print("OK: prompt log well-formed")


if __name__ == "__main__":
    main()
