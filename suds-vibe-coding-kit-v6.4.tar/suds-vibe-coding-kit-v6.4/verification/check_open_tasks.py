#!/usr/bin/env python3
"""
check_open_tasks.py — the anti-drop gate.

Parses OpenTasksMustCompleteAll.md's "Current tasks" section and FAILS `just verify`
if any task is not in a terminal state. This is the mechanism that stops the
"given 3 tasks, did 2" failure: the build cannot go green while a task is still open,
or while a deferral/block lacks a stated reason.

Terminal states:
  [x] done            -> ok
  [~] deferred reason  -> ok only if there's text after the marker (the reason)
  [!] blocked  reason  -> ok only if there's text after the marker (the blocker)
  [ ] open            -> FAIL

No-ops cleanly if the file is absent (so non-task projects are unaffected).
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

TASK_FILE = Path("OpenTasksMustCompleteAll.md")


def main() -> None:
    if not TASK_FILE.exists():
        print("» no OpenTasksMustCompleteAll.md — skipping task-completion gate")
        return

    text = TASK_FILE.read_text(encoding="utf-8")

    # Only enforce the "Current tasks" section, not the Archive.
    m = re.search(r"## Current tasks\n(.*?)(?:\n## |\Z)", text, re.DOTALL)
    section = m.group(1) if m else ""

    # Safety: if there's no Current tasks section but the file DOES contain open
    # checkboxes, the gate would silently pass — warn loudly instead of trusting it.
    if not m and re.search(r"^- \[ \]", text, re.MULTILINE):
        print("  ! OpenTasksMustCompleteAll.md has open '- [ ]' items but no "
              "'## Current tasks' heading — gate cannot scope them. Add the heading.")
        sys.exit(1)

    problems: list[str] = []
    done = 0
    for raw in section.splitlines():
        line = raw.strip()
        cm = re.match(r"^- \[(.)\](.*)$", line)
        if not cm:
            continue
        mark, rest = cm.group(1), cm.group(2).strip()
        if mark == "x":
            done += 1
        elif mark == " ":
            problems.append(f"OPEN (not completed): {rest or '(blank task)'}")
        elif mark in "~!":
            # require a reason: something beyond a bare em-dash/whitespace
            reason = re.sub(r"^[—\-:\s]+", "", rest)
            if len(reason) < 3:
                kind = "deferred" if mark == "~" else "blocked"
                problems.append(f"{kind.upper()} without a reason: {rest or '(blank)'}")
        else:
            problems.append(f"unknown task marker '[{mark}]': {rest}")

    print(f"» open-tasks gate: {done} done, {len(problems)} unresolved")
    if problems:
        for p in problems:
            print(f"  x {p}")
        print("FAIL: tasks remain unresolved. Complete them, or mark [~]/[!] WITH a reason.")
        sys.exit(1)
    print("OK: all current tasks resolved")


if __name__ == "__main__":
    main()
