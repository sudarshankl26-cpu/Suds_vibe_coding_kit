#!/usr/bin/env python3
"""
audit_schema.py — runtime data-contract guard (v3 addition).

Closes the gap a static code scan can't see: facts about the LIVE database that
must match what DATA_MODEL.md declares. Catches the unit-scale and missing-column
class of bug (e.g. a column named *_rate that stores 0-100 when the contract says
0-1; a table the app depends on that silently vanished after a migration).

DOMAIN-AGNOSTIC: zero hardcoded table or column names. Everything is driven by
types/schema_rules.json, which you fill from DATA_MODEL.md's Units section. If that
file is absent, this gate no-ops (so non-DB projects are unaffected).

Supported DB: SQLite. (Postgres can be added; the check logic is engine-neutral.)
"""
from __future__ import annotations

import fnmatch
import json
import sqlite3
import sys
from pathlib import Path

CONFIG = Path("types/schema_rules.json")


def _matches(name: str, patterns: list[str]) -> bool:
    return any(fnmatch.fnmatch(name, p) for p in patterns)


def main() -> None:
    if not CONFIG.exists():
        print("» no types/schema_rules.json — skipping data-contract guard")
        return
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))

    db_path = Path(cfg.get("database_target", ""))
    if not db_path or not db_path.exists():
        print(f"» database '{db_path}' not present — skipping runtime data-contract guard")
        return

    print(f"» data-contract guard on '{db_path}'")
    errors = 0
    conn = sqlite3.connect(str(db_path))
    cur = conn.cursor()

    cur.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")
    objects = {r[0] for r in cur.fetchall()}

    # 1) Required tables/views exist (catches §34 missing-column / dropped-object class)
    for required in cfg.get("required_tables", []):
        if required not in objects:
            print(f"  x MISSING OBJECT: required '{required}' not in schema")
            errors += 1

    # 2) Fraction-scale invariant: columns matching the patterns must be <= max (default 1.0)
    fs = cfg.get("fraction_scale_columns", {})
    tbl_pats = fs.get("table_patterns", ["*"])
    col_pats = fs.get("column_patterns", [])
    max_allowed = float(fs.get("max_value", 1.0))
    if col_pats:
        tables = {o for o in objects if _matches(o, tbl_pats)}
        for tbl in tables:
            try:
                cur.execute(f'PRAGMA table_info("{tbl}")')
            except sqlite3.OperationalError as e:
                print(f"  ! could not read columns of {tbl}: {e}")
                errors += 1
                continue
            for col in (c[1] for c in cur.fetchall()):
                if not _matches(col, col_pats):
                    continue
                try:
                    cur.execute(f'SELECT MAX("{col}") FROM "{tbl}"')
                    mx = cur.fetchone()[0]
                except sqlite3.OperationalError as e:
                    print(f"  ! could not check {tbl}.{col}: {e}")
                    errors += 1
                    continue
                if mx is not None and mx > max_allowed:
                    print(f"  x SCALE VIOLATION: {tbl}.{col} max={mx} exceeds {max_allowed} "
                          f"(name implies fraction scale [0-{max_allowed:g}])")
                    errors += 1

    conn.close()
    if errors:
        print(f"FAIL: {errors} data-contract breach(es). Reconcile DB and DATA_MODEL.md / schema_rules.json.")
        sys.exit(1)
    print("OK: data-contract guard clean")


if __name__ == "__main__":
    main()
