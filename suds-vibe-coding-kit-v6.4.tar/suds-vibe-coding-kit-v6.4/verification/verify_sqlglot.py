# Exercise the exact sqlglot API before relying on it. Run: uv run python verification/verify_sqlglot.py
import sqlglot
from sqlglot import expressions as exp

ast = sqlglot.parse_one("SELECT a, b FROM t WHERE a > 1", dialect="sqlite")
assert isinstance(ast, exp.Select), f"expected Select, got {type(ast)}"
cols = [c.alias_or_name for c in ast.find_all(exp.Column)]
# find_all(Column) returns every column reference, including the one in WHERE — so a
# query "SELECT a, b FROM t WHERE a > 1" yields ['a', 'b', 'a'], not ['a', 'b'].
# (This is exactly the kind of API assumption this protocol exists to pin down.)
assert cols == ["a", "b", "a"], cols
select_cols = [c.alias_or_name for c in ast.selects]
assert select_cols == ["a", "b"], select_cols
print("sqlglot: find_all(Column) and .selects behave as expected")
