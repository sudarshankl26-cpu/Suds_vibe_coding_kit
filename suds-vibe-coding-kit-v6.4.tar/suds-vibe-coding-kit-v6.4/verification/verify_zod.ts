// Exercise the exact zod API before relying on it. Run: pnpm exec tsx verification/verify_zod.ts
import { z } from "zod";

const Schema = z.object({ id: z.number().int(), email: z.string().email() });
const ok = Schema.safeParse({ id: 1, email: "a@b.co" });
const bad = Schema.safeParse({ id: 1.5, email: "nope" });
if (!ok.success) throw new Error("expected valid input to pass");
if (bad.success) throw new Error("expected invalid input to fail");
console.log("zod: safeParse discriminates valid/invalid as expected");
