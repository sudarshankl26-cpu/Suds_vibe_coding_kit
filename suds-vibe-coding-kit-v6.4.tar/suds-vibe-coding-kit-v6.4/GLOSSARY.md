# GLOSSARY

Every domain term used in the PRD, DATA_MODEL, or anywhere else in this repo gets an entry here. If an agent encounters a term not in this file, it must stop and ask before using it.

The single highest-leverage doc in the kit: definition drift across files is the most common source of subtle bugs in vibe-coded apps.

---

## Rules for entries

- **One definition per term.** If a term has multiple meanings in different contexts, give each meaning a distinct name.
- **Examples included.** Every entry has at least one concrete example.
- **Negative examples where useful.** "X is NOT Y" is often clearer than "X is Z."
- **Aliases listed.** If the same concept goes by multiple names in your codebase, note the canonical name and the aliases.

---

## Entries

[Replace the examples below with your domain's actual terms. Alphabetical order.]

### [Term: e.g. "Active user"]

**Definition.** [One sentence.]

**Canonical name.** [The exact identifier used in code: `active_user` / `activeUser` / etc.]

**Aliases.** [Other names that mean the same thing: `dau_user`, `engaged_user`, etc. Avoid these in new code.]

**Example.** [A concrete instance. "A user who appeared in the events table with action=login on the target day."]

**NOT.** [Things sometimes confused with this. "NOT the same as a 'paying user' or 'registered user.'"]

**Formula (if applicable).** [The exact computation. Lives canonically in METRICS.yaml if this is a metric.]

---

### [Term 2]

**Definition.** [...]

[etc.]

---

## Patterns of definition drift to watch for

When you add a new term, check whether it overlaps with an existing one:

- Synonyms in disguise (`org_id` vs `organization_id` vs `account_id` — pick one)
- Temporal variants ("active in the last 30 days" vs "active today" — name them differently)
- Aggregation level ("revenue" at line-item vs order vs customer vs day grain — pick a default, list the others as derived terms)
- Inclusion variants ("revenue" including/excluding refunds — name the inclusive one explicitly)

If you can't decide which variant is canonical, the term isn't well-defined yet. Stop and resolve it before continuing.
