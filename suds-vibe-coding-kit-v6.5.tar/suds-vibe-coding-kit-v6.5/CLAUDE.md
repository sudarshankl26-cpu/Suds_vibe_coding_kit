# CLAUDE.md

Claude Code does not read AGENTS.md natively, so this file imports it. All actual rules
live in AGENTS.md — do not add rules here, add them there.

@AGENTS.md

## Claude-Code-only notes
- Run `just verify` (fast code gates) freely while working; run `just verify-all` before a
  commit (the pre-commit hook runs it too). Autonomous, non-interactive.
- Use Plan Mode for any task touching more than ~3 files; show the plan before editing.
- `STATE.md` is your session-start orientation file — read it first (see AGENTS.md §0).

## Prompt-capture hook dependency

Deterministic verbatim prompt capture (`UserPromptLog.md`) runs via the `UserPromptSubmit`
hook in `.claude/settings.json`, which invokes `python scripts/log_prompt.py`. Two things
must be true on the machine running Claude Code, or capture silently no-ops (the hook
swallows its own errors so it can never block your turn — meaning a missing `python` is
invisible):

1. **`python` must resolve on PATH.** After installing `mise` (`winget install jdx.mise`),
   restart your shell / terminal so mise's shims are picked up, and confirm
   `python --version` works before launching Claude Code. On a bare Windows machine without
   mise active, `python` may resolve to the Microsoft Store stub or nothing at all — in that
   case either let `mise` provide it, or install Python from python.org and ensure it's on
   PATH.
2. **Verify it fires once.** After your first prompt, check `UserPromptLog.md` has a new
   `[hook:claude-code]` entry. If it doesn't, the `python` resolution above is the cause.

The pre-commit hook and `just` recipes are unaffected — they probe `python`/`python3`/`py`
in order. Only the Claude Code hook hardcodes `python` (Claude Code's hook config doesn't
support a fallback chain).
