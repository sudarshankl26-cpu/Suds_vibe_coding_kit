# AGENTS.md

**This is the single source of truth for all agent rules.** Every other tool-config file
in this repo (`CLAUDE.md`, `.windsurfrules`, `.cursor/rules/`, `.zed` settings) is a thin
pointer back to this file. Do not copy rules into those files — they drift. Edit here only.

Read end-to-end before writing code. Re-read §0 at the start of every session.

---

## 0. Session start protocol (read every session)

1. **Read `RepoMapReadFirst.md` FIRST.** It is the living map of the codebase — top-level
   layout, entry points, and a curated "start here." Reading it (~2k tokens) replaces
   re-walking hundreds of files to rediscover structure (50k+ tokens). **Do not re-walk the
   tree to "understand the structure" — read this instead.** If it looks stale, run
   `just map-sync` (cheap), then read it. Do not re-discover by hand.
2. Read `STATE.md` — current phase, active task, what's blocked (~200 tokens).
3. Skim `SinsGotchasLearnings_INDEX.md` if it exists. v6.5 structure: read its **★ALWAYS
   block** fully (it extends §0b with project-specific rules); note the **trigger map** —
   before touching an area, look up its globs/APIs there and open ONLY the matching full
   entries. Entries marked ⚙ are already enforced by `just verify` — trust the gate, don't
   re-read or re-check them by hand. **§0b + the ★ALWAYS block are your combined ≤20-item
   attention budget** — they do not overlap by design (universal here, project-specific
   there), so read both; together they are the shortlist you internalize each session.
4. Read `EXECUTION_PLAN.md` **only for the current phase** unless you need more.
5. If `STATE.md` says `blocked: true`, resolve the `blocker` or ask before anything else.
6. Contracts (PRD, GLOSSARY, DATA_MODEL, ARCHITECTURE, `types/`) — read anytime; do **not**
   edit them inside a feature commit (§5).
7. **Once per machine/model, if you're a non-frontier model** (GLM, DeepSeek, MiniMax, MiMo,
   …): skim `MODEL_NOTES.md` for context-budget and reasoning-effort tips. Not needed every
   session.

You own `STATE.md`, `SinsGotchasLearnings.md`, `RepoMapReadFirst.md` (curated block),
`UserPromptLog.md`, `WorkLogAfterEachRun.md`, and `OpenTasksMustCompleteAll.md`. You do **not**
own the contract files. That boundary is the whole game.

## 0a. Per-turn discipline (lightweight — most of this is now automatic)

The whole point of v6.1: spend your budget on the work, not on proving you followed the
process. Keep this short loop, no more.

- **Prompts log themselves — don't touch the log.** In Claude Code and OpenCode a hook
  captures every prompt to `UserPromptLog.md` verbatim; it is **passive evidence you never
  edit**. Only in a hook-less tool (Kilo, Zed, Antigravity, Hermes) append the entry yourself:
  the prompt inside a `~~~text` fence, EXACTLY as typed. **Never edit or re-stamp a past
  entry.** An "out-of-order timestamp" note is harmless cross-tool clock skew — ignore it; do
  NOT rewrite the trail to "fix" it (that was the single biggest time-sink in v6).
- **Track only real deliverables.** Pull the discrete things the user actually asked for into
  `OpenTasksMustCompleteAll.md` as `[ ]` items before you start — this is the anti-drop net.
  Do NOT add process steps ("log the prompt", "update STATE", "run verify") as tasks; those
  are routine, not deliverables. Before declaring done, every task is `[x]`, `[~] reason`, or
  `[!] blocker`. (`just verify-all` runs `check-tasks`.)
- **Consult the learnings BEFORE you change an area.** The always-on shortlist is §0b below
  plus the index's ★ALWAYS block; for anything deeper, use the index's **trigger map** (the
  file globs, the tech, the API you're about to touch). The taxonomy only prevents a repeat
  if it's read before the code, not after the bug.
- **Capture new learnings as prose, immediately — but FIRST grep for a repeat.** Before
  adding a `## N. Title` entry to `SinsGotchasLearnings.md`, search the file for the same
  failure class. **If it already exists, do NOT write a new entry** — increment its
  `Recurrences:` count, and at 2+ the ratchet applies: a repeated sin is proof prose failed,
  so promote it up the enforcement ladder in the same commit (type/constructor → ast-grep
  `### Audit Rule` → regression test → `Digest: yes`), per `skills/sins-triage.md` §3. For a
  genuinely NEW learning, give the entry its v6.5 metadata (`Scope:` / `Trigger:` /
  `Enforced:` — the `Trigger:` line is what makes it findable at the point of action). An
  `### Audit Rule` stays OPTIONAL for first offenses: add one only when the pattern is
  genuinely structural; don't engineer a pattern to dodge false matches. `just audit-sins`
  self-heals, so there is no sync-then-re-verify dance.
- **One WorkLog entry per session that shipped something** — a short summary in
  `WorkLogAfterEachRun.md` (what changed, what's deferred + why, verify result), not one per
  micro-step. Update `STATE.md` (the cursor) when the phase or active task moves.

---

## 0b. Generalized failure-mode digest (always applies — internalize before coding)

The highest-leverage lessons from the taxonomy, kept here so you avoid them from the first
line instead of catching them after. The **★ALWAYS block of `SinsGotchasLearnings_INDEX.md`
is this list's project-specific extension — read both.** Full set on demand via the index's
trigger map. This digest is an attention budget (≤ ~20 items): earning a slot means
something else gets demoted or promoted to a gate (the sins-triage ritual manages this).

1. **Trace every value.** Anything shown to a user must come from live data or be visibly
   marked synthetic — no invented numbers, IDs, or confidence scores.
2. **Zero ≠ missing.** Never let `?? 0` / `|| 0` / a placeholder `0` masquerade as real;
   render "—" for unknown.
3. **Never swallow exceptions** (`except: pass`, empty `catch {}`) — let them surface.
4. **No average-of-averages** — weight by the denominator (`sum(num)/sum(denom)`).
5. **One numeric convention per quantity** (rates 0–1 everywhere; ×100 only at the render edge).
6. **Parse structured text with a real parser** (SQL→sqlglot, TS→compiler/tree-sitter,
   JSON/HTML→their parsers); regex is for unstructured text only.
7. **Derive during render, not in `useEffect`** — effects are for external sync.
8. **Label == computation** — a metric's name must match what it actually computes.
9. **One port, in `.env`** — every consumer reads it; no `localhost:NNNN` literals.
10. **Verify a third-party API before relying on it** (`verification/verify_<lib>`) — the "I'm
    sure it does X" instinct is wrong ~30% of the time.
11. **Guard edges** — empty arrays (`Math.max(...arr)`), nullable keys, small-N buckets.
12. **"Done" means run-and-observed**, not "code written" — execute it (test / `just smoke` /
    screenshot); don't defer the check.
13. **Hard parts get evals first.** For complex/branchy logic, edge-case handling, input/data
    validation, parsers, or money/units math, write the tests (with the edge-case list) BEFORE
    the implementation, then make `just verify` green. Trivial code needs no ceremony. (§4a)
14. **Three strikes → escalate, don't thrash.** If the same test/error survives ~3 fix
    attempts, stop guessing — consult whatever's available (LSP/type diagnostics, Context7 MCP,
    web search, a `verify_<lib>` probe) before the next attempt. (§6a)
15. **Plan long/complex work into phases.** For anything large (more than a handful of files, a
    refactor, or work that won't fit one focused session), write a dated plan file and execute it
    phase by phase, keeping each phase small; delegate independent slices to subagents where the
    tool supports it. (§4b)
16. **Flag assumptions and constraints inline — don't bury them.** When you assume instead of
    asking, drop a `#PLAN_UNCERTAINTY` next to it and resolve it before "done"; mark a
    non-negotiable as `#EXPORT_CRITICAL` and never silently weaken it. (§1a)

---

## 1. Authoritative reference files

If your code disagrees with one of these, the file wins — extend the file (as its own
commit) before writing the code.

- **PRD.md** — what the app does, who for, what it deliberately does NOT do
- **GLOSSARY.md** — every domain term's exact meaning
- **DATA_MODEL.md** — entities, grain, invariants, units
- **ARCHITECTURE.md** — components, data flow, tech choices, anti-goals
- **types/** — code-level type contracts (`models.py`, `schema.ts`)
- **EXECUTION_PLAN.md** — phased build plan
- **DESIGN_GUIDELINES.md** — default visual standard / anti-AI-slop (only if the project renders a UI)
- **STATE.md** — current build state (agent-owned, mutable)
- [If present: METRICS.yaml, openapi.yaml, design-tokens.css]

Never invent fields on entities in `types/`. Never introduce a domain term absent from
`GLOSSARY.md`. Never use a metric formula different from `METRICS.yaml`. If something is
missing, **stop and ask** — do not invent.

---

## 1a. Inline flags — mark constraints, assumptions, and decisions where they live

Three lightweight tags borrowed from spec-driven team workflows and made solo-lean. They are
**prose conventions, not gates** — write them inline in contracts, a `plans/` file, `STATE.md`,
or a code comment, exactly as text. They exist because the agent's reasoning is lost between
sessions and tools (§8): a constraint you must respect, an assumption you proceeded on, or a
road you chose for a reason should survive **on disk**, not in a transcript nobody re-reads.

- **`#EXPORT_CRITICAL`** — a non-negotiable constraint (a security rule, an invariant, a
  correctness requirement). Never silently weaken, refactor away, or violate one. If a change
  would touch it, treat it like a contract edit: **stop and ask** (§6). Put it next to the
  thing it governs — in `PRD.md` / `DATA_MODEL.md`, on the function, or in the phase.
- **`#PLAN_UNCERTAINTY`** — an assumption you made to keep moving (a guessed unit, an unverified
  API shape, a requirement you picked one reading of). Write it the moment you assume instead of
  ask. A phase is **not done** while one is unresolved: validate it, or promote it to a `PRD.md`
  open question / an ADR. The §I drift audit and §H phase reconciliation both sweep for
  stragglers — and a `#PLAN_UNCERTAINTY` that turns out to be load-bearing is exactly a §6
  "stop and ask".
- **`#PATH_DECISION`** — a one-line "why this over the obvious alternative" breadcrumb, for a
  choice with a real trade-off that isn't heavy enough for a full ADR. (When all three ADR
  tests apply — hard to reverse, surprising, real trade-off — write the ADR instead.)

Keep them rare and real, the way ADRs are kept rare. A tag on every line is noise; a tag on the
three things that will bite the next agent is the whole point.

**Enforcement honesty.** These flags are prose discipline, not gates — no `just verify` check
looks for unresolved `#PLAN_UNCERTAINTY`. They survive on disk (so the §I drift audit and the
phase-end reconciliation can find them), and on your diligence at phase end ("a phase is not
done while one is unresolved" is a rule you enforce, not the harness). If you want teeth for a
specific critical assumption, promote it: turn it into a real `verify_<lib>` probe, a test, or
a `#EXPORT_CRITICAL` constraint that §6 gates.

---

## 2. Universal anti-patterns

Wrong every time. Re-read at session start.

- ❌ **Bypassing constructors/helpers.** If `types/` provides `Finding.make_id(...)` or
  `User.create(...)`, never construct the entity directly.
- ❌ **Reinventing an in-repo pattern.** Before building a new route / component / module /
  query / test, check `RepoMapReadFirst.md` and grep for an existing equivalent — if one exists,
  match its shape instead of inventing a parallel way to do the same thing. Reuse first; create
  only when nothing fits. (One consistent pattern beats three half-right ones; this is the
  tech-agnostic core of "search first, reuse always".)
- ❌ **Inventing imports.** Not in `pyproject.toml` / `package.json` → don't import it.
  Add to deps, install, commit, then import.
- ❌ **Regex-parsing structured text.** SQL → a SQL parser (sqlglot). TS/JS → the TS
  compiler API or tree-sitter. JSON → a JSON parser. HTML → a DOM parser. Regex is for
  genuinely unstructured text only.
- ❌ **Swallowing exceptions.** No `try: ... except: pass`, no empty `catch {}`. Let them
  propagate to the orchestrator / error boundary.
- ❌ **Legacy type syntax.** Python ≥3.11: use `X | None`, `list[X]`, `dict[K,V]` — never
  `Optional`, `List`, `Dict` from `typing`. TS: no `any` (the only legal `any` is a
  documented third-party opaque object); prefer `unknown` + narrowing.
- ❌ **Inventing test data.** Use `tests/fixtures/`. New fixture = explicit, with a planted
  bug + expected output.
- ❌ **Declaring "done" without verification.** Not done until its test passes AND the
  manual step in `EXECUTION_PLAN.md` returns expected output. See §3.
- ❌ **Skipping phases.** Phase N+1 breaks in non-obvious ways if N's invariants aren't set.
- ❌ **Editing contract files inside a feature commit.** Contract edits are their own commits (§5).
- ❌ **Silent migrations.** Schema/type shape change → write an explicit migration function.
  Never assume old data has the new shape.
- ❌ **Fixing a bug without capturing it.** After any non-trivial fix, add an entry to
  `SinsGotchasLearnings.md` (prefer enforcing it as a type or an ast-grep `### Audit Rule` over
  prose, but prose is fine when it isn't structural). A bug fixed but not captured will return.
- ❌ **Creating an app sub-folder.** The project root (this folder) IS the app root. Never
  `mkdir my-app && cd my-app` or nest the app one level down. `scaffold.ps1`/`scaffold.sh`
  already set this folder up in place; build here.
- ❌ **Re-scaffolding / re-init.** Don't `git init`, don't re-run the scaffold, don't
  re-create the structure. The scaffold ran before you. Start from `STATE.md`.
- ❌ **Hardcoding the dev port.** The port lives once in `.env` as `PORT` (SinsGotchasLearnings
  §24). Server, client proxy, and start/stop scripts all READ it. No `localhost:NNNN` literals.
- ❌ **Thrashing on the same failure.** Re-trying minor variations of a fix after ~3 failed
  attempts on the same test/error without consulting LSP/docs/web first. See §6a.
- ❌ **Ignoring a gate's "MISSING TOOLS" / "skipping" output.** A gate that couldn't run its
  tool checked NOTHING — that is a red, not an inconvenience. v6.5 gates fail loudly on a
  configured-but-missing tool; if you ever see a skip you didn't expect, run `just doctor`
  before trusting any green. An entire harness once no-op'd for a full phase because
  "skipping" warnings were scrolled past.
- ❌ **Re-documenting a repeated sin.** If a bug you're fixing already has a
  `SinsGotchasLearnings.md` entry, the lesson FAILED as prose. Increment its `Recurrences:`
  and promote it (type → ast-grep rule → test → digest); never write a second prose entry
  for the same failure class. (§0a, `skills/sins-triage.md`)

### React / TypeScript specific
- ❌ **`useEffect` for derived state.** If it can be computed during render, compute it during
  render. `useEffect` is for synchronizing with external systems, not for "when X changes,
  set Y."
- ❌ **Fetching in `useEffect` by hand** when the project uses Tanstack Query / RSC. Use the
  data layer chosen in ARCHITECTURE.md.
- ❌ **`localStorage`/`sessionStorage` in artifacts/sandboxed previews.** Use in-memory state.
- ❌ **Stringly-typed props.** Discriminated unions over `status: string`.
- ❌ **Unkeyed lists / index-as-key** when items can reorder.

### Python specific
- ❌ **Mutable default args** (`def f(x=[])`).
- ❌ **`requirements.txt` hand-editing** when the project uses `uv` — use `uv add`.
- ❌ **Bare `assert` for runtime validation** in non-test code (stripped under `-O`). Use
  explicit raises or Pydantic.

### UI / visual design (only when the project renders a UI)
- ❌ **AI-slop visual defaults.** Emojis / ASCII art / OS glyphs used as interface icons;
  mismatched icon sets or stroke widths; saturated primaries or rainbow gradients; pure-black
  dark mode; inconsistent corner radii; drop shadows on everything; gratuitous glassmorphism or
  neo-brutalism. These are the tells of a model emitting its defaults instead of a *decided*
  design. Follow **`DESIGN_GUIDELINES.md`**: one icon set at one stroke width, a neutral base + a
  single muted accent, one type family with a real hierarchy, structure from whitespace + 1px
  borders, shadows only on floating layers. If the PRD defines a design language, that wins — tag
  the non-negotiables `#EXPORT_CRITICAL` (§1a). (Skip entirely for CLIs / libraries / pipelines.)

[Project-specific anti-patterns — append as you hit them:]
- [e.g. "Never average a rate column; weight by denominator or sum(num)/sum(denom)"]
- [e.g. "Never SELECT * in production queries"]

---

## 3. Verification gates

Two commands, by design (v6.1):

- **`just verify`** — code/correctness gates only (lint, typecheck, test, verify-libs,
  verify-schema, audit-sins, dox-check). It stays green while you build, so run it FREELY as a
  mid-work sanity check. Trust the green gate — don't re-audit by hand what it already checked.
- **`just verify-all`** — everything in `verify` PLUS the bookkeeping gates (`check-tasks`,
  `check-prompt-log`) and the app `smoke` test. This is what the pre-commit hook and CI run.
  Run it before you commit / call a phase done.

**v6.5 — no silent false-greens.** A gate whose stack is configured but whose tool is
missing now FAILS with the setup command (it used to print "skipping" and pass — which once
let an entire harness no-op for a phase). The JS package manager is detected from the
lockfile, never assumed. `just doctor` self-tests the harness: run it after scaffold, on a
new machine, or whenever gate output looks suspicious — a green doctor is what makes a green
verify trustworthy.

A phase/task is not complete until `just verify-all` passes AND:

1. Deliverable files exist and are committed.
2. Tests pass (pytest / vitest) **and the app was actually run/observed** — `just smoke`, a
   screenshot, or the `EXECUTION_PLAN.md` manual step returning expected output. Do not defer
   the real-behavior check (see §0b.12); wire a `smoke` script instead of writing `[~] can't
   verify`. The shipped `smoke` template is Playwright-based: the first time a `smoke` script
   is configured, also run `pnpm exec playwright install --with-deps` (Playwright's browsers
   aren't bundled with the npm package). The `smoke` gate will tell you, loudly, if you forget.
3. Linter + type checker pass with zero errors.
4. **The descriptive files still describe reality.** Run `just map-sync` if the phase
   changed structure, and reconcile ARCHITECTURE/DATA_MODEL if the phase changed what they
   assert (contract edits are their own commit, §5). `dox-check` fails on wholesale-stale
   path references — a doc that has decayed into fiction poisons trust in every other doc.

Never work around a failure by relaxing an assertion. Fix the code or open a discussion.

**Escape hatch (use sparingly).** If a line legitimately matches a sins `### Audit Rule` but is
an architecture-approved exception, put ast-grep's suppression comment on the line above it:
`# ast-grep-ignore` (Python/CSS) or `// ast-grep-ignore` (TS/JS) — never delete the rule from
`SinsGotchasLearnings.md` or weaken it. Justify the bypass in the commit message.

**Data contracts.** When you change a DB column's unit/scale or add/remove a table the app
depends on, update `types/schema_rules.json` in the same commit. `just verify-schema` checks
the live DB against it (no-ops if the project has no DB).

---

## 4. External library verification protocol

Before using a third-party library new to this repo:

1. Write `verification/verify_<library>.py` (or `.ts`).
2. Import it, exercise the **exact** API surface you'll use.
3. Run it. Confirm output matches expectations.
4. Commit it alongside the real code.

The "I'm sure the library does X" instinct is wrong ~30% of the time and those bugs cost
hours. The script catches them for free. See `verification/` for examples.

**Beat your knowledge cutoff — search before you pin.** Your training is stale by the time you
read this. Before adding or upgrading a dependency, **use web search and/or Context7** to confirm
the *current* version, the current API/import surface, and any recent breaking changes — then
pin and verify. This is encouraged proactively, not only when something breaks (§6a rung 3). Use
whichever you have; web search is widely available and Context7 is preferred for library docs.

---

## 4a. Eval-first for hard parts (suggested)

A suggestion, not a gate — but a high-leverage one. Some units are simply harder to build
*and* to evaluate, and they're where agents quietly ship bugs. For those, write the evals
(tests) **before** the implementation.

**When it applies** — only to genuinely hard units. Reach for this when the unit has any of:
complex/branchy logic, edge-case handling, input/data validation, a parser or format
converter, money/units/rounding math, date/time/timezone math, or anything security-sensitive.
**Trivial code is exempt** — match the ceremony to the job (this is a suggestion precisely so
it doesn't become overhead on simple functions).

**Suggested flow:**

1. **Enumerate the edge cases first** — a short table or comment block listing the inputs that
   matter: empty/null, zero vs missing, boundary values, malformed input, the off-by-one, the
   "what if it's already cancelled" scenario. (The grill and `EXECUTION_PLAN.md` already push
   acceptance criteria as testable assertions — reuse them here.)
2. **Write them as failing tests** in `tests/` (pytest / vitest) before the implementation.
3. **Implement until `just verify` is green** — its `test` gate runs them, so passing evals are
   already enforced. No new gate, no marker, no bookkeeping.
4. **Keep the edge-case list next to the test** so the next agent sees what's covered.

This raises quality exactly where it's hardest, and the existing test gate does the enforcing —
nothing here adds a self-referential check. If you get stuck making them pass, see §6a.

---

## 4b. Planning long or complex work (plan files + phases + subagents)

A suggestion for big work, not a gate. Today's coding models (incl. GLM, DeepSeek, MiniMax,
MiMo — see `MODEL_NOTES.md`) carry ~1M-token context, but recall, cost, and prompt-cache hit
rate all degrade as a single trajectory bloats. Don't pour a whole large task into one runaway
session — **plan it, phase it, and delegate it.**

**When it applies** — any task that is *long or complex*, judged by what you can actually
observe: it touches more than a handful of files (~3+), it's a refactor/migration, it spans
multiple subsystems, or it plainly won't fit in one focused session. (You can't measure your own
token use precisely, so use **file count and scope** as the proxy — the ~300k-token budget below
is a rule of thumb, not a number to compute.) Small, local changes skip this entirely.

**Write a dated plan file.** Create `plans/<meaningful-slug>-YYYY-MM-DD.md` (e.g.
`plans/payments-refund-flow-2026-06-19.md`). This is a *working* plan for one chunk of work —
distinct from `EXECUTION_PLAN.md` (the whole-project build plan) and from `STATE.md` (the live
cursor). Use the `skills/templates/plan.md.template` shape: goal, the phases, and each phase's
verification. (If your tool has a **Plan Mode**, use it to draft and get the plan approved, then
save the approved plan into `plans/` so it survives context resets and tool handoffs.)

**Phase it small.** Make each phase a single coherent slice — a handful of files and one focused
outcome — so its working set stays a *fraction* of the context window (rule of thumb: well under
~300k tokens; you don't need to measure it — keep phases small and they will be). That keeps
recall reliable, the stable prefix cacheable, and cost/latency sane. Every phase must be
independently shippable and end green on `just verify`. Commit per phase; update `STATE.md`
between phases so any tool (or a fresh subagent) can resume cold.

**Delegate to subagents where the tool supports it** (Claude Code's Task tool, OpenCode/Kilo
orchestrator modes, …). The portable pattern is **Explore → Plan → Execute**:
- **The context firewall (v6.5 — the main token saver).** A subagent's output must NOT land
  in the orchestrator's context. Delegated agents write findings/patches/logs to a scratch
  dir (`.scratch/<task>/`, gitignored) and return only: the path + a ~3-line summary + a
  confidence level. The orchestrator reads a file on demand — only the ones that matter, at
  the moment of synthesis, not all of them up front.
- **Handoff packets.** Write every delegated prompt as if the agent has zero chat context:
  exact objective + repo path; in-scope files and explicit out-of-scope; where to write
  output and what to return (path + summary, not content); the verification command to run
  and what success looks like; stop conditions (a command fails after one retry, or the task
  needs out-of-scope files → stop and report, don't improvise).
- **Route each slice by its floor.** Score stakes / reversibility / ambiguity — the highest
  axis sets the minimum model tier for that slice (mechanical scans and summaries go cheap;
  architectural, one-way, or security-critical work stays at the top tier; when unsure, go
  up one). And watch the *count*, not just the tier — many cheap agents is still an
  expensive run. (Details per model in `MODEL_NOTES.md`.)
- *Explore* with a read-only subagent to map the relevant files (its summary, not the raw file
  dumps, returns to you — saving your context).
- *Plan* the phases from that map (this and the hard `§4a` units are worth the model's **higher
  reasoning-effort tier**; see `MODEL_NOTES.md`).
- *Execute* a phase, delegating **independent slices in parallel** when a phase touches ~10+
  files or has 3+ genuinely independent pieces (e.g. one subagent writes the migration, one
  updates tests, one drafts docs). Keep **sequential, dependent** work in a single session.
- Give every subagent a **specific task subject** and its own iteration budget; a stuck
  subagent runs the §6a ladder (and may itself spawn a debugger subagent, up to ~3×) rather
  than thrashing.
- **Vet delegated work — reports are leads, not facts.** No delegated patch is accepted
  until it passes the verification its stakes demand (build, targeted tests, or a full
  diff-review for high-stakes slices) — never rubber-stamp a delegated diff. Before relying
  on a high-impact finding or telling the user something is done: reopen the cited files,
  confirm the claimed line refs / failures are real, and review the final diff against the
  task. Lighter agents gather signal; truth-judgment stays with the orchestrator.
- **Match harness to slice count.** One slice, tightly coupled, or the validation itself
  needs delicate judgment → do it directly; delegation's coordination cost would exceed the
  savings. And scope is a cost lever: split a mega-ask into focused runs instead of one
  giant fan-out.

**If the tool has no subagents**, run the phases sequentially in the main session — the plan
file is the through-line that survives context resets and tool handoffs.

---

## 5. Commit hygiene

- One concept per commit. "phase 3: orchestrator + first two detectors" — not "edit 6 files."
- Contract-file edits (PRD/GLOSSARY/DATA_MODEL/ARCHITECTURE/types) are **separate commits**
  from code that consumes them.
- `STATE.md` updates ride along with the phase commit they describe (it's build state, not a
  contract).
- Don't squash away the linear history; it's the audit trail.

---

## 6. When to stop and ask

Cost of asking: 30 seconds. Cost of building the wrong thing: hours + polluted history.

**Ask when:** a contract is ambiguous about something you must decide; a library's real API
differs from your verification script; a test fails in a way that suggests the requirement is
wrong; you're about to add a dependency, a domain term, or an entity; you're about to skip a
phase or gate; two contract files disagree.

**Don't ask when:** the answer is plainly in a contract file; it's a routine local choice
(variable name, list vs generator); you could answer it yourself by writing a verification
script.

**Assumptions & constraints (§1a).** If you must assume to proceed, tag it `#PLAN_UNCERTAINTY`
where you assumed it and resolve it before the phase is done — an unresolved one at "done" is a
§6 question you skipped. Never change anything tagged `#EXPORT_CRITICAL` without asking.

---

## 6a. When you're stuck (anti-thrash escalation ladder)

§6 is about ambiguous **requirements** — you stop and ask the user. This section is the
opposite case: a **failing test or error you can't crack**. *In this debugging loop only*, do
**not** interrupt the user and do **not** keep re-trying variations of the same guess. (This
narrow "don't ask" never overrides §8 — still announce/confirm before destructive or
irreversible actions — nor §6 when the real blocker turns out to be an ambiguous requirement.)

**Trigger:** the same test/error survives **~3** fix attempts. Re-running a fourth near-identical
guess is thrashing — stop and change *how* you're getting information.

**First, check whether your symptom is a known kit failure mode.** If the failure looks like a
gate misbehaving (a red on an unrelated file, a "skipping" that shouldn't be there, a loop
between two gates), consult **`docs/FAILURE_MODES_AND_LOOP_RISKS.md`** — it catalogs the kit's
known malfunction/loop/confusion scenarios with the kit's built-in defenses and the residual
gaps. A documented issue has a known fix; don't re-derive it via the ladder below.

**Then escalate autonomously** — pull in real information (you do not pause to ask; you go get
the answer — escalating means **continuing with better information, not abandoning the task**).
Do as many of these as your tool supports; the first two always work, the rest are **encouraged
whenever available** — don't ration them:

1. **Read the exact diagnostics.** The full error/stack trace, plus type-checker output
   (`mypy`, `tsc`) and any LSP diagnostics — often the precise cause is already in the message
   you skimmed past. (Always available.)
2. **Write a minimal repro / `verify_<lib>` probe and run it** (§4). Isolating the failing call
   in a tiny script confirms what the code *actually* does — the "I'm sure it does X" instinct
   is wrong ~30% of the time (§0b.10). (Always available — needs only code execution.)
3. **Search the web and/or Context7 — use them freely.** Your training has a **knowledge
   cutoff**; web search and Context7 are how you get *current* truth: the exact error string's
   known cause/fix, the library's real and **current** API, version-specific behavior, and
   recent breaking changes. Reach for them early, not as a last resort. (Context7 is preferred
   for library docs where available; web search covers everything else and is widely available.)
4. **Delegate or use any other tool available** — spawn a focused **debugger subagent** with the
   error + repro (§4b), or use repo search / a focused experiment.

**Use whichever are available** — not every tool/agent (Kilo, Zed, OpenCode, …) has Context7,
web search, LSP, or subagents; skip what you genuinely don't have and use the rest (rungs 1–2
always work). Only after this ladder is genuinely exhausted does the normal §6 "stop and ask"
apply — and then only if it turns out to be a real requirements ambiguity rather than a solvable
bug.

---

## 7. Tool / environment conventions

- **Python:** `uv` (not pip/poetry). **Node:** `pnpm` (not npm/yarn).
- Tests in `tests/`, fixtures in `tests/fixtures/`, library checks in `verification/`.
- Paths in code: `pathlib.Path` / `path.join` — never string-concatenate.
- Frontend bundle output is git-ignored; never commit the build.
- **Output language follows the project's stated language (default: English)** for content
  **you author at the code level**: identifiers, comments, commit messages, internal docs, and
  new internal log/error messages. This applies to code-level identifiers specifically, even
  when the model's strongest language differs — keep identifiers in the project's language for
  consistency. **Do NOT translate or alter user-facing copy, localized / i18n strings, or real
  data** — those follow the project's own requirements (and its stated UI language), never this
  rule. When in doubt, match what's already in the repo. All files are written/read as **UTF-8**.
- **Windows 11:** commands in `justfile` are written cross-shell. If a tool runs in WSL vs
  PowerShell, prefer WSL for the `just` recipes; they assume a POSIX shell.
- **Model-specific operating tips** (context budget, reasoning-effort tiers, sampling) live in
  `MODEL_NOTES.md` — read it once if you're driving this repo with GLM / DeepSeek / MiniMax /
  MiMo or any non-frontier model.

---

## 8. Multi-agent / multi-tool note

This repo is worked by several agents/tools (Claude Code, Kilo, Zed, OpenCode, Windsurf,
Antigravity). They all read **this file** via their own pointer. Therefore:

- Never assume the user can see your screen; state what you're doing before destructive ops.
- Leave the repo in a `just verify-all`-green state at the end of every session so the next
  tool starts clean.
- The `STATE.md` block is the handoff mechanism between tools. Keep it accurate — it is the
  only thing the next agent reads to orient.

**Sequential handoff is supported; concurrent multi-agent use is not.** STATE.md is the baton
between tools *used one at a time*. Running two top-level agents against the same checkout
simultaneously will corrupt shared state: `UserPromptLog.md` appends race (and on Windows can
trip a sharing-violation), `STATE.md` is last-write-wins, and the git index is not
multi-writer safe (`.git/index.lock` contention fails one agent's commit mid-flight). If you
need parallelism, do it from a **single orchestrator** via the §4b subagent firewall — each
subagent writes to its own `.scratch/<task>/` (gitignored) and returns a summary, so there is
no shared-file contention. Two top-level editors on the same tree is the one configuration
this kit does not support.

---

## 9. What good final output looks like

- What was built (one paragraph).
- What was tested + result (one line per test/category).
- What's deferred and why (one line each).
- Any unresolved `#PLAN_UNCERTAINTY` flags left for the user to decide (§1a).
- The next step the user should take.

**Not:** effusive self-praise, restating the request, bullet-listing every file touched,
or suggesting features nobody asked for.

---

## 10. Hierarchical AGENTS.md (optional — for larger, modular repos)

**Default is flat:** this one root AGENTS.md governs the whole repo. Most projects need
nothing more. Only reach for the hierarchy below when the repo grows distinct subsystems
(e.g. `backend/`, `frontend/`, `etl/`, `infra/`) with their own durable local rules.

When a subsystem becomes a durable boundary with rules that don't belong at the root, add a
**child `AGENTS.md`** inside that folder. Rules:

- **Root stays the single source of GLOBAL rules.** A child holds LOCAL contracts only —
  things true for that subtree and nowhere else. Never restate or copy global rules into a
  child (that reintroduces the drift this kit exists to prevent).
- **A child must point to root.** Include a line stating global rules live in the root
  AGENTS.md (e.g. "Global rules live in the root AGENTS.md; this doc adds <subsystem>-local
  rules only.").
- **A child may only ADD constraints, never weaken a root rule.** A child cannot re-permit
  something the root forbids (no `✅` for a root `❌`). `just dox-check` enforces this.
- **Every child must be indexed by its parent.** The nearest ancestor AGENTS.md lists it
  under a `## Child DOX Index` section. `just dox-check` enforces this too.
- **Read the chain before editing.** Before editing a file, read the root AGENTS.md plus
  every child AGENTS.md on the path down to that file. The nearest doc controls local
  details; the root controls global rules.
- **Update the chain after editing.** If a change alters a subsystem's purpose, contracts,
  or rules, update that subsystem's AGENTS.md (and the parent's index if you add/remove a
  child) in the same commit.

Child doc shape (keep it short — local specifics only):

```
# <subsystem>/AGENTS.md
## Purpose
What this subtree is and owns.
## Local Contracts
Global rules live in the root AGENTS.md; this doc adds <subsystem>-local rules only.
- <local rule 1>
- <local rule 2>
## Child DOX Index
(only if this subsystem has its own sub-children)
```

This layer is inspired by the DOX framework, but enforced: `just dox-check` (part of
`just verify`) fails the build if a child isn't indexed, lacks the root pointer, or weakens a
root rule. It is a clean no-op when the repo is flat.

## Child DOX Index

This repo is flat (root-only). Add children here as `- <dir>/ — <one-line scope>` when you
create subsystem AGENTS.md files. Leave as-is for a single-app project.
