# Adopting or upgrading — see migrate/MIGRATION.md

The single, consolidated guide for getting an existing project onto kit v6.5 is
now **[`migrate/MIGRATION.md`](migrate/MIGRATION.md)**. It covers all three paths
in one place with a decision table and copy-paste commands:

| Your project today | Path | Tool |
|---|---|---|
| Already on v6.4 → v6.5 | **A — Swap** | manual (MIGRATION.md §A) |
| On v4 / v5 / early-v6 → v6.5 | **B — Migrate** | `migrate/migrate_kit.py` |
| Built without the kit | **C — Adopt** | `adopt/adopt_kit.py` |

The adopt path also has its own self-documented launchers: `adopt/adopt-kit.ps1`
(Windows) and `adopt/adopt-kit.sh` (WSL/macOS/Linux), both `--plan` first then
`--apply`. New-project scaffolding is in `START_HERE.md` Path A.

> This file used to duplicate the migrate/adopt walkthroughs and had drifted to
> reference "v6.1". The canonical, version-current instructions now live in
> `migrate/MIGRATION.md` — one file, one source of truth (the kit's whole
> anti-drift philosophy applied to its own docs).
