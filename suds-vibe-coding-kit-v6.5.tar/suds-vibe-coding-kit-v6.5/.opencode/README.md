# .opencode/ — OpenCode plugin config

## What this provides

`plugins/prompt-logger.js` captures every genuine user prompt to `UserPromptLog.md`
verbatim, outside the model's control — the OpenCode equivalent of Claude Code's
`UserPromptSubmit` hook. The log is **passive evidence**: the agent never edits it.

## Auto-loading (no setup needed in the common case)

OpenCode auto-loads local plugins from `.opencode/plugins/` at startup — no `package.json`
or `opencode.json` entry is required for a plugin that uses only Node built-ins. This plugin
imports only `node:fs` and `node:path`, so it loads on a fresh clone with zero configuration.

`.opencode/.gitignore` ignores `package.json` / `node_modules` because this plugin needs none.
If you ever extend it to use an external npm package, drop a `package.json` here with that
dependency and OpenCode will `bun install` it at startup.

## Event-name compatibility — verify on your OpenCode version

The plugin subscribes to `"chat.message"`, the event name used when this plugin was written.
Newer OpenCode builds renamed message events to `message.updated` / `message.part.updated`
(see the canonical list at https://opencode.ai/docs/plugins/#events). If you're on a build
that no longer honors `"chat.message"`, prompt capture will silently stop.

**Verify it's firing** after your first prompt: open `UserPromptLog.md` and confirm an entry
with the `[hook:opencode]` source label appeared. If it didn't:

1. Check the OpenCode event list for your build (`chat.message` vs `message.updated`).
2. If renamed, update the hook key in `plugins/prompt-logger.js` (currently the
   `"chat.message":` line) to the current name and reload OpenCode.

If your OpenCode build has no working prompt-capture hook at all, fall back to the manual
rule in `AGENTS.md` §0a: append each prompt yourself, inside the `~~~text` fence, verbatim.
