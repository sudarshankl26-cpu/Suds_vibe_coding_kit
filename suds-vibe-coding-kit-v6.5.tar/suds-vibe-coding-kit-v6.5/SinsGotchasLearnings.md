# SinsGotchasLearnings.md — incident-indexed defect taxonomy

The highest-value file in this repo once a project has run for a while. Every real bug you
hit gets one entry here, so the **same class of bug is caught before it ships again**. This
file is the source for two generated artifacts (do not edit those by hand):

- `rules/*.sins.yml` — the ast-grep rules from every `### Audit Rule` below, run by
  `just audit-sins` (part of `just verify`).
- `SinsGotchasLearnings_INDEX.md` — a one-line-per-entry index agents read at session start.

You normally don't regenerate by hand — `just audit-sins` self-heals (it regenerates the rules
whenever this file changes). `just sins-sync` does it explicitly (rules + index).

---

## How to write an entry

**Step 0 — grep for a repeat.** If the failure class already has an entry, do NOT add a new
one: increment its `Recurrences:` line. At 2+ the ratchet applies — a repeated sin is proof
prose failed; promote it (type/constructor → ast-grep `### Audit Rule` → regression test →
`Digest: yes`) in the same commit. See `skills/sins-triage.md`.

Most NEW learnings are **prose** — that is the default and it is fine. v6.5 metadata (all
optional lines under the heading) makes an entry retrievable at the point of action:
`Scope:` universal | stack:<x> | project · `Trigger:` comma-separated globs/APIs/keywords ·
`Enforced:` prose | rule | test:<path> | type:<path> · `Digest:` yes/no (~20 budget) ·
`Recurrences:` <int>. The `Trigger:` line matters most — no trigger, no retrieval.

```
## N. Short Title

> **Incident:** One sentence on what actually went wrong, with the real symptom.

### Why It's Dangerous
Why it ships silently / why a human misses it.

### Rule
The single imperative rule, first sentence ≤130 chars (it becomes the index line).
```

**Optional `### Audit Rule` (ast-grep).** Add one ONLY when the defect is a genuinely
structural code shape (a call shape, an import, a CSS declaration). v6.1 replaced the v6
single-line grep audits — which couldn't express multiline/CSS and kept matching their own
explanatory comments — with **ast-grep**, which matches the AST. Shape:

```
### Audit Rule
​```yaml
id: kebab-case-unique-id          # becomes rules/<id>.sins.yml
language: TypeScript              # or Python, Css, Tsx, JavaScript, …
severity: error                  # error => fails the gate; warning/info/hint => a note
rule:
  pattern: Math.round($X * 100) / 100   # `pattern:` is the simplest form — write the bad code
message: One line shown on a hit, ending with the §number.
​```
```

Rules of thumb that keep this cheap (the v6 failure was over-engineering these):

- **Prefer `pattern:`** — write the offending code shape with `$VARS` for the parts that vary.
  Reach for `kind:`/`has:`/`inside:`/`all:`/`any:` only when a simple pattern can't express it.
- **If a clean rule isn't obvious in a minute, don't write one.** Leave it as prose. Do NOT
  burn reasoning crafting a pattern to avoid false matches — that was the v6 time-sink.
- ast-grep matches code, not comments, so a rule can never flag its own write-up. Multiline
  and CSS work natively.
- Suppress an approved exception with `# ast-grep-ignore` / `// ast-grep-ignore` on the line
  above — never delete the rule.

---

## Promotion path (where a learning goes)

Not everything belongs here. Route by enforceability:

| The lesson is… | Put it in… |
|---|---|
| A structural code pattern | **here**, with an `### Audit Rule` (ast-grep) → enforced gate |
| A type-level guarantee | `types/` (a constructor/helper/union) → enforced by `tsc`/`mypy` |
| A domain-term definition | `GLOSSARY.md` |
| A schema/grain/unit fact | `DATA_MODEL.md` |
| A tech-choice rationale | `ARCHITECTURE.md` |
| A general agent behavior | `AGENTS.md` §2 anti-patterns / §0b digest |

A learning that can be moved *up* this list (prose → rule → type) should be. The goal is to
push every lesson to the most automatic enforcement layer it can reach. Prose is the layer of
last resort for ENFORCEMENT — but it's the common, expected form for capture. Don't contort a
conceptual lesson into a rule.

---

## Entries

> **These first entries ship with the kit.** They are the *universal, recurring* defect
> classes distilled from many real projects — debranded and generic. They are ON by default so
> the agent avoids the mistake instead of waiting to make it. A few carry an `### Audit Rule`
> (enforced by `just audit-sins`); most are prose, surfaced via the index and the §0b digest in
> `AGENTS.md`. **Delete any that don't apply to your project** (e.g. the React ones for a
> pure-backend app), and keep appending your own — your project-specific incidents are where
> this file earns its keep.
>
> **Prune early — especially on a non-frontier model.** Right after the grill, delete the
> shipped defaults that don't fit your stack. A shorter taxonomy means a shorter
> `SinsGotchasLearnings_INDEX.md` (read at session start) and a tighter, more cacheable prompt
> prefix — which matters most for models running on a tight working-context budget (see
> `MODEL_NOTES.md`). Then `just sins-sync` to regenerate the index.
>
> The single highest-leverage principle here is **§2: every value shown to a user must trace
> to live data.** Roughly half of all real incidents are some variation of it.

---

## 2. Phantom Values — Numbers That Don't Trace to Live Data
Scope: universal
Trigger: metrics, dashboard, confidence, mock-data, hardcoded-number
Digest: yes

> **Incident:** A dashboard showed a confident figure ("revenue up 23%", "confidence: 0.87",
> "Merchant 4471 is the outlier") that was hardcoded, copied from a planning doc, or invented
> by an LLM. It looked authoritative and was wrong — nobody could tell because the number had
> no provenance.

### Why It's Dangerous
This is the single most common class of defect across projects: a value rendered to a human
that does not come from a query against live data. It includes fabricated AI confidence
scores, hardcoded narratives, phantom strings, stale stats presented as current, and
invented entity IDs. Each looks like working software. None survives contact with the data.

### Rule
**Every value shown to a user must either (a) trace to a live query/computation, or (b) be
explicitly marked synthetic** (a `// HARDCODED`/`// PLACEHOLDER` comment, a visible "sample"
badge, or qualitative language instead of a fake number). An AI-generated confidence score or
projected impact must be computed from a verified statistic or set to 0/omitted. Any
hardcoded entity reference (an ID, a name) must be verifiable with one query. If you can't
trace it, you can't ship it.

---

> **Also merged (ex-§64):** fabricated confidence scores and analysis coefficients with no provenance — every confidence/score/coefficient is computed from live data or carries a provenance comment (source, date, method).

## 3. Duplicated Logic That Drifts Apart
Scope: universal
Trigger: formatter, shared-constants, duplicate-logic

> **Incident:** The same computation (a rate formula, a currency formatter, a set of
> "currency columns") lived in two files. One was updated; the other wasn't. The two screens
> silently disagreed.

### Why It's Dangerous
Copy-pasted logic has no compiler link between the copies. They drift the moment one changes,
and the drift is invisible until a user notices two numbers that should match, don't.

### Rule
If two files compute the same thing or share the same classification set (currency columns,
percent columns, formatting rules, thresholds), extract it into a single shared `lib/`
module and import it in both places. One definition, one home.

---

## 4. The `?? 0` / `|| 0` Fallback That Masks Missing Data
Scope: universal
Trigger: ?? 0, || 0, fallback, missing-data

> **Incident:** `const value = data.metric ?? 0` turned every missing/failed computation into
> a confident zero, indistinguishable from a real zero (see §1, but at the consumer instead
> of the producer).

### Why It's Dangerous
The fallback is invisible and feels defensive ("avoid undefined"), but it destroys the
distinction between "this is genuinely zero" and "this never computed." Errors get rendered
as data.

### Rule
Differentiate "zero" from "unknown." Default to `null`/`undefined` and render "—" or an error
state, not `0`, unless zero is provably the correct value. Review every `?? 0` and `|| 0`.

### Audit Rule
```yaml
id: nullish-zero-fallback
language: TypeScript
severity: warning
rule:
  any:
    - pattern: $A ?? 0
    - pattern: $A || 0
message: '`?? 0` / `|| 0` can turn missing/failed data into a confident zero. Default to null and render "—" unless zero is provably correct. (SinsGotchas §4)'
```


---

> **Also merged (ex-§1):** a metric field hardcoded to `0` as a placeholder shipped as a real value — same class: zero masquerading as missing.

## 5. Swallowed Exceptions — `except: pass` / empty `catch {}`
Scope: universal
Trigger: try/except, catch, error-handling

> **Incident:** A `try/except` with a bare `pass` (or an empty JS `catch {}`) hid a real
> failure; the function returned a default and the bug surfaced three layers away as wrong
> data with no stack trace.

### Why It's Dangerous
A swallowed exception converts a loud, locatable failure into a silent, mislocated one. It is
the most expensive way to "handle" an error.

### Rule
Never swallow. Either show visible feedback to the user (toast, inline error, placeholder),
or let the exception propagate to the orchestrator/error boundary. A `catch` that only logs
is acceptable only if the log is actually monitored.

---

## 6. The Average-of-Averages Fallacy
Scope: universal
Trigger: AVG, rates, aggregation

> **Incident:** A headline rate was computed as `AVG()` over a column that was already a
> per-group average. The result was mathematically meaningless — small and large groups
> weighted equally.

### Why It's Dangerous
It produces a plausible-looking number that is simply wrong, and no test catches it because
the value is in-range. It is one of the most common data-correctness bugs.

### Rule
Never average pre-aggregated averages. Compute a weighted average:
`SUM(value × weight) / SUM(weight)`, or `SUM(numerator) / SUM(denominator)` from raw rows.
Before computing any rate from a pre-aggregated table, verify the denominator is consistent
per group.

---

## 7. The 0–1 vs 0–100 Scale Chaos
Scope: universal
Trigger: rates, percentage, scale, units

> **Incident:** Some code stored a rate as a fraction (`0.23`), other code as a percentage
> (`23`). A threshold comparison (`rate > 15`) then matched everything or nothing, and a
> displayed "2300%" looked absurd.

### Why It's Dangerous
The same field name carries two different units across layers. The bug only appears when a
specific value crosses the confusion boundary, so it ships silently.

### Rule
Pick ONE convention for all rate/percentage columns (recommended: fractions, 0–1) and apply
it everywhere — storage, thresholds, and display. Multiply by 100 only at the render edge.
When you standardize, audit every consumer; a fixed API with an unconverted frontend is its
own bug. Capture the convention in `DATA_MODEL.md` and `types/schema_rules.json`.

---

## 8. The Cancel-Out Rounding Bug — `Math.round(x * 100) / 100`
Scope: universal
Trigger: Math.round, rounding, percentage

> **Incident:** Code meant to convert a fraction to a percentage used
> `Math.round(x * 100) / 100`, which rounds to 2 decimals and divides back — a no-op that
> returns the original fraction. The "percentage" was off by 100×.

### Why It's Dangerous
It reads as deliberate arithmetic and passes review. The two operations cancel; the intent
(scale by 100) silently doesn't happen.

### Rule
Rounding to N decimals is `Math.round(x * 10**N) / 10**N`. Scaling to a percentage is
`x * 100`. Don't conflate them. If you see `* 100) / 100`, it's almost always a bug.

### Audit Rule
```yaml
id: cancel-out-rounding
language: TypeScript
severity: error
rule:
  pattern: Math.round($X * 100) / 100
message: 'Math.round(x*100)/100 rounds to 2dp then divides back — a no-op. To scale to a percentage use x*100; to round to N dp use Math.round(x*10**N)/10**N. (SinsGotchas §8)'
```


---

## 9. Outlier-Corrupted Averages in Small-N Buckets
Scope: universal
Trigger: average, outliers, small-N

> **Incident:** A "average per group" displayed to users was dominated by one extreme outlier
> in a bucket with only a handful of rows, producing an absurd headline number.

### Why It's Dangerous
Mean is not robust. With small N, a single bad row (or a data-entry error) moves the headline
arbitrarily, and the number still looks like a normal metric.

### Rule
For any user-facing average, either cap/winsorize outliers before averaging, use the median,
or show N alongside the value and suppress the metric below a minimum N. Never display a raw
mean over a tiny or unbounded-range bucket.

---

## 10. Aggregation Coverage Gaps — NULL Keys Silently Dropped
Scope: universal
Trigger: GROUP BY, NULL, aggregation

> **Incident:** A `GROUP BY dimension` silently excluded all rows where `dimension` was NULL,
> so a headline total covered only the mapped subset. 98% of the data was filtered out and
> the number looked fine.

### Why It's Dangerous
NULL-key rows vanish from grouped aggregates without warning. The total is wrong by exactly
the amount you can't see.

### Rule
Every aggregation that groups by a nullable dimension must include an explicit
"Unknown"/"Unmapped" bucket for NULLs (`COALESCE(dimension, 'Unknown')`), and you must verify
the grouped total reconciles to the ungrouped total.

---

## 11. Label ≠ Computation — Semantic Misdirection
Scope: universal
Trigger: metric-label, KPI, naming

> **Incident:** A card labeled "Late Deliveries" actually counted orders past their *estimated*
> time, not their *promised* time — a different, larger set. The label and the SQL disagreed,
> and every viewer drew the wrong conclusion.

### Why It's Dangerous
A wrong label on a correct number is still a wrong dashboard. It's invisible to tests (the
number is right) and invisible to code review (the SQL is right) — only domain knowledge
catches it.

### Rule
Every metric label must accurately describe its actual computation, survive the "would a
reasonable person interpret this correctly?" test, and use process-step language for funnel
stages (not happy-path outcomes). Column names must describe what they actually contain.

---

## 12. Mixed Time Scopes on One Screen
Scope: universal
Trigger: KPI, time-scope, dashboard

> **Incident:** One KPI card showed last-7-days, the one beside it showed month-to-date, with
> no labels. Users compared them as if they shared a denominator. They didn't.

### Why It's Dangerous
Each number is individually correct, so nothing fails. The error is in the *juxtaposition* —
the dashboard implies a comparison that isn't valid.

### Rule
Every KPI on a given page must share the same temporal denominator, or each must carry an
explicit, visible scope label ("MTD", "Last 7d"). No bare numbers whose time window the
viewer has to guess.

---

## 13. Every Chart Needs a Title and Context Label
Scope: universal
Trigger: charts, titles, units

> **Incident:** A dashboard shipped with bare charts — no title, no units, no time scope —
> so a number couldn't be interpreted without reading the source code that produced it.

### Why It's Dangerous
An unlabeled chart is data without meaning. It invites misreading and can't be audited by
anyone but the author.

### Rule
Every chart/section has a title, units, and a context label (time scope, filter, segment).
If a number could be misread without context, the context is mandatory, not optional.

---

## 14. No Emojis in Professional UI
Scope: stack:react
Trigger: emoji, icons, status-indicator

> **Incident:** Status indicators used emoji (✅⚠️🔴) that rendered inconsistently across
> platforms and looked unprofessional in a business dashboard.

### Why It's Dangerous
Low-stakes individually, but it signals an unpolished product and breaks visual consistency
across OSes/browsers.

### Rule
Use an icon library (e.g. `lucide-react`, `@radix-ui/icons`) for all user-facing visual
indicators. Emojis are fine in developer-facing logs only, never in the UI. (Delete this
entry if your product is intentionally casual.)

> **No shipped `### Audit Rule`.** An emoji-in-UI rule is project-specific (it must scope to
> *your* UI source globs, not a generic `client/src/**`). A ready-to-adapt rule shape lives
> in `docs/ast-grep-examples/emoji-in-ui.sins.yml` — copy it into this entry with `files:`
> set to your UI source path, then `just sins-sync`. The prose + trigger map already surface
> the lesson.

---

## 15. SWR / Query Infinite Retry Storm
Scope: stack:react
Trigger: SWR, react-query, retry, fetch

> **Incident:** A structural error (missing table, broken endpoint) triggered SWR's default
> unlimited retries, hammering a dead endpoint forever and masking the real failure as a
> "loading" state.

### Why It's Dangerous
The default retry-forever turns a fast, loud, structural failure into a slow, silent,
resource-burning one. Transient-retry defaults are wrong for structural errors.

### Rule
Every SWR/React-Query config must set `shouldRetryOnError: false` or a finite
`errorRetryCount`. Distinguish transient (network blip — retry) from structural (missing
table — fail fast and surface).

---

## 16. `useEffect`/`useCallback` Misused for Derived State
Scope: stack:react
Trigger: useEffect, useCallback, derived-state

> **Incident:** A `useCallback(() => {...}, [])()` immediately-invoked pattern (and elsewhere
> a `useEffect` that just did `setY` when `X` changed) was used to compute values that should
> be derived during render. Result: extra render cycles, stale values, cascading re-renders.

### Why It's Dangerous
It works often enough to ship, then produces intermittent stale-state and performance bugs
that are very hard to reproduce.

### Rule
If a value can be computed during render, compute it during render (or `useMemo`). `useEffect`
is for synchronizing with external systems, not "when X changes, set Y." Never use
`useCallback` as a `useEffect` substitute (no IIFE callbacks).

---

## 17. Heavy Components Imported Statically
Scope: stack:react
Trigger: recharts, heavy-import, bundle, lazy

> **Incident:** Chart libraries (recharts, nivo, xyflow) were statically imported into a
> top-level route, bloating the initial bundle and slowing first paint for users who never
> scrolled to the chart.

### Why It's Dangerous
It's invisible in development (everything's local and fast) and only bites real users on real
networks. No test fails.

### Rule
Components importing heavy visualization libraries must be lazily loaded (`next/dynamic`,
`React.lazy`). Keep the initial bundle lean. (Framework-specific — delete if not using a
bundler with code-splitting.)

---

## 18. Schema/Field Change Without Consumer Propagation
Scope: universal
Trigger: schema-change, rename, migration, consumers
Digest: yes

> **Incident:** A column/API field was renamed or its type changed, but a downstream consumer
> (a SQL query, a TS type, a UI component) still referenced the old shape. It failed at
> runtime, or worse, silently read `undefined`.

### Why It's Dangerous
The producer change looks complete and self-consistent. The break is in a consumer the author
didn't think to grep for. Half-finished migrations are a top recurring incident.

### Rule
When you change a schema/type/field: (1) grep for every consumer in the same commit, (2)
update `types/` and `DATA_MODEL.md` together, (3) write an explicit migration for existing
data — never assume old data has the new shape. A rename isn't done until the old name returns
zero hits.

---

## 19. Regex-Parsing Structured Text
Scope: universal
Trigger: regex, SQL, JSON, parsing

> **Incident:** SQL/JSON/TS was parsed or rewritten with regex; an edge case (a comment, a
> nested quote, a multiline construct) broke it in a way that corrupted output silently.

### Why It's Dangerous
Regex on structured grammars works on the happy path and fails on the long tail, usually
without an error — it just produces subtly wrong output.

### Rule
Parse structured text with a real parser: SQL → sqlglot, TS/JS → the TS compiler API or
tree-sitter, JSON → a JSON parser, HTML → a DOM parser. Regex is only for genuinely
unstructured text.

---

## 20. Math.min/max Spread on a Possibly-Empty Array
Scope: universal
Trigger: Math.max, Math.min, spread, empty-array

> **Incident:** `Math.max(...arr)` threw (or returned `-Infinity`) when `arr` was empty,
> crashing a render or producing a nonsense axis bound.

### Why It's Dangerous
Empty arrays are common (filtered data, loading states) and the failure is a runtime throw or
a silent `±Infinity` that poisons downstream math.

### Rule
Always guard `Math.min(...arr)` / `Math.max(...arr)` with an empty-array check, or use a
reduce with an explicit initial value.

### Audit Rule
```yaml
id: math-spread-unguarded
language: TypeScript
severity: warning
rule:
  any:
    - pattern: Math.max(...$A)
    - pattern: Math.min(...$A)
message: 'Math.max/min(...arr) throws or returns ±Infinity on an empty array. Guard for empty, or reduce with an explicit initial value. (SinsGotchas §20)'
```


---

## 21. Every `fetch` Needs a Timeout / AbortController
Scope: universal
Trigger: fetch, HTTP, timeout, AbortController

> **Incident:** A `fetch()` with no timeout hung indefinitely when the backend stalled,
> leaving the UI in a permanent loading state with no escape.

### Why It's Dangerous
The default fetch has no timeout. A slow or dead backend becomes an infinite spinner the user
can't recover from.

### Rule
Every `fetch()` (or HTTP client call) must have an AbortController with a timeout (≈45s is a
reasonable default) and surface a visible error when it fires.

---

## 22. Don't Leak Internal Exception Text to API Clients
Scope: universal
Trigger: error-response, API, exception-text

> **Incident:** An HTTP error response interpolated the raw exception string into its `detail`
> field, leaking stack traces, file paths, and SQL into client-visible responses.

### Why It's Dangerous
It's an information-disclosure issue (paths, schema, internals) and a poor UX — the client
gets noise instead of an actionable message.

### Rule
Never interpolate raw exception text into an HTTP response body. Log the detail server-side;
return a stable, generic, client-safe message + an error code.

---

## 23. Windows: stdout/redirect Encoding Corrupts Non-ASCII
Scope: stack:windows
Trigger: stdout, encoding, UTF-8, print, cp1252

> **Incident:** A Python generator that wrote `§`/`⚙` glyphs produced mojibake (`┬º`/`ΓÜÖ`)
> when its output was redirected with `>` on Windows, because the default console/redirect
> encoding is cp1252, not UTF-8.

### Why It's Dangerous
It only manifests on Windows (works fine on the author's Mac/Linux/WSL), and only for
non-ASCII output, so it ships and corrupts generated files silently in the user's environment.

### Rule
Any script that reads or writes text must force UTF-8 explicitly:
`Path(p).read_text(encoding="utf-8")`, `write_text(..., encoding="utf-8")`, and for stdout,
`sys.stdout.reconfigure(encoding="utf-8")`. Never rely on the platform default encoding.

---

> **Also merged (ex-§98):** Python gate scripts crashed echoing a Unicode task line under cp1252 — every script that prints authored text forces UTF-8 stdout (`sys.stdout.reconfigure(encoding='utf-8')`).

## 24. Hardcoded Port in Multiple Places (The Triple Definition)
Scope: universal
Trigger: port, .env, localhost

> **Incident:** A dev port was written into the server config, the client proxy, the start
> script, and the README. One was changed; the others weren't; the app and its tooling
> disagreed about where it ran.

### Why It's Dangerous
A configuration constant with no single home drifts the moment any one copy changes. The port
is a contract; copies of a contract drift (see §3).

### Rule
Define the port ONCE in `.env` (e.g. `PORT=...`) and have every consumer — server, client
proxy, start/stop scripts, docs — read it from there. No literal port numbers scattered in
source.

---

## 25. justfile Shebang Recipes Break on Native Windows (No cygpath)
Scope: stack:windows
Trigger: justfile, shebang, recipes

> **Incident:** `just sins-sync` failed on native Windows PowerShell with "could not find
> `cygpath` executable to translate recipe shebang interpreter path." Every multi-line
> recipe used a `#!/usr/bin/env bash` shebang, which `just` can only run on Windows if
> Cygwin/Git-Bash's `cygpath` is on PATH. A separate earlier failure: a pip-installed Python
> package named `just` shadowed the real command runner.

### Why It's Dangerous
The justfile is the entry point to every verification gate. If it only runs under a
Unix-ish shell, then on a native-Windows agent the entire gate is unrunnable — and the
agent, unable to verify, either skips verification or loops. The kit's own enforcement
layer becomes the thing that doesn't work in the user's environment.

### Rule
Make recipes shell-agnostic: set both `set shell` (bash) and `set windows-shell`
(powershell), and write recipes as thin one-liners that call Python helpers rather than
`#!/usr/bin/env bash` script bodies (Python runs identically on both shells; bash-isms like
`[ -f x ]`, `shopt`, `for f in` do not). Ship a pure-PowerShell fallback (`verify.ps1`,
`sync.ps1`) so the kit works with no `just` and no bash at all. And confirm `just --version`
prints the real Rust tool, not a shadowing Python package.

## 27. CI That Installs `just` But Not the Toolchain Is a False Green
Scope: stack:kit
Trigger: CI, toolchain, workflows

> **Incident:** A CI workflow set up Python + `just` and ran `just verify` — which passed.
> But `uv` and `pnpm` weren't installed, so every lint/type/test/lib gate SKIPPED (the
> portable runner skips absent tools). CI was green while running zero actual checks.

### Why It's Dangerous
A gate that can't run its tools but reports success is worse than no gate (same family as
SinsGotchasLearnings §3, the `|| true` no-op). It gives a server-side guarantee that doesn't
exist; the first real bug sails through the merge queue.

### Rule
CI must install the SAME toolchain used locally (via mise: just/uv/node/pnpm) AND install
project deps (`uv sync`, `pnpm install`) so the gates actually execute, not skip. After
enabling CI, deliberately push a known-bad commit once and confirm CI fails — a gate you
haven't watched fail is not yet a gate.

## 28. Git Hooks and CI Gates Must Survive a Missing `just`
Scope: stack:kit
Trigger: git-hooks, pre-commit, just

> **Incident:** The pre-commit hook ran `just verify` and, when `just` wasn't installed,
> waved the commit through with a warning. So on any machine where the one prerequisite
> wasn't set up yet, the gate silently did nothing on every commit.

### Why It's Dangerous
The whole point of the hook is that it can't be forgotten. If "tool not installed" degrades
to "commit allowed," the gate is off exactly when the environment is least set up — the
highest-risk moment.

### Rule
The hook must use a fallback chain: prefer `just verify`; if `just` is absent, run the gate
gate-by-gate via the Python helpers (`scripts/run_gate.py`, `scripts/sins.py`,
`verification/*`); only allow the commit ungated if NO interpreter exists at all, and say so
loudly. Provide pure-PowerShell `verify.ps1` so a Windows user with no `just` is never
ungated. Use `#!/bin/sh` (not `bash`) in the hook so Git-for-Windows' bundled shell runs it.

## 30. Day-1 Gate Failures From the Kit's Own Defaults (mypy/pytest)
Scope: stack:kit
Trigger: mypy, pytest, day-1, gate-defaults

> **Incident:** On a fresh project, `just verify` failed two ways before any real code was
> written: (1) mypy type-checked the kit's example `verification/verify_sqlglot.py`, which
> imports `sqlglot` (not installed), erroring with "cannot find module"; and (2) pytest
> returned exit 5 ("no tests collected") which propagated as a gate failure — but a new
> project legitimately has no tests yet.

### Why It's Dangerous
A gate that fails on day 1, before the user has done anything wrong, trains them to bypass
it (`--no-verify`) or delete it — the verification culture dies at the start (same family as
SinsGotchasLearnings §3). The failures also blamed the kit's own example files, which is
confusing.

### Rule
The gate must be green on a freshly-initialized project that has installed its dev tools.
Scope type-checking to the user's own code (`src/`), not the kit's example/template files
that intentionally reference optional libs. Treat "no tests collected" (pytest exit 5,
vitest `--passWithNoTests`) as success. And when a configured tool isn't installed yet,
SKIP it LOUDLY ("NOT actually checking — run `just setup`") rather than failing OR silently
passing.

## 31. Hierarchical Docs Without Enforcement Drift Like Any Other Prose
Scope: universal
Trigger: AGENTS.md, docs-hierarchy, drift

> **Incident:** A distributed-documentation convention (per-subsystem AGENTS.md, inspired by
> the DOX framework) was adopted as prose discipline: "read the doc chain before editing,
> update it after, never let a child weaken a parent rule." With no enforcement, child docs
> drifted — some weren't indexed by their parent, some restated (and contradicted) global
> rules, one re-permitted something the root forbade.

### Why It's Dangerous
A per-folder rules doc that nobody checks is just more prose to drift, and a child that
silently re-permits a globally-forbidden pattern is worse than no child doc — it grants false
permission. Distributed docs multiply the surface area for the exact drift a single source of
truth was meant to prevent.

### Rule
If you split rules across a hierarchy of AGENTS.md, ENFORCE the hierarchy, don't just
document it: every child must be indexed by its parent, must point to the root for global
rules (not restate them), and must only ADD constraints (never re-permit a root ❌). Keep the
root as the single source of GLOBAL rules; children hold LOCAL specifics only. `just dox-check`
(in `just verify`) enforces all three and is a clean no-op for a flat single-app repo.

---

> **v6 merge note.** Entries §32–§77 below were distilled and debranded from five real
> project incident archives (a BI-demo dashboard, an FMCG analytics suite, a finance app,
> a voice-analytics/LLM app, and a large ops-analytics audit) plus recurring hazards found
> in real build plans. Same rules as above: delete what doesn't apply, append your own.

## 33. A Gate That Swallows Failures Is Worse Than No Gate
Scope: universal
Trigger: gates, || true, skipping, false-green
Digest: yes

> **Incident:** Every recipe in a verification gate ended with `|| true` to handle a
> "config not present yet" case — and thereby also swallowed every real failure (missing
> binary, failing test, broken lint). The gate was green for weeks while broken.

### Why It's Dangerous
A silently-green gate creates false confidence; nobody re-checks what a gate claims to have
checked. No-op behavior must be explicit ("file absent — skipping"), never an exit-code mask.

### Rule
A gate may skip loudly when its inputs are absent; it must never convert a real failure into success (`|| true`, `-ErrorAction SilentlyContinue`, bare `except: pass`).

> **Also merged (ex-§85):** `just verify` silently no-op'd EVERY pnpm gate on native Windows (missing .cmd resolution + hardcoded pnpm) — an entire phase ran with zero real checks. v6.5 run_gate.py enforces this structurally (lockfile-detected PM, loud MISSING-TOOLS failure, `just doctor`).

## 34. Drill-Without-Data — Interactive Affordances Backed by Nothing
Scope: universal
Trigger: buttons, drill, onClick, interactive

> **Incident:** Seventeen "Drill into X" buttons — the highest-value interaction in the
> demo — all called a handler that flashed a CSS class for 1.5s and did nothing else.

### Why It's Dangerous
Click-through is exactly what a reviewer tests first. Cosmetic handlers pass every static
check and fail only in a live demo, where it costs the most.

### Rule
Every interactive affordance must change real state or render real data; if the data behind a drill doesn't exist yet, disable the control and label it, don't fake the click.

## 35. The Cosmetic Slicer — Controls That Filter Nothing
Scope: universal
Trigger: filters, slicers, dropdown

> **Incident:** Fourteen slicer tiles and four dropdowns updated only their own `.active`
> CSS class; the matrix next to them never changed. A separate page offered filter values
> (categories) that no row in the data layer even possessed.

### Why It's Dangerous
A filter that doesn't filter is indistinguishable from a working one in a screenshot. It
also implies the data has dimensions it doesn't have.

### Rule
A filter control must be wired to a re-render with filtered data, and every option it offers must exist in the data layer — derive options FROM the data, never hardcode them.

## 36. Modal Submit ≡ Cancel — Silent No-Op Actions
Scope: universal
Trigger: modal, submit, cancel

> **Incident:** A "Set Alert" dialog's Cancel and Create buttons called the same
> `closeModal()` handler. No validation, no persistence, no toast — filling the form and
> "creating" did exactly nothing, silently.

### Why It's Dangerous
The user believes the action happened. Nothing in the UI or logs says otherwise.

### Rule
A primary modal action must do its work and confirm it (state change + visible feedback); if unimplemented, the button is disabled with a "not wired" label.

## 37. Future-Data — Charts Rendering Beyond the Data Horizon
Scope: universal
Trigger: time-series, charts, dates, horizon

> **Incident:** A "52-week rolling" chart showed two full-height bars for dates AFTER the
> "data updated" timestamp shown in the same screen — fabricated future data next to a
> freshness claim that contradicted it.

### Why It's Dangerous
Generated/mock series happily extend past "now". Any reviewer who cross-reads the freshness
label loses trust in the entire dashboard.

### Rule
Clamp every time series at the dataset's max date; the data horizon comes from the data, never from `new Date()`.

## 38. Hardcoded Identity — The Current User Defined N Times
Scope: universal
Trigger: current-user, identity, config

> **Incident:** The current user's name/initials/email/title were hardcoded in five places
> with three different spellings; changing persona for a demo required a five-file hunt.

### Why It's Dangerous
Identity drifts exactly like any other duplicated constant (§3) — but it's the first thing
an audience notices.

### Rule
Current-user identity lives in ONE config object; every avatar, email field, and signature renders from it.

## 39. Drift-State — Sibling Status Indicators That Contradict
Scope: universal
Trigger: status-indicator, health, derived-state

> **Incident:** The topbar said "Refresh: Healthy" (green) while the page showed a data
> integrity alert; the bell badge said 6 while 3 rows were unread. Each indicator was
> hand-set in a different place.

### Why It's Dangerous
Contradictory chrome tells the reviewer "nothing here is computed". Each indicator was
locally plausible; only cross-reading exposes the lie.

### Rule
Status indicators are DERIVED from one source of truth (count the rows, check the alerts); never set two indicators independently when one fact feeds both.

## 40. Fake URLs on Primary CTAs
Scope: universal
Trigger: href, links, CTA

> **Incident:** Every primary CTA pointed at `href="#"` or at an invented deep link that
> 404'd in the real target system ("Open full report" → a fabricated Power BI URL).

### Why It's Dangerous
`href="#"` scrolls to top and looks like a bug; an invented URL looks real until clicked in
front of an audience. LLMs invent plausible URLs constantly (§2's cousin).

### Rule
A link is either a verified-working URL, an internal route that exists, or a disabled control with a label — never a placeholder href and never an invented external deep link.

## 41. Infinity/NaN Rendered Where a Number Should Be
Scope: universal
Trigger: division, Infinity, NaN, denominator

> **Incident:** A matrix rendered literal `Infinity` and `NaN` cells because a
> percent-change divided by a zero prior-period value, and nothing guarded the division.

### Why It's Dangerous
Zero denominators are guaranteed to occur in real data (new products, first periods).
`x/0 → Infinity` and `0/0 → NaN` render without throwing, so no error surfaces.

### Rule
Every division that can see a zero denominator goes through one shared safe-divide helper that returns null (rendered "—"), never through inline `a/b`.

## 42. Sum-Includes-Total — Adding the Rollup Row Back In
Scope: universal
Trigger: SUM, total-row, rollup

> **Incident:** A KPI summed channel rows INCLUDING the "Total" row and showed ~2× the
> correct value. The total was already the rollup of the other rows.

### Why It's Dangerous
2× errors look plausible at a glance, and the bug only exists because data and rollup live
in the same array.

### Rule
Rollup rows ("Total", "All", "Overall") are stored separately or filtered by a flag before any aggregation — never aggregate a list that mixes members with their own rollup.

## 43. Double-Bound Handlers — Extend the Wiring, Don't Add a Second
Scope: universal
Trigger: addEventListener, handlers, wiring

> **Incident:** A new feature needed tile-clicks to also re-render content, so a SECOND
> click handler was added next to the existing wiring function. Every click then fired
> twice — and later handlers fought each other.

### Why It's Dangerous
Double-binding is invisible until an action is non-idempotent (toggle, POST, counter), and
then it's a "sometimes" bug.

### Rule
One element, one wiring site: extend the existing handler/wiring function; never attach a second listener for the same concern from a different file.

## 44. Headless/DOM Verification Can Mislead — Verify Rendering in a Real Browser
Scope: universal
Trigger: jsdom, headless, playwright, screenshot, layout

> **Incident:** jsdom showed correct `style="height: 28%"` on every chart bar, but a real
> browser rendered all bars at zero height — the parent had no resolved height, which
> jsdom never computes.

### Why It's Dangerous
"The DOM is right" ≠ "the pixels are right". Layout-dependent CSS (percent heights, flex,
grid) only resolves in a real layout engine.

### Rule
DOM assertions verify structure; for layout-dependent visuals the phase's manual verification step must view the real page (or a headed screenshot) before "done".

## 45. Generic Action Routers Hide Unhandled Actions
Scope: universal
Trigger: dispatcher, routeAction, switch, actions

> **Incident:** A `routeAction(action)` dispatcher handled 21 button actions; 16 had real
> behavior, 5 fell through to a generic "Done ✓" toast — unimplemented actions looked
> exactly like implemented ones.

### Why It's Dangerous
A default branch that fakes success converts "not built yet" into "silently broken".

### Rule
Action dispatchers are exhaustive: unknown/unimplemented actions throw or render an explicit "not implemented" state — never a generic success path.

## 46. Bare json.loads / JSON.parse on LLM Output
Scope: universal
Trigger: JSON.parse, json.loads, LLM-output

> **Incident:** An LLM returned its JSON wrapped in ```json fences (as LLMs often do);
> `json.loads()` threw, and the feature died on responses that were actually fine.

### Why It's Dangerous
Works in every test where the model happened to return clean JSON; breaks in production on
the first fenced/prefixed response. Retry storms often follow.

### Rule
LLM output goes through ONE shared extractor that strips fences/prose and validates against a schema (pydantic/zod) — never bare json.loads/JSON.parse at call sites.

## 47. Prompt Schema Drift — Generate the LLM's View of the Database
Scope: universal
Trigger: LLM-prompt, schema, DATA_SCHEMA

> **Incident:** A hand-written `DATA_SCHEMA` constant in a talk-to-data route described 34+
> column names that did not exist in the actual database. Every non-trivial generated SQL
> query failed with "no such column". A later rebuild of aggregate tables silently
> invalidated the prompt again.

### Why It's Dangerous
The system prompt is a second copy of the schema — §3 (duplicated logic) applied to an LLM.
It drifts on every migration, and the failure mode is the LLM "hallucinating", when really
it was taught wrong.

### Rule
The schema/ontology section of any data-aware prompt is GENERATED from the live schema (or types/schema_rules.json) at build or startup — never hand-written, and regenerated whenever the schema changes.

## 48. LLM Structured Output Polluted With Prose
Scope: universal
Trigger: LLM-output, structured-fields, max-length

> **Incident:** Follow-up suggestion chips rendered full explanation paragraphs because the
> LLM stuffed prose into the structured `suggestions` field and nothing validated shape.

### Why It's Dangerous
Schema-less consumption of LLM fields means UI breakage is decided by model mood.

### Rule
Every structured LLM field has a max length and shape check at the parse boundary; reject/truncate at parse time, not in the component.

## 49. Few-Shot Examples and Cheat Sheets Must Match the Real Schema and Grain
Scope: universal
Trigger: few-shot, examples, cheat-sheet

> **Incident:** Example questions shipped with the product referenced a grain the data
> didn't have (and few-shot SQL used values absent from the domain), so the showcase
> queries — the ones users try first — were exactly the ones that failed.

### Why It's Dangerous
Few-shots are executable documentation: the LLM imitates them and users start with them.
Wrong examples are taught bugs.

### Rule
Every shipped example question/few-shot must be executed against the real data as part of verification — an example that doesn't run is a planted defect.

## 50. Fake Progress Indicators Desync From Real Work
Scope: universal
Trigger: progress, loading, spinner

> **Incident:** A loading screen ran on a fixed timer ("Analyzing… 80%") while the real API
> call sometimes finished earlier or failed entirely — progress hit 100% on a request that
> had already 500'd.

### Why It's Dangerous
Progress UI that lies converts an error state into "it worked, where's my result?".

### Rule
Progress indicators bind to real lifecycle events (request sent/streaming/complete/failed); if true progress is unknowable, show an indeterminate spinner, never a fake percent.

## 51. Empty Result ≠ Error — Always Render the Distinction
Scope: universal
Trigger: empty-state, error-state, UI-states
Digest: yes

> **Incident:** An empty (but successful) result rendered as a generic error; elsewhere an
> empty transcription rendered as nothing at all. Users couldn't tell "no data matches"
> from "the system is broken".

### Why It's Dangerous
Both directions destroy trust: real errors get ignored ("probably just no data") and real
empty sets get reported as bugs.

### Rule
Three distinct UI states, always: data / explicit empty-state with explanation / error with cause. An empty success must never reuse the error path or render blank.

## 52. Unhandled Response Status Renders Nothing
Scope: universal
Trigger: response.status, switch, exhaustive

> **Incident:** A component switched on `response.status` and handled "ok" and "error" —
> a third status the API actually returned ("partial") matched no branch and rendered a
> blank panel.

### Why It's Dangerous
Status enums grow. Every unhandled branch is a future blank screen with no console error.

### Rule
Switches over API statuses are exhaustive with a loud default (TS: `never` check; Python: `assert_never`) — a status you didn't plan for must be visible, not blank.

## 53. Safety Caps Must Clamp, Not Just Fill Defaults
Scope: universal
Trigger: LIMIT, caps, clamp, boundary

> **Incident:** A SQL safety layer appended `LIMIT 500` only when the query had no LIMIT —
> a generated `LIMIT 50000` sailed through and froze the UI.

### Why It's Dangerous
"Add if missing" is not a cap. Any guard implemented as a default instead of a clamp can be
bypassed by the very input it guards against.

### Rule
Safety limits clamp: `effective = min(requested, cap)` — applied unconditionally at the boundary, regardless of what the input already specifies.

## 54. Naive Sentence/Text Splitting Breaks on Real Text
Scope: universal
Trigger: split, sentences, segmentation

> **Incident:** Splitting transcripts on `"."` broke on abbreviations ("Dr.", "U.S.") and
> decimals, producing garbage segments that downstream metrics quietly consumed.

### Why It's Dangerous
Looks correct on clean test sentences; corrupts silently on real text. A cousin of §19
(regex-parsing structured text).

### Rule
Sentence/token segmentation uses a real segmenter (spaCy, Intl.Segmenter, nltk); `split(".")` is only acceptable for genuinely delimiter-separated data.

## 55. No Backend Health Check — The Dead-Server Mystery
Scope: universal
Trigger: health-endpoint, server, dev-loop

> **Incident:** The backend was down; the frontend showed stale panels and generic spinners.
> Users filed UI bugs. Nothing anywhere said "the server is not running".

### Why It's Dangerous
Every backend outage masquerades as N unrelated frontend bugs, and the debugging session
starts in the wrong codebase.

### Rule
Ship a `/health` endpoint and surface it: the UI states plainly when the backend is unreachable, and start-server scripts verify health before declaring the app up.

## 56. A Fix Must Be Applied at Every Call Site
Scope: universal
Trigger: bugfix, call-sites, grep
Digest: yes

> **Incident:** Entity-name corrections were applied in the main query path but not the
> diagnostic path — the bug was "fixed" yet kept appearing in diagnostics, and the two
> paths now disagreed.

### Why It's Dangerous
A partially-applied fix is worse than no fix: the system contradicts itself and the bug
report gets closed.

### Rule
After fixing a pattern, grep for ALL occurrences of that pattern and fix or audit-disable each — the fix commit includes the search, not just the one site the bug report named.

## 57. DB Row Fetches May Return None/undefined
Scope: universal
Trigger: fetchone, db-row, None, undefined

> **Incident:** `cursor.fetchone()[0]` threw `TypeError: 'NoneType' object is not
> subscriptable` the first time a query legitimately matched nothing.

### Why It's Dangerous
Empty result sets are normal, not exceptional. Direct indexing converts "no rows" into a
crash at a distance from the cause.

### Rule
Never index a fetch result directly: bind it, check for None/undefined, and handle the empty case explicitly (or use a helper that returns a typed Optional).

## 58. Datetime Type Mismatches Compare Silently Wrong
Scope: universal
Trigger: datetime, Timestamp, comparison

> **Incident:** Comparing a pandas `Timestamp` against a Python `date` filtered out every
> row — no error, just an empty frame that downstream code happily aggregated to zeros.

### Why It's Dangerous
Cross-library datetime types often compare without raising, and a wrong-but-valid boolean
mask is invisible. Pairs with §1 (silent zero).

### Rule
Normalize to ONE datetime type at the data boundary (document it in DATA_MODEL.md); never compare values from different datetime systems directly.

## 59. PowerShell 5.1 Does Not Support `&&`
Scope: stack:windows
Trigger: powershell, &&, .ps1

> **Incident:** A generated `.ps1` used `cmd1 && cmd2`. Windows PowerShell 5.1 (the default
> `powershell.exe` on Windows 11) has no `&&` operator — the script died on syntax.

### Why It's Dangerous
LLMs write bash-isms into PowerShell constantly, and it works in pwsh 7 — so it passes on
the dev box and breaks on default Windows.

### Rule
Scripts targeting `powershell.exe` use `;` plus explicit `$LASTEXITCODE` checks (or `if`), never `&&`/`||`; reserve those for `pwsh` 7+ and say so in the shebang comment.

## 60. Seeded-but-NULL — Verify Seed Output, Not Seed Code
Scope: universal
Trigger: seed, ETL, NULL-rate, verification

> **Incident:** Seed logic for a column existed and ran without error, yet the column was
> 100% NULL in the database — a join in the seeder matched nothing.

### Why It's Dangerous
"The seeder ran" is not "the data exists". Every downstream feature reading that column
sees NULL and degrades silently (§1, §10).

### Rule
After seeding/ETL, assert the OUTPUT: row counts > 0 and NULL-rate thresholds per critical column, as an executable check — not by reading the seeder code.

## 61. Dimension Validity Varies by Slice
Scope: universal
Trigger: dimensions, filters, slices, validity

> **Incident:** Individual brands existed in retailer-channel data but NOT in the "Total
> market" channel of the same table; a brand+total filter combination returned silently
> empty results that rendered as zeros.

### Why It's Dangerous
Each filter value is valid alone; the COMBINATION is invalid. No error fires, and §4
fallbacks turn it into plausible zeros.

### Rule
Document slice-dependent dimension validity in DATA_MODEL.md, and make invalid filter combinations unselectable (or render an explicit "not available for this slice" state).

## 62. Format at the Edge, Once
Scope: universal
Trigger: formatting, toFixed, units, render-edge

> **Incident:** Raw floats serialized into the UI ("4.333333333333333 min"); separately,
> two components each maintained their own column-format maps, which drifted (one showed
> %, the other a fraction, for the same column).

### Why It's Dangerous
Per-component formatting is duplicated logic (§3) applied to presentation — drift is
guaranteed, and raw floats scream "demo".

### Rule
One formatting module owns number/date/unit rendering keyed by column/metric id; components call it and never hand-roll `toFixed`/f-strings for displayed metrics.

## 63. Grain-Hazard Joins — Fan-Out Corrupts Metrics
Scope: universal
Trigger: JOIN, grain, fan-out

> **Incident:** Joining an order-grain table to an item-grain table without pre-aggregation
> duplicated order rows; every downstream SUM and AVG was inflated. (The kit ships
> `tests/fixtures/sample_sql/planted_fanout.sql` to test exactly this.)

### Why It's Dangerous
Fan-out doesn't error — it multiplies. Metrics stay plausible (everything scales up
together) so nothing looks obviously wrong.

### Rule
Before joining tables of different grain, aggregate the finer table to the coarser grain (or use EXISTS); every join in analytics SQL states the expected grain of its result in a comment.

## 65. Validate Meaning at Layer Boundaries
Scope: universal
Trigger: boundaries, validation, props, API-response

> **Incident:** A value flowed engine → API → page → component, and no layer checked it
> meant anything: `(projectedImpact / 2).toFixed(1)` happily rendered a hardcoded 0 as
> "0.0pp" through four layers.

### Why It's Dangerous
Each layer assumes the previous one validated. With zero contracts between layers, garbage
travels end-to-end and acquires legitimacy at each hop.

### Rule
Each boundary (API response, store, component props) validates shape AND domain (ranges, non-placeholder) with zod/pydantic; a value that can't be validated renders as missing, not as itself.

## 66. Required Tables Must Exist Before Routes Ship
Scope: universal
Trigger: tables, schema, startup, routes

> **Incident:** Six aggregation tables an API depended on were never created and eight more
> were empty — every dependent route 500'd on every request, discovered only by clicking
> around.

### Why It's Dangerous
The gap between "schema in code" and "tables in DB" is invisible until runtime, and each
500 looks like a route bug rather than a missing-prerequisite bug.

### Rule
Startup (or `just verify-schema`) asserts every table the app reads exists AND is non-empty where emptiness is invalid; a route ships in the same commit as the migration it depends on.

## 67. Partitioned Totals Double-Count
Scope: universal
Trigger: partitions, SUM, double-count, scope-rollups

> **Incident:** A table stored per-persona partitions of the same orders; a query summed
> `total_orders` across ALL rows, inflating the denominator ~6× and showing cancel rates
> 6× too low. A sibling table's "delayed orders" column counted every order, not just
> delayed ones, overstating by 83%.

### Why It's Dangerous
Aggregating an aggregate is only valid when partitions are disjoint and complete. Column
names ("total_…") say nothing about partition semantics.

### Rule
Document each aggregate table's partition key and whether rows are disjoint in DATA_MODEL.md; never SUM across partitions without confirming disjointness, and never trust a column name over its definition.

> **Also merged (ex-§100):** `token_costs` carried the same spend under multiple `scope` rollups and was SUMmed across scopes — same class: never SUM across non-disjoint partitions; document the partition key in DATA_MODEL.md.

## 68. Overwrite vs Accumulate in Loops
Scope: universal
Trigger: loops, aggregation, accumulate

> **Incident:** A monthly-trend loop wrote `bucket[month] = value` instead of
> `bucket[month] += value`, understating hours wasted by 98% — only the last row per month
> survived.

### Why It's Dangerous
The output has the right shape, plausible values, and is wrong by an order of magnitude.
Tests that check shape pass.

### Rule
Any aggregation loop is verified against an independent total (`sum(buckets) == sum(rows)`); reconciliation asserts ship with the loop, not as an afterthought.

## 69. The Population Filter Must Match the Metric's Definition
Scope: universal
Trigger: population-filter, metrics, WHERE

> **Incident:** A "delay breakdown" table included non-delayed orders in its population;
> a completion-rate formula counted some entities twice. Each metric's denominator quietly
> disagreed with the metric's own name.

### Why It's Dangerous
Numerator/denominator population mismatches produce numbers that are wrong in a way only a
domain expert spots — every individual query step looks fine.

### Rule
Every metric's population filter is written next to its formula (METRICS.yaml or GLOSSARY) and the SQL/code cites it; a metric named "X rate among Y" must filter to exactly Y.

## 70. Narrative Strings Must Interpolate Computed Numbers
Scope: universal
Trigger: narrative, interpolation, copy, numbers

> **Incident:** A root-cause card's text claimed "+32%" while the data said +10.2% — the
> narrative was hardcoded prose written during planning, never recomputed.

### Why It's Dangerous
Numbers inside sentences escape every data-flow check, yet read as the most authoritative
part of the screen. Stale narrative is §2 hiding in copywriting.

### Rule
Prose templates interpolate computed values (`{pct_change}`); a numeric claim inside a hardcoded UI string is a defect unless it's a label, not a finding.

## 71. Hot Paths: Cache and Precompute — Don't Recompute Per Request
Scope: universal
Trigger: caching, hot-path, recompute

> **Incident:** Server functions re-queried the DB for data the page already held, insights
> were recomputed on every request, an O(n²) fuzzy match ran per keystroke, and bulk writes
> ran with per-row fsync — each alone tolerable, together a 30s page.

### Why It's Dangerous
Each instance is locally innocent; the product of them is an app that feels broken. Agents
add the Nth recomputation without seeing the N-1 others.

### Rule
Derived data is computed once at the cheapest layer (ETL/build > server cache > client memo) and reused; before adding a query or loop in a hot path, check whether the result already exists upstream.

## 72. Trust the Enforced Config Over the Doc
Scope: universal
Trigger: docs-vs-config, lint-config, truth

> **Incident:** A migration doc said `core → shared` imports were forbidden; the actual
> ESLint boundary config allowed them. Agents kept "fixing" legal imports to match the doc.

### Why It's Dangerous
When prose and enforcement disagree, following the prose creates churn against a gate that
keeps passing — and erodes trust in both.

### Rule
The enforced artifact (lint config, type, gate) is the truth; when a doc disagrees, update the doc in its own commit — never code against the doc and around the gate.

## 73. No Shared Abstraction Before Three Consumers
Scope: universal
Trigger: shared/, abstraction, DRY, hoisting

> **Incident:** Single-persona widgets were hoisted into `shared/` "for reuse"; the second
> consumer needed different behavior, and the abstraction grew flags until nobody could
> change it safely.

### Why It's Dangerous
The wrong abstraction is more expensive than duplication — it couples unrelated features
and turns every change into a multi-consumer negotiation.

### Rule
Code moves to `shared/`/`core/` only when 3+ consumers need IDENTICAL behavior; until then, duplicate it locally and note the duplication (§3 covers keeping the copies honest).

## 74. Plan-Version Drift — One Canonical Plan, Superseded Plans Say So
Scope: universal
Trigger: plans, PLAN.md, superseded

> **Incident:** A repo accumulated `PLAN.md`, `IMPLEMENTATION_PLAN_V2.md`,
> `IMPLEMENTATION_PLAN_v2.2.0.md`, and an enhancement plan — agents in later sessions
> picked a stale plan and executed superseded phases.

### Why It's Dangerous
To an agent every plan file is equally authoritative; the most recently *written* plan is
not the most recently *named*. Executing a stale plan re-introduces decisions you reversed.

### Rule
EXECUTION_PLAN.md is the only live plan; any other plan document gets a first-line banner `> SUPERSEDED by EXECUTION_PLAN.md — do not execute` the moment it stops being current.

## 75. Absolute Machine Paths in Repo Files
Scope: universal
Trigger: absolute-paths, C:\, portability

> **Incident:** Build plans hardcoded `C:\Users\<name>\...` project locations; on the next
> machine (and in WSL) every path was wrong, and the username leaked into shared docs.

### Why It's Dangerous
Absolute paths are invisible until the repo moves — then scripts, docs, and configs break
at once. They also tie the repo to one identity.

### Rule
Repo files use paths relative to the project root; the root itself is wherever the repo was cloned — never a hardcoded user directory.

## 76. Every Plan Phase Ends With an Executable Verification Step
Scope: universal
Trigger: plan-phases, verification-step

> **Incident:** Plan phases ended at "build X" with no stated check; "done" became the
> agent's opinion, and dropped sub-tasks surfaced two phases later.

### Why It's Dangerous
A phase without a falsifiable exit condition cannot fail — so it always "succeeds",
including when it didn't happen.

### Rule
Each EXECUTION_PLAN.md phase ends with a concrete verification: the command to run and the expected output; a phase with no check is not a phase, it's a hope.

## 77. Version Numbers in Plans Are Intent — the Lockfile Is Truth
Scope: universal
Trigger: versions, lockfile, pins, plans

> **Incident:** A plan pinned `react ^19` and specific minor versions; by build time the
> installed versions differed, and agents "fixed" working code to match the stale plan.

### Why It's Dangerous
Two version records (plan + lockfile) is §3 again; the plan copy is dead the moment
`install` runs.

### Rule
Plans name dependencies, not versions (or say "latest at install time"); the lockfile is the only version authority, and code follows the installed API (verified via verification/ scripts).

## 78. Naive Datetime Comparison Across Timezones / Tools
Scope: universal
Trigger: timezones, UTC, timestamps, comparison

> **Incident:** Two tools wrote timestamps to one shared log — one in local time, one in UTC,
> both with the offset stripped. A gate that parsed them as *naive* datetimes and enforced
> strict increasing order then flagged every cross-tool interleave as "out-of-order", and the
> agent "fixed" it by REWRITING entries in an append-only audit trail. (This is the v6 bug
> that motivated v6.1.)

### Why It's Dangerous
A naive datetime drops the only thing that makes two clocks comparable — the offset. The
comparison is silently wrong exactly when sources differ, and the "fix" corrupts the record.

### Rule
Compare datetimes as timezone-AWARE instants (normalize to UTC); write timestamps with their
offset (`isoformat()`, not a stripped `strftime`). An append-only log is evidence — never
rewrite a past timestamp to satisfy a checker; make the checker timezone-correct instead.

## 80. Over-Engineering a Line-Based Audit Instead of Using a Real Tool
Scope: universal
Trigger: ast-grep, audits, line-grep

> **Incident:** A bug needed a "ban this pattern" check, but the audit framework only allowed a
> single-line grep. The model spent ~15 minutes designing a regex that would match a multiline
> CSS defect, avoid matching its own explanatory comment, and stay valid in two regex dialects
> — for one check. The pattern is fundamentally line-based; the defect was not.

### Why It's Dangerous
Line-grep can't see structure, so it can't express most real defects (multiline, CSS, "this
call but not that one"). Forcing it produces brittle patterns and enormous wasted reasoning,
and it violates the kit's own rule: parse structured text with a real parser.

### Rule
Enforce structural patterns with an AST tool (ast-grep), not line-grep — write the offending
*code shape*, not a text regex. And if a clean rule isn't obvious quickly, capture the learning
as prose and move on; an unenforced lesson in the index beats an hour spent on a fragile regex.

> **No shipped `### Audit Rule`.** The historical demo rule (banning Leaflet container
> `overflow` overrides) was project-specific. A copy is kept in
> `docs/ast-grep-examples/leaflet-container-overflow-override.sins.yml` purely as an ast-grep
> *teaching example* (multiline + CSS); it lives outside `sgconfig.yml`'s `ruleDirs` so the
> gate never runs it. Adapt the shape, not the literal rule, when you have an analogous
> project defect.

## 81. Copying a WAL-Mode SQLite File Copies an Empty Database
Scope: stack:sqlite
Trigger: WAL, sqlite, snapshot, copy

> **Incident (2026-07-03, task 1.7/1.9):** the pristine snapshot was taken with
> `copyFileSync(LIVE_DB, PRISTINE_DB)` right after applying DDL in WAL mode. The snapshot
> "worked" — until `/api/reset` restored it and every table was gone ("no such table: teams").
> In WAL mode the schema and data still lived in the `-wal` file; the main file was empty.

### Why It's Dangerous
The copy succeeds, the file exists, sizes look plausible — nothing fails until restore time,
in a different session, when the WAL is gone. A "run-and-observed" smoke of the *snapshot*
path is the only thing that catches it (and did).

### Rule
Snapshot a WAL-mode SQLite database with `VACUUM INTO '<path>'` (single consistent file),
never a raw file copy. On restore, also delete the target's stale `-wal`/`-shm` siblings
before reopening, or the old WAL replays over the snapshot.

## 82. Cowork Mount: Edits to Pre-Existing Files Look Truncated in the Sandbox
Scope: stack:cowork
Trigger: mounts, sandbox, truncation

> **Incident (2026-07-03):** host-side Write edits to files that already existed
> (types/schema.ts, verify_zod.ts) appeared truncated (975 of 38961 bytes) when read from the
> sandbox mount; bash-side deletes failed with EPERM; one bash-created file silently vanished.
> Newly created files synced fine in both directions. Same failure family as the Phase 0
> commit hazard already recorded in STATE.md.

### Rule
In Cowork sessions on this repo: treat the HOST (Read/Write/Edit tools) as the only truth for
file content; never trust sandbox-mount reads of files edited this session. Run installs,
compilers, and tests in a sandbox-local directory (e.g. ~/sv) populated via freshly created
files, then apply the verified diffs back to the host with Edit/Write. Never `git add`/commit
from the sandbox. Verify byte sizes after any cross-boundary copy.

## 83. Seed Inserts Must Follow FK-Dependency Order, Not Schema Declaration Order
Scope: stack:sqlite
Trigger: seed, foreign-keys, insert-order

> **Incident (2026-07-03, task 1.3):** the seed-migration runner inserted tables in the order
> they're declared in `types/schema.ts`'s `TABLES` object, with a comment claiming that was
> "FK-safe." It wasn't: `evidence` is declared ~line 397 but FK-references `tickets` (declared
> ~line 467), so every evidence row failed `FOREIGN KEY constraint failed` at insert time
> (FK enforcement was correctly ON). Same trap would bite any child table declared before its
> parent. The schema's declaration order is alphabetical-by-section for human readability, not
> topologically sorted.

### Rule
When bulk-inserting a multi-table bundle into a DB with `PRAGMA foreign_keys = ON`, insert in
**topological (FK-dependency) order** — parents before children — computed from the schema's
FK edges, NOT from the declaration/key order. Self-referential FKs (e.g. `hco_entities.parent`)
are handled by row order within the table (roots first); the topo sort skips the self-edge.
Stable sort (preserve declaration order among unrelated tables) so the seed-gate checksum is
deterministic. The declaration-order comment was a lie the type system couldn't catch — only
the live FK check at insert time surfaced it.

### Enforcement (prose, not ast-grep)
No `### Audit Rule`: this sin is *semantic* (insert rows in FK-topological order), not a
syntactic call/import shape, so it isn't expressible as an ast-grep pattern (a raw
`INSERT INTO …` is SQL, and ast-grep would flag every legitimate insert). It is enforced by
construction instead: `seeds/migrate/_run.ts:insertBundle` computes the topo order from the
schema's FK edges and is the ONLY sanctioned bulk-insert path — new seed layers merge into a
`Bundle` and go through it, never hand-rolling per-table declaration-order inserts.

## 84. A "Fresh DB" Builder That Uses CREATE TABLE IF NOT EXISTS Silently Accumulates
Scope: stack:sqlite
Trigger: CREATE TABLE IF NOT EXISTS, fresh-db, reset

> **Incident (2026-07-03, task 1.4):** `freshDb(path)` opened the target file and ran the
> generated DDL (which is all `CREATE TABLE IF NOT EXISTS`) — so on a *second* run against an
> existing `pristine.db`, the tables already held the first run's rows. The subsequent `INSERT`
> then hit `UNIQUE constraint failed: sources.source_id` (and would have doubled every count).
> A "pristine snapshot" that isn't reproducible from scratch defeats the entire reset mechanism
> (task 1.8) — re-running the seed would silently produce a corrupt 2×-scale DB.

### Rule
Any function that builds a *pristine* / *snapshot* DB for reset purposes MUST start from a
truly empty file: delete the target file AND its WAL/SHM sidecars before opening (SQLite leaves
`-wal`/`-shm` siblings that re-attach on open). `:memory:` is the exception (always fresh).
The DDL's `IF NOT EXISTS` is for forward-compat/idempotent schema application, NOT for
guaranteeing an empty starting state — those are different guarantees and conflating them is
the bug. Idempotency of the seed run is itself a test (`tsx .../index.ts` twice ⇒ identical
checksums).

### Enforcement (prose, not ast-grep)
No `### Audit Rule`: this sin is *behavioural* ("the builder must delete the file first"), not a
syntactic shape ast-grep can match — a `kind: function` matcher only proves a function named
`freshDb` exists, not that it rmSyncs, so it flags false and misses the real bug. Enforced by
construction + test instead: `seeds/migrate/_run.ts:freshDb` deletes the target file + its
`-wal`/`-shm` sidecars before opening, and the seed idempotency test (`tsx …/index.ts` twice ⇒
identical checksums) fails loudly if any snapshot builder regresses this.

## 86. A Migration Loader Passed the Module Namespace Instead of Its Named Const → 0 Rows, Silently
Scope: universal
Trigger: migration-loader, import-namespace, exports

> **Symptom:** `tables_assets` and `pipelines` came out of the Lumen migration EMPTY (count 0),
> yet the run reported success and FK check was clean — a valid, self-consistent, and wrong DB.
> The estate (≈80 nodes) simply vanished. Only auditing per-table counts after the rebuild
> (not trusting "done.") surfaced it.

> **Root cause:** the mock exposes its graph as `export const estate = { nodes, edges }` (nodes/
> edges are module-internal, NOT top-level exports). `loadLumen` did `import * as estate` then
> passed the whole **namespace** as `LumenSource.estate`. `buildEstate` read `estate.nodes` —
> but on the namespace that's `undefined` (the data is at `namespace.estate.nodes`). `?? []`
> then turned the miss into an empty array — a clean, silent zero. Classic §2 "zero ≠ missing"
> wearing a migration costume.

### Rule
When a runtime loader adapts a vendored module via `import * as m`, the module's `export const
foo = …` lives at `m.foo`, NOT spread onto `m`. Reach through to the named export
(`m.foo.nodes`), and **always audit per-table row counts after a migration rebuild** — a table
that should be populated but reads 0 is a wiring bug until proven a real empty. "The seed run
said done" is not verification; `SELECT COUNT(*)` per expected table is (§0b.12).

## 87. `process.exit()` While an HTTP Server Is Mid-Close Trips a libuv Assertion on Windows
Scope: stack:windows
Trigger: process.exit, server.close, libuv

> **Symptom:** the lean smoke asserted everything correctly (all ✓, "smoke: OK") but the process
> then crashed with `Assertion failed: !(handle->flags & UV_HANDLE_CLOSING), file src\win\async.c`
> and exited **127** — turning a passing check into a failing gate.

> **Root cause:** the script called `server.close()` (async — it schedules the socket handle to
> close) and immediately fell through to `process.exit(0)`. On Windows, calling `process.exit()`
> while a libuv handle is still in the CLOSING state trips an internal assertion. The assertion is
> about lifecycle, not logic — the assertions had already passed.

### Rule
Do not call `process.exit()` while any handle is mid-close. Await the close first: `server.close(cb)`
and exit inside `cb`, and call `server.closeAllConnections()` first so keep-alive sockets (undici's
`fetch` pool) don't delay the callback. Prefer setting `process.exitCode` and letting the loop drain;
if you must force-exit for a lingering agent, do it on an `unref()`'d timer AFTER your own handles are
fully closed (none in CLOSING state). Same shape as the WAL-sidecar race (§81): the check was right,
the teardown was wrong.

## 88. Client (Bundler) Extensionless Imports Break the Root (NodeNext) tsc When a Root-Checked Test Imports Them
Scope: stack:typescript
Trigger: NodeNext, extensions, imports, tsc

> **Symptom:** a `tests/*.test.ts` (checked by the root NodeNext tsconfig) imported a client module
> (`client/src/app/routes.ts`), and root `tsc --noEmit` errored on the CLIENT file's imports — even
> though the client's own `tsc -p client/tsconfig.json` was green.

> **Root cause:** the two tsconfigs use different module resolution. The client uses
> `moduleResolution: "bundler"` (extensionless relative imports are legal). The root uses
> `NodeNext` (relative imports REQUIRE an explicit extension). tsc type-checks imported files under
> the config of the program that pulled them in — so a root-checked test dragged the client file into
> NodeNext checking, where `import { X } from "../primitives/types"` (no extension) is an error.
> `exclude` does not help: an imported file is still checked even if excluded.

### Rule
A client module that a root-typechecked test needs to import must use **`.js` extensions** on its
relative imports (`from "../primitives/types.js"`) — `.js` resolves to `.ts` under BOTH bundler and
NodeNext, so it is the portable form. Keep such cross-boundary modules (route registry, pure helpers)
dependency-light and NodeNext-safe. Alternatively, keep root-checked tests importing only extension-
correct or zero-import client modules (e.g. `format.ts`).

---

## 97. PowerShell .ps1 Scripts Must Be ASCII (or UTF-8 with BOM) — Windows PowerShell 5.1 Reads No-BOM Files as ANSI
Scope: stack:windows
Trigger: .ps1, encoding, BOM, ANSI

**Symptom.** `start-server.ps1` parsed and ran fine under PowerShell 7 (pwsh) but the user got a
cascade of parser errors on their machine: *"The string is missing the terminator"* on a
`Write-Host` line containing a Unicode arrow, plus bogus *"Missing closing '}'"* errors above it.
The error text showed the tell-tale mojibake `â†'` / `Â·` — UTF-8 bytes being read one-byte-at-a-time.

**Cause.** The file was written UTF-8 **without a BOM**. **Windows PowerShell 5.1** (still the default
`powershell.exe` on Windows 11) decodes a BOM-less `.ps1` as **ANSI / Windows-1252**, so a UTF-8
multi-byte character (`->`=E2 86 92, mid-dot=C2 B7, ellipsis, `>>`) becomes 2-3 garbage chars. When
that happens *inside a string literal* it corrupts the closing quote and the parser derails, throwing
misleading brace-mismatch errors elsewhere. PowerShell 7 reads UTF-8 by default, which is why the
tool's own test (pwsh) passed and hid the bug.

### Rule
Author `.ps1` / `.bat` / `.cmd` files as **pure ASCII** (the safest — a subset of both ANSI and UTF-8,
so every shell agrees), or if you truly need Unicode, save as **UTF-8 with BOM**. Never put Unicode
box-drawing, arrows, mid-dots, ellipses, em-dashes, or the section sign in a Windows script's *string
literals*. Verify before shipping: scan for any byte > 127 (`[IO.File]::ReadAllBytes(path) | ? { $_ -gt 127 }`).
Do not trust a pwsh-7 parse/run as proof it works under 5.1. (Prose — Windows tooling gotcha.)
