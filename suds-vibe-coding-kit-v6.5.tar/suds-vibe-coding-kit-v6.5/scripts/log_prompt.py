#!/usr/bin/env python3
"""
log_prompt.py — deterministic, verbatim user-prompt capture (v6.1).

Why this exists: relying on the agent to copy the user's prompt into UserPromptLog.md
fails in practice (paraphrased entries, missing headers, logging that silently stops
mid-project). This script is called by TOOL HOOKS — outside the model's control — so
the raw prompt is appended verbatim on every turn. The log is PASSIVE evidence: the agent
never edits it (no "interpretation" lines to fill in v6.1).

Callers:
  Claude Code   .claude/settings.json UserPromptSubmit hook:
                    python scripts/log_prompt.py --hook claude-code
                (reads the hook's JSON on stdin; uses its "prompt" field)
  OpenCode      .opencode/plugins/prompt-logger.js appends directly (no python needed),
                but may also call:  python scripts/log_prompt.py --stdin --source opencode
  Manual/other  python scripts/log_prompt.py --text "the prompt" --source kilo

v6.1 changes:
  - Timestamps are OFFSET-AWARE ISO (`2026-06-18T12:06:03+05:30`) so cross-tool logs that
    mix local and UTC entries compare as correct instants (no more false "out-of-order").
  - NON-PROMPT GUARD: tool-call/result echoes and pasted file dumps are NOT prompts. They are
    skipped so the log stays a clean record of real instructions (the v6 OpenCode plugin
    logged 200-line file reads as "prompts", ballooning the file the agent re-reads).
  - SIZE CAP: an oversized body is head-truncated with a marker (a real long prompt is kept;
    a giant paste is trimmed).

Behavior:
  - Appends one entry to UserPromptLog.md (creates it with the standard header if absent).
  - Verbatim body inside a tilde fence (lengthened if the prompt itself contains tildes).
  - Skips exact-duplicate of the immediately previous captured prompt (hook double-fire guard).
  - Never raises to the caller: any internal failure prints to stderr and exits 0 so a
    logging problem can never block the user's actual turn.
"""
from __future__ import annotations

import json
import re
import sys
from datetime import datetime
from pathlib import Path

LOG = Path("UserPromptLog.md")

MAX_CHARS = 4000  # head-truncate bodies longer than this (keeps a real prompt, trims a paste)

# Patterns that identify a message as a tool echo / pasted file content, not a user prompt.
NON_PROMPT_PATTERNS = [
    re.compile(r"^\s*Called the .{1,60}? tool with", re.IGNORECASE),
    re.compile(r"^\s*<(path|content|type|file_contents|environment_details)\b", re.IGNORECASE),
    re.compile(r"</(content|file_contents|environment_details)>\s*$", re.IGNORECASE),
    re.compile(r"^\s*\{[\"']?(filePath|file_path|path)[\"']?\s*:", re.IGNORECASE),
    re.compile(r"^\s*(tool_result|function_results|<tool_use_error>)", re.IGNORECASE),
]

HEADER = """# UserPromptLog

Append-only record of every instruction the user gives, **verbatim**. Entries marked
`[hook:...]` were captured automatically by a tool hook (outside the model's control) and are
guaranteed verbatim. Entries marked `[agent:...]` were written by the agent in tools without
hook support — there the agent pastes the prompt verbatim, never paraphrased.

This file is PASSIVE EVIDENCE. **Never edit or delete past entries, and never re-stamp a
timestamp** — it is an append-only audit trail. (`just verify-all` runs `check-prompt-log`,
which fails only on a structurally malformed file; out-of-order timestamps across tools are a
harmless note, not something to "fix".)

---

<!-- APPEND BELOW. Newest at the bottom. Never edit entries above. -->
"""


def fence_for(text: str) -> str:
    f = "~~~"
    while f in text:
        f += "~"
    return f


def is_non_prompt(text: str) -> bool:
    """True if the text looks like a tool echo / pasted file content rather than a prompt."""
    head = "\n".join(text.lstrip().splitlines()[:3])
    return any(p.search(head) for p in NON_PROMPT_PATTERNS)


def clamp(text: str) -> str:
    if len(text) <= MAX_CHARS:
        return text
    return text[:MAX_CHARS] + f"\n…[truncated {len(text) - MAX_CHARS} chars by log_prompt]"


def read_prompt(argv: list[str]) -> tuple[str, str]:
    """Returns (prompt_text, source_label)."""
    source = "manual"
    if "--source" in argv:
        source = argv[argv.index("--source") + 1]
    if "--hook" in argv:
        kind = argv[argv.index("--hook") + 1]
        raw = sys.stdin.read()
        try:
            data = json.loads(raw)  # audit-disable (guarded by JSONDecodeError handler)
            return str(data.get("prompt", "")).strip(), f"hook:{kind}"
        except json.JSONDecodeError:
            return raw.strip(), f"hook:{kind}"
    if "--text" in argv:
        return argv[argv.index("--text") + 1].strip(), source
    if "--stdin" in argv:
        return sys.stdin.read().strip(), source
    return "", source


def last_logged_prompt(text: str) -> str:
    """Extract the verbatim body of the final fenced block, for dedupe."""
    blocks = re.findall(r"^(~~~+)\w*\n(.*?)^\1\s*$", text, re.MULTILINE | re.DOTALL)
    return blocks[-1][1].strip() if blocks else ""


def main() -> int:
    try:
        prompt, source = read_prompt(sys.argv[1:])
        if not prompt:
            return 0  # nothing to log (e.g. slash command turn)
        if is_non_prompt(prompt):
            return 0  # a tool echo / pasted file content — not a user instruction
        prompt = clamp(prompt)
        if LOG.exists():
            # Normalize CRLF→LF on read: the dedup regex anchors on `^~~~` (MULTILINE) and a
            # CRLF save by a Windows editor would otherwise defeat same-prompt dedup.
            existing = LOG.read_text(encoding="utf-8").replace("\r\n", "\n").replace("\r", "\n")
        else:
            existing = HEADER
            LOG.write_text(HEADER, encoding="utf-8")
        if last_logged_prompt(existing) == prompt:
            return 0  # duplicate fire of the same turn
        ts = datetime.now().astimezone().isoformat(timespec="seconds")  # offset-aware ISO
        f = fence_for(prompt)
        entry = (
            f"\n## {ts} — [{source}]\n"
            f"**Prompt (verbatim):**\n{f}text\n{prompt}\n{f}\n"
        )
        with LOG.open("a", encoding="utf-8", newline="\n") as fh:
            fh.write(entry)
    except Exception as e:  # noqa: BLE001 — logging must never block the user's turn
        print(f"[log_prompt] non-fatal: {e}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
