#!/usr/bin/env python3
"""
extract_audits.py — generate ast-grep rule files from SinsGotchasLearnings.md (v6.1).

v6 generated two parallel grep runners (bash + python) from `### Audit Recipe` blocks. Single-
line grep can't express multiline or structural patterns and kept matching the rule's own
explanatory comment — the single biggest source of wasted reasoning. v6.1 replaces that with
ast-grep: each learning may carry an `### Audit Rule` containing an ast-grep YAML rule, and
this script writes each rule to rules/<id>.sins.yml. `ast-grep scan` (via `just audit-sins`)
then applies them on the AST — multiline, structural, language-aware (incl. CSS), and incapable
of matching a comment.

Entry shape in SinsGotchasLearnings.md:

    ## 42. Some Defect

    ### Audit Rule
    ```yaml
    id: some-defect
    language: TypeScript
    severity: error          # error => fails the gate; warning/info/hint => note
    rule:
      pattern: alert($MSG)
    message: Prefer a custom UI over alert().
    ```

Rules are OPTIONAL. Most learnings are conceptual — leave them as prose; they still show in the
index. Only add a rule when the pattern is genuinely structural.

Usage:
    python scripts/extract_audits.py            # reads ./SinsGotchasLearnings.md, writes rules/
"""
from __future__ import annotations

import hashlib
import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

SRC = Path("SinsGotchasLearnings.md")
RULES_DIR = Path("rules")
STAMP = RULES_DIR / ".sins-source.sha256"
GEN_SUFFIX = ".sins.yml"  # generated rule files carry this suffix so we can clean only ours

ID_RE = re.compile(r"^\s*id:\s*([A-Za-z0-9_.-]+)\s*$", re.MULTILINE)


def read_text_lf(path: Path) -> str:
    """Read UTF-8 with CRLF/CR normalized to LF. Windows editors save CRLF; our entry-splitting
    regex (`\\n(?=## \\d+. )`) and the source-hash both assume LF. Without normalization a CRLF
    save would silently miss every entry AND change the hash, forcing spurious regeneration."""
    return path.read_text(encoding="utf-8").replace("\r\n", "\n").replace("\r", "\n")


def extract_rules(md: str) -> list[tuple[str, str]]:
    """Return (id, yaml_text) for every ast-grep rule block under an `### Audit Rule` heading."""
    # Drop the documentation sections before `## Entries` (How to write / Promotion path).
    # Their illustrative rule block is not a real rule — only numbered `## N.` entries are.
    # Avoids a spurious parse/warning from the example block.
    md = re.sub(r"\n## How to write an entry\b.*?(?=\n## Entries\b)", "\n", md, flags=re.DOTALL)
    out: list[tuple[str, str]] = []
    for entry in re.split(r"\n(?=## \d+\. )", md):
        # The Audit Rule section runs from its heading to the next `### ` or `## ` heading.
        sec = re.search(r"\n### Audit Rule\b(.*?)(?=\n### |\n## |\Z)", entry, re.DOTALL)
        if not sec:
            continue
        for block in re.findall(r"```ya?ml\n(.*?)```", sec.group(1), re.DOTALL):
            m = ID_RE.search(block)
            if not m:
                sys.stderr.write("⚠  skipping an Audit Rule block with no `id:` field\n")
                continue
            out.append((m.group(1), block.rstrip() + "\n"))
    return out


def write_rules(rules: list[tuple[str, str]], src_hash: str) -> None:
    RULES_DIR.mkdir(exist_ok=True)
    # Clean only previously-generated rule files (leave any hand-added rules untouched).
    for old in RULES_DIR.glob(f"*{GEN_SUFFIX}"):
        old.unlink()
    seen: set[str] = set()
    for rid, text in rules:
        if rid in seen:
            sys.stderr.write(f"⚠  duplicate rule id {rid!r}; the later one wins\n")
        seen.add(rid)
        (RULES_DIR / f"{rid}{GEN_SUFFIX}").write_text(text, encoding="utf-8")
    STAMP.write_text(src_hash + "\n", encoding="utf-8")


def source_hash(md: str) -> str:
    return hashlib.sha256(md.encode("utf-8")).hexdigest()


def is_stale() -> bool:
    """True if SinsGotchasLearnings.md changed since rules/ was last generated."""
    if not SRC.exists():
        return False
    if not STAMP.exists():
        return True
    return STAMP.read_text(encoding="utf-8").strip() != source_hash(read_text_lf(SRC))


def main() -> None:
    if not SRC.exists():
        print("no SinsGotchasLearnings.md — nothing to generate")
        return
    md = read_text_lf(SRC)
    rules = extract_rules(md)
    write_rules(rules, source_hash(md))
    print(f"» generated {len(rules)} ast-grep rule(s) in rules/ from SinsGotchasLearnings.md")


if __name__ == "__main__":
    main()
