#!/usr/bin/env python3
"""
dox_check.py — enforce the integrity of an OPTIONAL hierarchical AGENTS.md layer.

The kit's root AGENTS.md is the single source of truth for GLOBAL rules. For larger,
modular repos you may add a child AGENTS.md inside a durable subsystem folder (e.g.
backend/, frontend/, etl/). Child docs hold LOCAL contracts only — they must point back to
root for global rules and may only ADD constraints, never weaken a root rule.

DOX (the framework this is inspired by) states these as prose discipline. This script makes
them an enforced gate, which is the kit's whole philosophy: push every rule to the most
automatic enforcement layer it can reach.

Checks (each a hard failure unless noted):
  1. INDEXED      — every non-root AGENTS.md is listed in the "Child DOX Index" of the
                    NEAREST ancestor AGENTS.md.
  2. POINTS-TO-ROOT — every child AGENTS.md contains the marker line declaring root as the
                    source of global rules (default: a line containing "global rules" and
                    "root AGENTS.md", case-insensitive). Keeps children from re-stating
                    global rules (which would drift).
  3. NO-WEAKEN    — a child must not re-permit something the root forbids. Heuristic: for
                    each root "❌ <thing>" anti-pattern, if a child says "✅ <same thing>"
                    or "allowed"/"ok to" + that thing, fail. (Best-effort; catches the
                    obvious reversals DOX only warns about in prose.)
  4. SHAPE        — informational: child has the expected section headers.
  5. DOC-REFS (v6.5) — contract docs (ARCHITECTURE.md, DATA_MODEL.md, PRD.md, GLOSSARY.md,
                    EXECUTION_PLAN.md, DESIGN_GUIDELINES.md) are scanned for backticked
                    repo paths. A few missing = informational (docs may describe planned
                    work); WHOLESALE rot (≥3 missing AND >30% of the doc's path refs) =
                    hard failure. This is the objective core of "the descriptive files
                    stopped matching the code" — the doc has decayed into fiction, and an
                    agent that catches one stale doc rationally stops trusting all of them.
                    A path whose line ends with `<!-- planned -->` is exempt.
  6. MAP-FRESH (v6.5) — once the repo has real source files, RepoMapReadFirst.md must not
                    still contain "[fill in" placeholders and must not reference ≥3
                    now-nonexistent paths. Fix is one command: `just map-sync` (then fill
                    the curated block). This closes the RCA class where the map silently
                    described a deleted architecture.

If the repo has NO child AGENTS.md (the flat default), checks 1–4 no-op; 5–6 still run.

Usage:  python scripts/dox_check.py
Exit 0 = clean (or no hierarchy), 1 = integrity violation.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

ROOT = Path(".")
EXCLUDE_DIRS = {".git", "node_modules", ".next", "dist", "build", "__pycache__",
                ".venv", "venv", "migrate", "adopt", "examples"}
POINTS_TO_ROOT_RE = re.compile(r"global rules.*root AGENTS\.md|root AGENTS\.md.*global rules",
                               re.IGNORECASE | re.DOTALL)
EXPECTED_SECTIONS = ["Purpose", "Local Contracts"]  # minimal required shape for a child


def read_text_lf(path: Path) -> str:
    """Read UTF-8 (errors replaced) and normalize CRLF/CR → LF. Windows editors and some model
    Write calls save CRLF; our regexes anchor on `\\n`. Normalize on read, never on disk."""
    return path.read_text(encoding="utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")


def find_agents() -> list[Path]:
    out = []
    for p in ROOT.rglob("AGENTS.md"):
        if any(part in EXCLUDE_DIRS for part in p.parts):
            continue
        out.append(p)
    return out


def nearest_ancestor_agents(child: Path, all_agents: set[Path]) -> Path | None:
    """The closest AGENTS.md strictly above child's directory."""
    for parent in child.parent.parents:
        cand = parent / "AGENTS.md"
        if cand in all_agents:
            return cand
    root_doc = ROOT / "AGENTS.md"
    return root_doc if root_doc in all_agents and child != root_doc else None


def root_forbidden_phrases(root_text: str) -> list[str]:
    """Extract the short phrase after each root '❌' anti-pattern bullet."""
    phrases = []
    for m in re.finditer(r"❌\s*\*?\*?([^.\n*]{4,60})", root_text):
        phrases.append(m.group(1).strip().lower())
    return phrases


# --------------------------------------------------------------- v6.5 doc-freshness
CONTRACT_DOCS = ["ARCHITECTURE.md", "DATA_MODEL.md", "PRD.md", "GLOSSARY.md",
                 "EXECUTION_PLAN.md", "DESIGN_GUIDELINES.md"]
# A backticked token counts as a repo path if it is bare-path-shaped AND either contains a
# separator or ends in a known source/config extension. `<placeholders>`, globs, URLs,
# and commands with spaces never match.
PATH_TOKEN_RE = re.compile(r"`([A-Za-z0-9_.\-/\\]+)`")
PATH_EXTS = (".py", ".ts", ".tsx", ".js", ".jsx", ".json", ".md", ".sql", ".css", ".html",
             ".yml", ".yaml", ".toml", ".env", ".txt", ".csv", ".ps1", ".sh")


def _path_refs(text: str) -> list[str]:
    refs = []
    for line in text.splitlines():
        if line.rstrip().endswith("<!-- planned -->"):
            continue
        for tok in PATH_TOKEN_RE.findall(line):
            t = tok.strip().lstrip("./")
            if not t or t.startswith(("http", "www.")):
                continue
            if "/" in t or "\\" in t or t.lower().endswith(PATH_EXTS):
                refs.append(t)
    return refs


def _repo_has_real_source() -> bool:
    """True once the project has been meaningfully built (so template docs are exempt)."""
    if (ROOT / "src").is_dir():
        return True
    n = 0
    for pat in ("*.py", "*.ts", "*.tsx", "*.js", "*.jsx"):
        for p in ROOT.rglob(pat):
            if any(part in EXCLUDE_DIRS or part in ("scripts", "verification", "skills")
                   for part in p.parts):
                continue
            n += 1
            if n >= 15:
                return True
    return False


def check_doc_refs() -> tuple[list[str], list[str]]:
    """(failures, infos). Contract docs must not decay into fiction (check 5)."""
    failures: list[str] = []
    infos: list[str] = []
    for name in CONTRACT_DOCS:
        doc = ROOT / name
        if not doc.exists():
            continue
        text = read_text_lf(doc)
        if "[fill in" in text.lower():
            continue  # still a template — nothing to reconcile yet
        refs = _path_refs(text)
        missing = sorted({r for r in refs if not (ROOT / r).exists()})
        if not missing:
            continue
        if len(missing) >= 3 and len(missing) / max(len(refs), 1) > 0.30:
            failures.append(
                f"STALE DOC: {name} references {len(missing)}/{len(refs)} paths that no "
                f"longer exist ({', '.join(missing[:6])}{'…' if len(missing) > 6 else ''}). "
                f"The doc has drifted from the code — reconcile it (its own commit, "
                f"AGENTS.md §5) or mark planned paths with `<!-- planned -->`.")
        else:
            infos.append(f"{name}: {len(missing)} referenced path(s) missing "
                         f"({', '.join(missing[:4])}) — planned work or drift? "
                         f"Mark planned lines `<!-- planned -->` or reconcile.")
    return failures, infos


def check_map_fresh() -> list[str]:
    """RepoMapReadFirst.md must describe the repo that exists (check 6)."""
    doc = ROOT / "RepoMapReadFirst.md"
    if not doc.exists() or not _repo_has_real_source():
        return []
    text = read_text_lf(doc)
    failures: list[str] = []
    if "[fill in" in text.lower():
        failures.append("STALE MAP: RepoMapReadFirst.md still contains '[fill in]' "
                        "placeholders although the repo has real source files. Run "
                        "`just map-sync`, then fill the curated block with the real "
                        "entry points.")
    refs = _path_refs(text)
    missing = sorted({r for r in refs if not (ROOT / r).exists()})
    if len(missing) >= 3:
        failures.append(f"STALE MAP: RepoMapReadFirst.md references {len(missing)} paths "
                        f"that no longer exist ({', '.join(missing[:6])}"
                        f"{'…' if len(missing) > 6 else ''}). Run `just map-sync`.")
    return failures


def check_verify_parity() -> list[str]:
    """Ensure verify.ps1 (the no-just PowerShell fallback) runs the same gates as the
    justfile's `verify:` chain. Two hand-maintained gate lists drift; this catches it.
    Best-effort: only runs if both files exist."""
    problems: list[str] = []
    jf, ps = Path("justfile"), Path("verify.ps1")
    if not jf.exists() or not ps.exists():
        return problems
    m = re.search(r"^verify:\s*(.+)$", read_text_lf(jf), re.M)
    if not m:
        return problems
    just_gates = [g for g in m.group(1).split() if g not in ("&&", "@echo")]
    ps_text = read_text_lf(ps)
    for g in just_gates:
        # verify.ps1 references each gate via a Gate "name" label
        if f'Gate "{g}"' not in ps_text:
            problems.append(f"PARITY: `just verify` runs '{g}' but verify.ps1 does not — "
                            f"the PowerShell fallback would skip it. Add it to verify.ps1.")
    return problems


def main() -> None:
    agents = find_agents()
    root_doc = ROOT / "AGENTS.md"

    # Always-on checks, independent of the hierarchy (v6.5): gate parity + doc freshness.
    parity = check_verify_parity()
    doc_failures, doc_infos = check_doc_refs()
    doc_failures += check_map_fresh()
    for i in doc_infos:
        print(f"  i {i}")
    standalone = parity + doc_failures

    if root_doc not in agents:
        if standalone:
            print("FAIL: dox-check found problems:")
            for p in standalone:
                print(f"  x {p}")
            sys.exit(1)
        print("» dox-check: no root AGENTS.md — skipping hierarchy checks")
        sys.exit(0)

    children = [a for a in agents if a != root_doc]
    if not children:
        if standalone:
            print("FAIL: dox-check found problems:")
            for p in standalone:
                print(f"  x {p}")
            sys.exit(1)
        print("» dox-check: flat layout — parity + doc-freshness clean, no hierarchy to enforce")
        sys.exit(0)

    print(f"» dox-check: {len(children)} child AGENTS.md found")
    failures: list[str] = list(standalone)
    all_set = set(agents)
    root_text = read_text_lf(root_doc)
    forbidden = root_forbidden_phrases(root_text)

    for child in sorted(children):
        rel = child.as_posix()
        text = read_text_lf(child)

        # 1. INDEXED in nearest ancestor's Child DOX Index
        anc = nearest_ancestor_agents(child, all_set) or root_doc
        anc_text = read_text_lf(anc)
        idx_m = re.search(r"#+\s*(?:\d+[.)]?\s*)?Child DOX Index(.*)", anc_text,
                          re.DOTALL | re.IGNORECASE)
        child_dir = child.parent.as_posix()
        indexed = idx_m and (child_dir in idx_m.group(1) or rel in idx_m.group(1)
                             or child.parent.name in idx_m.group(1))
        if not indexed:
            failures.append(f"NOT INDEXED: {rel} is not listed in {anc.as_posix()}'s "
                            f"'## Child DOX Index'")

        # 2. POINTS-TO-ROOT marker
        if not POINTS_TO_ROOT_RE.search(text):
            failures.append(f"NO ROOT POINTER: {rel} must state that global rules live in "
                            f"the root AGENTS.md (add a line referencing 'global rules' + "
                            f"'root AGENTS.md').")

        # 3. NO-WEAKEN: child re-permits a root-forbidden thing
        low = text.lower()
        for ph in forbidden:
            if not ph:
                continue
            # child explicitly allows what root forbids
            if (f"✅ {ph}" in low or f"allowed: {ph}" in low
                    or f"ok to {ph}" in low or f"it is fine to {ph}" in low):
                failures.append(f"WEAKENS ROOT: {rel} appears to re-permit a root-forbidden "
                                f"rule: '{ph}'")

        # 4. SHAPE (informational)
        missing = [s for s in EXPECTED_SECTIONS if f"## {s}" not in text and f"# {s}" not in text]
        if missing:
            print(f"  i {rel}: missing recommended section(s): {', '.join(missing)}")

    if failures:
        print("\nFAIL: dox-check found hierarchy integrity violations:")
        for f in failures:
            print(f"  x {f}")
        print("\nFix: index every child under its parent's '## Child DOX Index', add the "
              "root-pointer line, and ensure children only ADD rules (never re-permit a "
              "root ❌). See AGENTS.md §10.")
        sys.exit(1)

    print("OK: dox-check clean (hierarchy indexed, root-pointed, no weakening, docs fresh)")
    sys.exit(0)


if __name__ == "__main__":
    main()
