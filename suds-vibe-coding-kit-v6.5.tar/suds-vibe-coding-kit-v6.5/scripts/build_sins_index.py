#!/usr/bin/env python3
"""
build_sins_index.py — Tier 2 of the learnings system (v6.5: targeted retrieval).

Collapses SinsGotchasLearnings.md into SinsGotchasLearnings_INDEX.md. The v6.5 index is
organized for RETRIEVAL AT THE POINT OF ACTION, not as a flat incident list — because a
lesson only prevents a repeat if it's in context at the moment the risky code is written:

  1. `★ ALWAYS`   — entries marked `Digest: yes` (project-specific always-on rules that
                    extend AGENTS.md §0b). Soft-capped at ~20: it's an attention budget,
                    not a library. The generator warns beyond that.
  2. `TRIAGE DUE` — entries with `Recurrences: 2+` that are still prose. A repeated sin is
                    PROOF the prose layer failed — promote it (rule / test / type / digest)
                    instead of documenting it a third time.
  3. Trigger map  — `Trigger:` tokens (globs, APIs, keywords) → §numbers. Before touching an
                    area, grep this map for the files/tech you're about to change.
  4. The one-line-per-entry list (unchanged from v6.1), minus…
  5. Enforced entries — anything with an `### Audit Rule` or `Enforced: rule|test|type` is
                    collapsed to a single trailing line. The gate checks those now; reading
                    them is wasted context ("trust the green gate").

v6.5 entry metadata (all OPTIONAL lines directly under the `## N. Title` heading; old
entries without them still parse and land in the general list):

    Scope: universal | stack:<react|python|windows|sqlite|…> | project
    Trigger: <comma-separated globs / APIs / keywords>   e.g. fetch, src/api/**, useEffect
    Enforced: prose | rule | test:<path> | type:<path>
    Digest: yes | no
    Recurrences: <int>   (increment when the same sin recurs; 2+ ⇒ promotion is mandatory)

Usage: python scripts/build_sins_index.py SinsGotchasLearnings.md > SinsGotchasLearnings_INDEX.md
"""
from __future__ import annotations
import re
import sys
from collections import defaultdict
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except (AttributeError, ValueError):
    pass

DIGEST_SOFT_CAP = 20


def read_text_lf(path: Path) -> str:
    """Read UTF-8 with CRLF/CR normalized to LF. The entry-splitting regex
    (`\\n(?=## \\d+. )`) anchors on `\\n`; a CRLF save would silently drop every entry."""
    return path.read_text(encoding="utf-8").replace("\r\n", "\n").replace("\r", "\n")


def parse_entry(e: str) -> dict | None:
    m = re.match(r"## (\d+)\.\s+(.+)", e)
    if not m:
        return None
    num, title = m.group(1), m.group(2).strip()
    meta: dict[str, str] = {}
    for line in e.splitlines()[1:12]:
        lm = re.match(r"\s*\*?\*?(Scope|Trigger|Enforced|Digest|Recurrences)\*?\*?\s*:\s*(.+)",
                      line, re.IGNORECASE)
        if lm:
            meta[lm.group(1).lower()] = lm.group(2).strip().rstrip("*").strip("`")
        elif line.startswith(("###", "> **Incident", "## ")):
            break
    rule = ""
    rm = re.search(r"### Rule[^\n]*\n+\*?\*?(.+?)(?:\n|$)", e)
    if rm:
        rule = re.sub(r"[*`]", "", rm.group(1)).strip()
        rule = rule.split(". ")[0][:130]
    enforced_field = meta.get("enforced", "").lower()
    has_audit = bool(re.search(r"^### Audit Rule", e, re.M))
    rmatch = re.match(r"\d+", meta.get("recurrences", "0") or "0")
    return {
        "num": num,
        "title": title,
        "rule": rule,
        "scope": meta.get("scope", ""),
        "triggers": [t.strip() for t in meta.get("trigger", "").split(",") if t.strip()],
        "enforced": has_audit or enforced_field.startswith(("rule", "test", "type")),
        "enforced_how": ("ast-grep" if has_audit else enforced_field) or "prose",
        "digest": meta.get("digest", "").lower().startswith("y"),
        "recur": int(rmatch.group(0)) if rmatch else 0,
    }


def line_for(x: dict) -> str:
    gear = " ⚙" if x["enforced"] else ""
    recur = f" 🔁×{x['recur']}" if x["recur"] else ""
    scope = f" [{x['scope']}]" if x["scope"] and x["scope"] != "universal" else ""
    return f"- **§{x['num']}{gear}**{recur}{scope} {x['title']}" + (
        f" — {x['rule']}" if x["rule"] else "")


def main() -> None:
    md = read_text_lf(Path(sys.argv[1]))
    raw = re.split(r"\n(?=## \d+\. )", md)
    entries = [x for x in (parse_entry(e) for e in raw) if x]

    out = ["# SinsGotchasLearnings_INDEX",
           "",
           "Generated from SinsGotchasLearnings.md — regenerate with `just sins-sync`. Read the",
           "★ALWAYS block every session; grep the trigger map for the area you're about to touch",
           "and open ONLY those full entries. ⚙ entries are gate-enforced — do NOT re-read or",
           "re-check them by hand; `just verify` does it.",
           ""]

    digest = [x for x in entries if x["digest"] and not x["enforced"]]
    if digest:
        out.append("## ★ ALWAYS (project digest — internalize before coding)")
        out.append("")
        out += [line_for(x) for x in digest]
        if len(digest) > DIGEST_SOFT_CAP:
            out.append("")
            out.append(f"  ⚠ {len(digest)} always-on entries (> {DIGEST_SOFT_CAP}). This is an "
                       "attention budget, not a library — run the sins-triage skill and demote "
                       "or promote-to-gate the excess.")
        out.append("")

    due = [x for x in entries if x["recur"] >= 2 and not x["enforced"]]
    if due:
        out.append("## ⚠ TRIAGE DUE — repeated while still prose (promotion is mandatory)")
        out.append("")
        out += [line_for(x) for x in due]
        out.append("")

    trig_map: dict[str, list[str]] = defaultdict(list)
    for x in entries:
        for t in x["triggers"]:
            trig_map[t].append(f"§{x['num']}")
    if trig_map:
        out.append("## Trigger map — about to touch X? read the listed entries first")
        out.append("")
        for t in sorted(trig_map):
            out.append(f"- `{t}` → {', '.join(trig_map[t])}")
        out.append("")

    general = [x for x in entries if not x["enforced"] and not x["digest"]]
    if general:
        out.append("## All prose entries")
        out.append("")
        out += [line_for(x) for x in general]
        out.append("")

    enforced = [x for x in entries if x["enforced"]]
    if enforced:
        out.append("## ⚙ Enforced by `just verify` — trust the gate, skip reading")
        out.append("")
        out.append("  " + " · ".join(
            f"§{x['num']} ({x['enforced_how']})" for x in enforced))
        out.append("")

    out.append("Legend: ⚙ gate-enforced · 🔁×N recurred N times · [stack:…]/[project] scope.")
    sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
