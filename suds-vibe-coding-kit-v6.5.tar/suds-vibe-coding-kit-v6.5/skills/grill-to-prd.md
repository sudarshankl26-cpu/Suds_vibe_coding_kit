# Skill: grill-to-prd

Adapted from Matt Pocock's `grill-with-docs` (skills-main), rewired for this kit's
file-based contracts instead of GitHub issues. Use this at the START of any new
project or feature, BEFORE writing PRD.md. Its job: close the misalignment gap —
the #1 cause of "the agent built the wrong thing" — by interviewing the user
relentlessly until the design tree is fully resolved.

## How to run it (the prompt the agent follows)

> Interview me relentlessly about this project/feature until we reach shared
> understanding. Walk down each branch of the design tree, resolving dependencies
> between decisions one at a time. **Ask ONE question at a time and wait for my
> answer before the next.** For each question, give your own recommended answer and
> a one-line reason, so I can just say "yes" or correct you. If a question can be
> answered by reading the existing repo or contracts, read them instead of asking.

## Rules during the session

**One question at a time.** Never present a wall of questions. The dependency
between answers matters — later questions change based on earlier ones.

**Ask what you don't know — never what was already said.** Before the first question,
extract everything the user's opening description (and the repo/contracts) already answers,
and skip those questions entirely. Re-asking provided information burns the user's patience
and signals you didn't read. Order the rest broad → narrow: what it does → who uses it and
why → which features enable that → the edge cases.

**Adapt to the user's signals.** Technical vocabulary → skip the basics, go deeper on
architecture and edge cases. Vague descriptions → guide with concrete options rather than
open-ended questions. Roughly 70% understanding, 30% educating about trade-offs.

**Always recommend.** Every question carries your best-guess answer + why. This
turns the session from an interrogation into a fast confirm/correct loop.

**Sharpen fuzzy language.** When the user says a vague or overloaded term ("account",
"user", "cancel"), stop and pin it: "You said 'account' — do you mean the Customer
or the login User? They're different." Resolve it, then write it into GLOSSARY.md
right then (don't batch).

**Probe with concrete scenarios.** Invent specific edge cases that force precision:
"What happens if the order is cancelled AFTER fulfilment starts but BEFORE shipping?"
Boundaries between concepts surface fastest under a concrete scenario. When a capability
turns out to be validation-heavy or edge-case-heavy (complex logic, a parser, money/units
math), **mark it risk-flagged** in its acceptance criteria, so EXECUTION_PLAN.md and
AGENTS.md §4a apply — that unit gets its edge cases written as tests first (eval-first).

**Cross-reference the code/contracts.** If the user states how something works and
the existing code or DATA_MODEL.md disagrees, surface the contradiction immediately.

**Update contracts inline, as decisions crystallize:**
- A resolved term → add it to `GLOSSARY.md` immediately, in canonical form.
- A hard-to-reverse architectural decision → offer an ADR (see below).
- A scoping decision (in/out) → note it for PRD.md §5/§7.
- A UI project → pin the **design language** (brand colors / typography / component library if
  any) and otherwise confirm the `DESIGN_GUIDELINES.md` anti-slop defaults; tag brand
  non-negotiables `#EXPORT_CRITICAL`. (Skip for CLIs / libraries / pipelines.)
- A non-negotiable surfaced (a security rule, an invariant, a correctness requirement) → tag it
  **`#EXPORT_CRITICAL`** in the PRD/contract where it lands (AGENTS.md §1a).
- An answer the user defers, or one you have to assume to keep moving → record it as a PRD §9
  open question and drop a **`#PLAN_UNCERTAINTY`** at the assumption, so it's resolved before
  that phase is done (don't let a guessed requirement masquerade as settled).

**Offer an ADR only when ALL THREE are true** (keep them rare):
1. Hard to reverse (changing your mind later is costly).
2. Surprising without context (a future reader will ask "why did they do this?").
3. A real trade-off (genuine alternatives existed; you picked one for reasons).
If any is missing, skip it. ADRs live in `docs/adr/NNNN-slug.md`, one paragraph is
fine: what's the context, what did we decide, why. See `docs/adr/0000-template.md`.

## The final question — the dev port

Before producing the PRD, ask ONE last question: the development server port (only if
the app actually runs a server). Recommend a **random non-standard port** to avoid the
usual collisions (3000, 5173, 8000, 8080). Generate a recommendation in a quiet range,
e.g. 4000–4999 or 49152–65535, and present it:

> "Last one: what port should the dev server run on? I recommend **PORT** (random,
> avoids the usual 3000/5173/8000 clashes). Accept, or give me your own?"

Whatever is chosen, write it to `.env` as `PORT=<n>` (copy `.env.example` first) — this
is the single source of truth (SinsGotchasLearnings §24). Every consumer (server, client
proxy, start/stop scripts) reads it from there. Note it for ARCHITECTURE.md too.

## When the grilling is done

Only when every branch of the design tree is resolved, produce PRD.md using the
kit's PRD template, then proceed to the normal authoring order (GLOSSARY is already
partly filled from the session) → DATA_MODEL → ARCHITECTURE → EXECUTION_PLAN.

The PRD's user-story list should be LONG and exhaustive ("As an <actor>, I want
<feature>, so that <benefit>"), covering every aspect surfaced during grilling.
Each story should map to at least one task that will land in
OpenTasksMustCompleteAll.md and one phase in EXECUTION_PLAN.md.
