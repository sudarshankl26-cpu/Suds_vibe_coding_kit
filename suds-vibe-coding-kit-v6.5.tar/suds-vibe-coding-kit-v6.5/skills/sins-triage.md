# Skill: sins-triage — consolidate the taxonomy so it teaches instead of accumulates

**Trigger:** run `just sins-triage` first; do this ritual when it flags anything, or every
~10 new entries, or at the end of a phase. Takes one focused session.

**Why this exists.** A model does not learn by having written something down — an entry only
prevents a repeat if it is (a) in context at the moment the risky code is generated, or
(b) enforced by a gate that runs regardless. An append-only file drifts toward a 100-entry,
95 KB archive that nobody can afford to load: documentation, not learning. This ritual is the
motor that pushes each lesson **up the enforcement ladder** (prose → digest → test → ast-grep
rule → type) and keeps the always-read surface small enough to actually steer behavior.

## The ritual, in order

### 1. Merge duplicates and near-duplicates
Same root cause, different incident → ONE entry. Keep the clearest title, fold the other
incidents into the `> **Incident:**` line ("also seen as: …"), sum their `Recurrences:`,
and delete the duplicates. Renumber nothing — gaps in §numbers are fine and expected.
(Typical clusters: silent-zero + `?? 0` fallback; fabricated values + fabricated confidence;
several Windows-encoding entries.)

### 2. Generalize project-scoped narratives
An entry titled "Phase 4B: the SignalMatrix port…" teaches nothing to the next project.
Extract the portable rule ("port the information architecture, not the invented data" →
"never invent data to fill a UI designed against a richer schema"), rewrite the entry around
it, set `Scope: universal` or `stack:<x>`, and compress the war story to one Incident line.
If there is no portable rule, the entry is a WorkLog memory, not a sin — move it to
`WorkLogAfterEachRun.md` and delete it here.

### 3. Promote — the recurrence ratchet (non-negotiable)
For every entry with `Recurrences: 2+` still at `Enforced: prose`, prose has **proven
insufficient**. Promote to the most automatic layer it can reach, in this order of preference:

| Layer | When | How |
|---|---|---|
| type/constructor | invariant expressible in the type system | add to `types/`, set `Enforced: type:<path>` |
| ast-grep rule | structural code shape | add `### Audit Rule`, run `just sins-sync` |
| regression test | behavior, not shape | add to `tests/`, set `Enforced: test:<path>` |
| ★ digest | judgment call, not mechanizable | set `Digest: yes` (mind the ~20 cap) |

Do not write a third prose paragraph about it. That is the one forbidden outcome.

### 4. Add retrieval metadata to bare entries
Every prose entry needs a `Trigger:` line — the globs / APIs / keywords an agent would have
in hand at the moment the mistake happens (`fetch`, `useEffect`, `src/db/**`, `Math.max`,
`.ps1`, `JSON.parse`). No trigger = unreachable at the point of action = dead weight.

### 5. Collapse and cap
- Entries now enforced by a gate: strip their body to Incident + Rule + the `Enforced:` line
  (the gate carries the detail; the index already hides them from the read path).
- ★ digest over ~20 entries: demote the weakest back to trigger-only, or promote to a gate.
- Superseded / obsolete-stack entries: move to `SinsArchive.md` (create it if absent) —
  never delete history, just get it out of the read path.

### 6. Regenerate and verify
`just sins-sync` (rebuilds rules/ + the index), then `just verify`. Commit as its own commit:
`chore(sins): triage — merged N, promoted M, archived K`.

## Invariants
- The full file may be long; the **INDEX must stay skimmable** (~1 line/entry) and the
  ★ALWAYS block small. Attention is the scarce resource, not disk.
- Never weaken or delete an `### Audit Rule` during triage; exceptions use
  `ast-grep-ignore` at the call site (AGENTS.md §3).
- Triage edits `SinsGotchasLearnings.md` only (+ `types/`, `tests/`, `SinsArchive.md` for
  promotions) — it never touches contract files.
