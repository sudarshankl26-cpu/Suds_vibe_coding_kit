<#
.SYNOPSIS
    Retrofit Sud's Vibe Coding Kit onto an EXISTING, non-kit project.
.DESCRIPTION
    Run from INSIDE your existing project, pointing -Kit at the unpacked kit. Plan-only
    by default (changes nothing); add -Apply to execute. Never overwrites your existing
    files - only adds missing kit machinery, installs the gate hooks, and generates the
    repo map. Then prints the prompt to reverse-engineer the contracts from your code.

    Step 1: unpack the kit tar OUTSIDE this project, e.g.
        tar -xf suds-vibe-coding-kit-v6.5.tar -C C:\temp\
    Step 2 (plan):   .\adopt\adopt-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.5
    Step 3 (apply):  .\adopt\adopt-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.5 -Apply
#>
param(
    [Parameter(Mandatory = $true)][string]$Kit,
    [switch]$Apply
)
$ErrorActionPreference = "Stop"
# The project is wherever you're standing, NOT where this launcher lives (the kit is
# typically unpacked elsewhere). Use the current directory. Run from INSIDE your project.
$Project = (Get-Location).Path

$py = $null
foreach ($c in @('python','python3','py')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $py = $cmd; break }
}
if (-not $py) { Write-Host "[ERROR] Python not found on PATH." -ForegroundColor Red; exit 1 }

$script = Join-Path (Join-Path $Kit "adopt") "adopt_kit.py"
$argsList = @($script, "--kit", $Kit, "--project", $Project)
if ($Apply) { $argsList += "--apply" } else { $argsList += "--plan" }
& $py.Source @argsList
