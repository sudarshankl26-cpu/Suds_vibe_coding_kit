# MIGRATION.md — get an existing project onto kit v6.5

> **One rule:** unpack the kit tar *somewhere outside your project* and point the
> tool *at* your project. Never extract the tar on top of an existing project —
> that is the only way to lose work, and every path below exists so you don't.

Three paths. Pick by looking at the folder you're upgrading:

| Your project today | Path | Tool | Overwrites your files? |
|---|---|---|---|
| **Already on v6.4** → v6.5 | **A — Swap** | manual (below) | only stock infra you swap by hand |
| **On v4 / v5 / early-v6** → v6.5 | **B — Migrate** | `migrate/migrate_kit.py` | **Never** — stages everything as `.kit-incoming` for review |
| **Built without the kit** (any stack) | **C — Adopt** | `adopt/adopt_kit.py` | **Never** — only adds missing files |

Whichever path, you end on the same finish line: `just doctor` green →
`just verify-all` green. That pair is the proof the kit works on your machine.

---

## One-time prerequisite (install once, ever)

[`mise`](https://mise.jdx.dev) is the single gateway. It reads `.mise.toml` and
provisions `just`, `uv`, `node`, `pnpm`, and **`ast-grep`** at pinned versions, so
the agent never burns a turn installing toolchain.

```powershell
winget install jdx.mise      # Windows
# WSL / macOS / Linux:  curl https://mise.run | sh
```

No mise? Install the one new v6.5 prereq directly: `pip install ast-grep-cli`
(or `npm i -g @ast-grep/cli`). Everything else (`just`, `uv`, `pnpm`) you likely have.

---

## Path A — v6.4 → v6.5 (the swap)

v6.5 is **additive and infrastructure-only** vs v6.4. Your contracts, learnings,
logs, STATE.md, and `src/` are untouched. ~12 stock-infra files swap, 4 new files
land, then 2 files get a small hand-merge.

```bash
# 0. from inside your project, on a clean tree:
git checkout -b upgrade-v6.5
git tag pre-v6.5                      # rollback point

# 1. unpack v6.5 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.5.tar -C /tmp/      # or C:\temp\
KIT=/tmp/suds-vibe-coding-kit-v6.5

# 2. swap the stock-infra files (your project didn't edit these; if you did, diff first):
for f in scripts/run_gate.py scripts/dox_check.py scripts/sins.py \
         scripts/extract_audits.py scripts/build_sins_index.py \
         scripts/build_repo_map.py scripts/log_prompt.py \
         verification/check_open_tasks.py verification/check_prompt_log.py \
         justfile sgconfig.yml; do
  cp "$KIT/$f" "$f"
done

# 3. add the new files:
cp "$KIT/skills/sins-triage.md" skills/sins-triage.md
mkdir -p rules docs/ast-grep-examples .opencode
cp "$KIT/rules/.gitkeep" rules/.gitkeep
cp "$KIT/docs/ast-grep-examples/"*.sins.yml docs/ast-grep-examples/
cp "$KIT/.opencode/README.md" .opencode/README.md
```

**The two hand-merges** (the only files you may have edited — diff and bring the v6.5
deltas over, keep anything project-specific):

- **`AGENTS.md`** — v6.5 deltas to fold in: §0 step 3 (★ALWAYS + trigger map),
  §0b (≤20-item attention budget note), §1a end ("Enforcement honesty" paragraph),
  §3 (Playwright `--with-deps` note, v6.5 no-silent-false-green policy),
  §4b (subagent economics / context firewall), §7 (output-language wording),
  §8 (concurrent-multi-agent warning).
- **`SinsGotchasLearnings.md`** — §14 (emoji-in-ui) and §80 (leaflet overflow)
  lost their shipped `### Audit Rule` blocks in v6.5 (they were project-specific).
  If you copied either, keep yours; if you relied on the shipped ones, adapt the
  shape from `docs/ast-grep-examples/` and scope `files:` to your UI path.

```bash
# 4. clear v6.4-generated rules, rebuild, prove green:
rm -rf rules/*.sins.yml rules/.sins-source.sha256
mise install                  # provisions ast-grep if missing
just sins-sync                # regenerate rules/ + index from YOUR taxonomy
just map-sync                 # rebuild RepoMapReadFirst.md
just doctor                   # v6.5: prove every gate can execute
just verify-all               # must be green
```

Roll back with `git reset --hard pre-v6.5`.

---

## Path B — v4 / v5 / early-v6 → v6.5 (the migrator)

The migrator is the safest tool: it **backs up, branches, and overwrites nothing**.
It classifies every file (PRESERVE / OVERWRITE / ADD / MERGE / SKIP-DRIFTED /
RETIRE), auto-applies only the safe categories, and stages anything that needs
your judgment next to yours as `<file>.kit-incoming`.

```bash
# 1. unpack v6.5 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.5.tar -C /tmp/
KIT=/tmp/suds-vibe-coding-kit-v6.5

# 2. from INSIDE your project — see the plan (changes nothing):
python "$KIT/migrate/migrate_kit.py" --kit "$KIT" --project . --plan
#   Windows launcher (no -Apply = plan-only):
#   & "$KIT\migrate\migrate-kit.ps1" -Kit "$KIT"

# 3. apply — creates .kit-backup-<stamp>/ + a git branch, stages merges as .kit-incoming:
python "$KIT/migrate/migrate_kit.py" --kit "$KIT" --project . --apply --remove-retired
#   launcher:  & "$KIT\migrate\migrate-kit.ps1" -Kit "$KIT" -Apply -RemoveRetired
```

Read every line of the plan. Categories: **PRESERVE** (untouched),
**OVERWRITE** (safe bugfix — only if your copy is byte-identical to stock v4),
**ADD** (new files), **MERGE / SKIP-DRIFTED** (need you — staged as `.kit-incoming`),
**RETIRE** (superseded — `--remove-retired` deletes them). On a v5/v6 project
expect most infra under SKIP-DRIFTED: that's the safe path, nothing auto-replaced.

**Resolve each `.kit-incoming`** — the only judgment part. Hand it to your agent:

> Read `migrate/MIGRATION.md`. Walk me through each `*.kit-incoming` file ONE AT A
> TIME: show the diff, tell me what the kit changed, recommend an action, apply
> only when I confirm.

The two that have tooling:

- **`SinsGotchasLearnings.md.kit-incoming`** — don't hand-merge. Run the helper:
  ```bash
  python "$KIT/migrate/merge_sins.py" \
      --mine SinsGotchasLearnings.md \
      --incoming SinsGotchasLearnings.md.kit-incoming
  ```
  Keeps your incidents first and verbatim, appends the kit's generic entries
  renumbered, skips duplicates. Then delete the `.kit-incoming`.
- **`RepoMapReadFirst.md.kit-incoming`** — do NOT take the kit's (it's an empty
  skeleton). Keep yours; delete the `.kit-incoming`; regenerate later.

The rest (`AGENTS.md`, `EXECUTION_PLAN.md`, `skills/grill-to-prd.md`, drifted
scripts/justfile/verify.ps1) — diff against yours, pull in the v6.5 sections, keep
your project-specific content, delete the `.kit-incoming`.

**Finish** (provisions the toolchain, rebuilds generated files, proves green):

```bash
mise install                  # just/uv/node/pnpm/ast-grep
just sins-sync                # rebuild ast-grep rules + index from your taxonomy
just map-sync                 # rebuild RepoMapReadFirst.md
just doctor                   # v6.5: prove every gate can execute
just verify-all               # must be green before you keep the branch
```

**Keep or roll back:** merge the `migrate-kit-*` branch, or roll back with
`git checkout -` + delete the branch, or restore from `.kit-backup-*/`.

---

## Path C — adopt the kit into a project built without it

`adopt_kit.py` **only adds files you don't already have** — it cannot overwrite
your source, configs, or anything else present. It git-inits if needed, installs
the gate hooks, and generates the repo map + sins index from your real code. It
does NOT fill your contracts — those get reverse-engineered from your code (the
script prints the agent prompt for that).

```bash
# 1. unpack v6.5 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.5.tar -C /tmp/
KIT=/tmp/suds-vibe-coding-kit-v6.5

# 2. from INSIDE your project — dry-run (changes nothing):
python "$KIT/adopt/adopt_kit.py" --kit "$KIT" --plan
#   launcher:  & "$KIT\adopt\adopt-kit.ps1" -Kit "$KIT"

# 3. apply (adds missing kit files, installs hooks, generates the map):
python "$KIT/adopt/adopt_kit.py" --kit "$KIT" --apply
#   launcher:  & "$KIT\adopt\adopt-kit.ps1" -Kit "$KIT" -Apply

# 4. provision + the contract-backfill prompt it printed → paste into your agent
mise install
# 5. baseline the gates against your existing code:
just verify
just verify-all
```

For anything the audit legitimately flags but you've decided is OK, put
`# ast-grep-ignore` (Python/CSS) or `// ast-grep-ignore` (TS/JS) on the line above
with a reason in the commit — don't weaken the rule.

---

## The finish line (all three paths)

```bash
just doctor          # every configured gate can actually execute on THIS machine
just verify-all      # lint/typecheck/test/verify-libs/verify-schema/audit-sins/dox-check
                      # + check-tasks/check-prompt-log/smoke → all green
```

Green `just verify-all` after a green `just doctor` = you're on v6.5 and the gates
are trustworthy (not silently skipping). If `doctor` is red, fix what it reports
first — a green `verify` on top of a red `doctor` means a gate is lying about what
it checked.

**Reversibility:** every path leaves you a rollback — `git reset --hard pre-v6.5`
(Path A), the `migrate-kit-*` branch + `.kit-backup-*/` (Path B), or your manual
backup (Path C). Nothing here is one-way.

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `just: command not found` | `just` not installed | `mise install` (or `winget install Casey.Just`) |
| `ast-grep: command not found` | the one new v6.5 prereq missing | `mise install`, or `pip install ast-grep-cli` |
| `doctor` red on a tool | that tool isn't on PATH but a stack is configured | install via `mise install`; doctor prints the exact fix |
| `audit-sins` skipped silently | ast-grep not on PATH | install it (see above); the gate will then run |
| `verify` red with `ERR_PNPM_NO_PKG_MANIFEST` on a `verify_*.ts` | JS stack not configured but a TS verify file exists | fixed in v6.5 (now skips cleanly); if you see it, your `run_gate.py` is pre-v6.5 — re-run Path A/B |
| `.kit-incoming` files left over | you didn't finish resolving them | walk them one at a time (Path B step "Resolve"); safe to delete once merged |
| migrator says "doesn't look like a kit folder" | `--kit` path has no `migrate/v4_baseline.sha256` | point `--kit` at the unpacked kit root, not a subfolder |

## The one rule for the agent

Do not auto-resolve MERGE / `.kit-incoming` files. Do not overwrite anything
outside what the migrator's `--apply` already did. Your job is to diff, explain,
recommend, and apply only on the user's confirmation — one file at a time.
