<#
.SYNOPSIS
    Migrate an ongoing v4/v5/v6.x project onto the current Sud's Vibe Coding Kit (v6.5) - safely.
.DESCRIPTION
    Run this from INSIDE your existing project folder, pointing -Kit at the unpacked
    kit. By default it only PRINTS THE PLAN (changes nothing). Add -Apply to execute
    (creates a git branch + backup first; never overwrites your state; stages
    judgment-call merges as .kit-incoming files).

    NOTE: for a v6.x → v6.5 upgrade the cleanest path is the manual swap described in
    migrate/MIGRATION.md (§"v6.4 → v6.5"). Use this migrator for v4/v5 projects (or when you
    want the full classify/backup safety).

    Step 1: unpack the kit tar somewhere OUTSIDE this project, e.g.
        tar -xf suds-vibe-coding-kit-v6.5.tar -C C:\temp\
    Step 2 (plan):   .\migrate\migrate-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.5
    Step 3 (apply):  .\migrate\migrate-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.5 -Apply
.PARAMETER Kit
    Path to the unpacked kit folder.
.PARAMETER Apply
    Execute the migration (default is plan-only).
.PARAMETER RemoveRetired
    Also delete superseded files (setup.sh, verification/audit_sins.*).
#>
param(
    [Parameter(Mandatory = $true)][string]$Kit,
    [switch]$Apply,
    [switch]$RemoveRetired
)
$ErrorActionPreference = "Stop"
# The project is wherever you're standing (your existing project), NOT where this
# launcher lives — the kit is typically unpacked elsewhere (e.g. C:\temp). Use the
# current directory. Run this from INSIDE your project.
$Project = (Get-Location).Path
$py = $null
foreach ($c in @('python','python3','py')) {
    $cmd = Get-Command $c -ErrorAction SilentlyContinue
    if ($cmd) { $py = $cmd; break }
}
if (-not $py) { Write-Host "[ERROR] Python not found in PATH." -ForegroundColor Red; exit 1 }

$script = Join-Path (Join-Path $Kit "migrate") "migrate_kit.py"
$argsList = @($script, "--kit", $Kit, "--project", $Project)
if ($Apply) { $argsList += "--apply" } else { $argsList += "--plan" }
if ($RemoveRetired) { $argsList += "--remove-retired" }

& $py.Source @argsList
