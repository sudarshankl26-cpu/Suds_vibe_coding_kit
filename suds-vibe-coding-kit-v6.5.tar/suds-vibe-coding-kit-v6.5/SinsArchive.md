# SinsArchive

Retired / superseded / stack-no-longer-used defect entries moved here by the
`skills/sins-triage.md` ritual (step 5: collapse and cap). This file exists so history is
never deleted — only moved out of the read path. It is **not** read at session start and
**not** scanned for ast-grep rules; entries here do not steer behavior. Search it only when
investigating why an old decision was made.

## Format

Keep each moved entry intact (its `## N. Title` heading, metadata, and body), prefixed with
a one-line reason for the move:

```
_Archived from SinsGotchasLearnings.md §NN on YYYY-MM-DD: <reason>._
## NN. Title
... original entry body ...
```

Reasons to archive (vs. delete — we never delete):
- **Superseded** — the lesson was promoted to a gate/type and the prose adds no retrieval value.
- **Obsolete stack** — e.g. a framework the project migrated off; the defect can't recur.
- **Generalized away** — a project-specific narrative was rewritten into a portable rule; the
  war-story original is kept here for context.

The §numbers are NOT renumbered when an entry moves here — gaps in `SinsGotchasLearnings.md`
are expected and fine.

---

<!-- Append archived entries below. Newest archive at the bottom. -->
