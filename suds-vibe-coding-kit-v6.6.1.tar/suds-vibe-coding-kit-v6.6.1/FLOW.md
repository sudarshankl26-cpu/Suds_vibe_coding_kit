# FLOW — [Project Name]

> **The information-flow contract.** PRD says *what and why*. DATA_MODEL says *what data exists*.
> DESIGN_GUIDELINES says *how it looks*. This file says **how the user moves**: which screens
> exist, in what order they're encountered, what question each one answers, and what happens in
> every state. It is a **contract** — same rules as PRD/DATA_MODEL: the agent never invents a
> screen, a route, or a navigation path that isn't here. If a build phase needs one, that's a
> FLOW.md change first (separate commit), then code.
>
> **Authoring order:** written AFTER `PRD.md` + `DATA_MODEL.md` (it binds to both), BEFORE
> `EXECUTION_PLAN.md` (phases slice along journeys, not along components). Produce it with
> `skills/grill-to-flow.md` — don't fill it by hand from imagination.
>
> **The one principle:** a screen is not a place, it's an **answer to a question**; a click is
> not navigation, it's a **narrowing of that question**. If you can't state a screen's question
> in one sentence, the screen shouldn't exist. Spec decisions, not pages.

---

## 1. Roles and their questions

Every role from PRD §3, with the questions they bring to the product. This table is the root of
the whole flow — every screen below must trace back to a cell here.

| Role | Top questions they need answered (ranked) | Frequency | Device / context |
|---|---|---|---|
| [e.g. Ops manager] | 1. "Is anything on fire right now?" 2. "What changed since yesterday?" 3. "Which unit is dragging the average?" | Daily, 9am | Desktop, 2 min glance |
| [e.g. Analyst] | 1. "Why did metric X move?" 2. "Can I export the underlying rows?" | Weekly, deep session | Desktop, 30+ min |

## 2. Journeys (the narrative spine)

One entry per journey. A journey = **trigger → path → decision/outcome**. Every PRD user story
must map to at least one journey; every journey must be walkable using only the screens and
edges defined in §3–§5. Rank them — J1 is the journey the whole layout optimizes for.

### J1 — [name, e.g. "Morning health check"]
- **Role:** [who] · **Trigger:** [what makes them open the app]
- **Path:** `S1 Overview` → *(sees anomaly tile)* → `S3 Metric Detail` → *(filters to region)* → `S5 Row Drilldown`
- **Decision at the end:** [the real-world action they take, e.g. "call the regional lead or close the tab"]
- **Success = ** [measurable: "reaches the decision in ≤ 90 seconds, ≤ 3 clicks"]

### J2 — [...]

> **The 90-second test (dashboards):** for the primary role's J1, list what they must know
> within 90 seconds of landing, before any click. That list IS the top of the home screen,
> in that order. Everything else is behind a zoom or a filter.

## 3. Screen inventory

Every screen/view/major modal in the product. Nothing renders that isn't in this table.

| ID | Screen | The question it answers (one sentence) | Primary role | Route | Entry points | Exit points |
|---|---|---|---|---|---|---|
| S1 | Overview | "Is anything abnormal across all [entities] right now?" | Ops manager | `/` | direct, login | S2, S3 |
| S2 | [...] | | | `/things/:id` | S1 tile click | S1 (back), S4 |

Rules:
- **Route column is mandatory** — every screen state worth returning to is deep-linkable
  (filters and selections encoded in URL params, so a link pasted in chat reproduces the view).
- **No dead ends:** every screen has ≥1 exit that isn't the browser back button.
- **≤ 3 clicks** from S1 to any screen a primary journey needs. If deeper, restructure.

## 4. Navigation model

The global skeleton, then the graph.

- **Persistent chrome:** [e.g. left sidebar with S1/S6/S9; top bar holds global filters + search]
- **Global vs contextual:** [which filters are global (persist across screens, live in URL) vs
  local (reset on leave)] — this is the #1 source of dashboard confusion; decide it here once.
- **Hierarchy pattern:** [pick and name it: overview → zoom+filter → detail-on-demand is the
  default for dashboards; wizard/stepper for setup flows; master-detail for records]

```mermaid
graph LR
  S1[S1 Overview] -->|click anomaly tile| S3[S3 Metric Detail]
  S1 -->|nav sidebar| S6[S6 Settings]
  S3 -->|click row| S5[S5 Drilldown]
  S5 -->|breadcrumb| S3
```

> Edges are labelled with the **gesture and the carried context** (what selection/filter travels
> across the edge). An unlabelled edge is an unresolved design decision.

## 5. Per-screen contracts

One block per screen. This is what the build agent actually renders from.

### S1 — [Overview]
- **Question answered:** [restate from §3]
- **Reading order (visual hierarchy):** 1) [status strip — the 90-second payload] 2) [trend
  block — "what changed"] 3) [ranked table — "who's dragging"]. The eye path IS the spec;
  the agent lays out top-left → bottom-right in this order.
- **Data bindings:** every number on screen names its source: `Entity.field` from DATA_MODEL +
  grain + aggregation (e.g. `Order.amount, daily sum, last 30d vs prior 30d`). **A binding to a
  field that doesn't exist in DATA_MODEL is a contract conflict — stop and reconcile, never
  invent the field.** *(tag invariant bindings `#EXPORT_CRITICAL`)*
- **Actions:** [each affordance → its effect + destination edge from §4]
- **States (all six, every screen — no exceptions):**
  - *Loading:* [skeleton matching final layout — never a spinner-only page]
  - *Empty (no data yet):* [what it says + the CTA that gets the user out of empty]
  - *Partial/degraded:* [some sources loaded, one failed — show what, flag what's missing]
  - *Error:* [message + retry affordance; never a blank screen]
  - *Nominal:* [the §"reading order" above]
  - *Permission-denied (if roles differ):* [hide vs disable vs explain — pick one policy]
- **Filters/controls:** [each control: options, **default value** (mandatory — an unfiltered
  default is a decision too), global-or-local per §4, URL param name]

### S2 — [...]

## 6. Interaction state machines (risk-flagged widgets)

For any stateful widget the grill risk-flagged (cross-filtering charts, multi-step forms,
optimistic edits, anything with undo): a small state table — states, events, transitions,
and what's disabled in each state. These get eval-first treatment (AGENTS.md §4a): the
transition table becomes tests before the widget is built.

| Widget | States | Events → transitions | Notes |
|---|---|---|---|
| [Date-range + compare toggle] | idle / pending / applied | apply → pending → applied; error → idle w/ toast | selections persist in URL |

## 7. Flow anti-goals

What the navigation deliberately does NOT do (same spirit as PRD §5 — this stops drift):

- [e.g. "No dashboard-builder / user-configurable layouts — layouts are fixed per role."]
- [e.g. "No modal-on-modal. Second-level detail is a route, not a nested dialog."]
- [e.g. "No horizontal tab sets inside a screen that already sits in the sidebar nav."]

## 8. Completeness gate (run before EXECUTION_PLAN.md is written)

- [ ] Every PRD §4 capability and user story maps to ≥1 journey in §2.
- [ ] Every journey walks only screens in §3 and edges in §4 — no phantom hops.
- [ ] Every screen answers exactly one question; none answer zero or three.
- [ ] Every data binding in §5 resolves to a real DATA_MODEL entity/field at a stated grain.
- [ ] All six states specced for every screen; every filter has a default.
- [ ] Every screen is deep-linkable and has a non-back exit; nothing is > 3 clicks from S1.
- [ ] The 90-second payload for the primary role is the literal top of S1.
- [ ] §7 anti-goals reviewed against the nav graph — no edge violates them.

Then slice EXECUTION_PLAN.md **vertically along journeys** (J1 end-to-end with real data first,
including its states), not horizontally along component types.
