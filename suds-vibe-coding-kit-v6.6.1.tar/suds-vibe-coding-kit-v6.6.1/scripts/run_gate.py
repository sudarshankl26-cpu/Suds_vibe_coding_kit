#!/usr/bin/env python3
"""
run_gate.py — cross-platform runner for the toolchain gates (lint/typecheck/test/fmt/
verify-libs/smoke/doctor). Replaces the bash-shebang justfile recipes so `just` works
identically on native Windows PowerShell, Git Bash, and WSL — no cygpath, no bash required.

Each gate is "configured-aware": it only runs a tool if that tool's config/manifest is
present (pyproject.toml → ruff/mypy/pytest; package.json/tsconfig.json → eslint/tsc/vitest).

v6.5 policy — NO SILENT FALSE-GREENS (SinsGotchasLearnings §33 / ex-§85):
  * NOT configured  → skipped cleanly (a Python-only repo owes no eslint run).
  * Configured but the LAUNCHER/tool is missing → the gate FAILS (exit 3) with the exact
    setup command to run. A gate that prints "skipping" and returns green is worse than
    no gate — that is precisely how a whole harness silently no-op'd for an entire phase.
    Set KIT_GATES_LENIENT=1 to demote these to warnings on a deliberately bare machine
    (e.g. docs-only session); the summary still prints what was NOT checked.
  * The JS package manager is DETECTED from the lockfile (pnpm-lock.yaml / package-lock.json
    / yarn.lock / bun.lockb) — never hardcoded. A pnpm-flavored kit on an npm project was
    the root cause of an all-gates-skip incident.
  * Launchers are resolved via shutil.which() and invoked by absolute path, so Windows
    `.cmd`/`.exe` shims resolve identically under PowerShell, Git Bash, and WSL.
  * Every gate ends with a one-line accounting: ran / skipped(unconfigured) / MISSING.

Usage:
    python scripts/run_gate.py <gate>
    gate ∈ {lint, typecheck, test, fmt, verify-libs, smoke, doctor}
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

LENIENT = os.environ.get("KIT_GATES_LENIENT") == "1"

if LENIENT:
    # A one-time loud banner per process. KIT_GATES_LENIENT is a footgun: if it's set in a
    # shell profile to quiet one transient noise, every subsequent missing tool becomes a
    # silent false-green — the exact v6.5 failure mode (SinsGotchasLearnings §33). Making it
    # loud every run keeps it visible so it doesn't get left on by accident.
    print("=" * 68)
    print("KIT_GATES_LENIENT=1 is set — configured-but-missing tools are WARNINGS, not")
    print("failures. A green run under LENIENT is NOT proof the gates ran. Use this only for")
    print("a deliberately bare machine (e.g. a docs-only session); unset it for real builds.")
    print("=" * 68)

# Accounting for the end-of-gate summary line.
RAN: list[str] = []
UNCONFIGURED: list[str] = []
MISSING: list[str] = []  # configured but tool absent — red unless KIT_GATES_LENIENT=1


def which(name: str) -> str | None:
    """shutil.which, so Windows resolves foo.cmd/foo.exe the same as POSIX foo."""
    return shutil.which(name)


def find_ast_grep() -> str | None:
    """Locate ast-grep, verifying identity (Linux `sg` can be the unrelated setgroups util).

    Single source of truth for ast-grep detection — used by `doctor` here AND by
    scripts/sins.py's `audit`, so the two can never disagree about whether the tool exists
    (the disagreement is how a false-green sneaks back in).
    """
    for name in ("ast-grep", "sg"):
        path = which(name)
        if path:
            try:
                r = subprocess.run([path, "--version"], capture_output=True, text=True,
                                   timeout=15)
                if "ast-grep" in (r.stdout + r.stderr).lower():
                    return path
            except (OSError, subprocess.TimeoutExpired):
                pass
    return None


# --------------------------------------------------------------------------- JS runner
def js_runner() -> tuple[list[str], list[str], str]:
    """(exec_prefix, run_prefix, name) for the package manager this repo actually uses.

    Detection order: lockfile (the truth) → installed fallback. Never assume pnpm.
    """
    if Path("pnpm-lock.yaml").exists():
        return ["pnpm", "exec"], ["pnpm", "run"], "pnpm"
    if Path("package-lock.json").exists():
        return ["npx", "--no-install"], ["npm", "run"], "npm"
    if Path("yarn.lock").exists():
        return ["yarn"], ["yarn", "run"], "yarn"
    if Path("bun.lockb").exists() or Path("bun.lock").exists():
        return ["bunx"], ["bun", "run"], "bun"
    # No lockfile yet (fresh project): prefer pnpm (kit convention), else whatever exists.
    for pm, ex, rn in (("pnpm", ["pnpm", "exec"], ["pnpm", "run"]),
                       ("npm", ["npx", "--no-install"], ["npm", "run"]),
                       ("yarn", ["yarn"], ["yarn", "run"]),
                       ("bun", ["bunx"], ["bun", "run"])):
        if which(pm):
            return ex, rn, pm
    return ["pnpm", "exec"], ["pnpm", "run"], "pnpm"


def missing_tool(label: str, tool: str, hint: str) -> int:
    """Configured stack, absent tool. Loud red (or loud yellow under LENIENT)."""
    MISSING.append(label)
    print(f"  !! {label}: `{tool}` is not available, but this stack is CONFIGURED to use it.")
    print(f"     This gate is NOT checking anything. Fix: {hint}")
    if LENIENT:
        print("     (KIT_GATES_LENIENT=1 — recorded as a warning, not a failure)")
        return 0
    return 3


def run(label: str, args: list[str], hint: str = "just setup") -> int:
    """Run a command, streaming output. Missing launcher = missing_tool(), not a skip."""
    print(f"» {label}")
    launcher = which(args[0])
    if launcher is None:
        return missing_tool(label, args[0], hint)
    try:
        proc = subprocess.run([launcher] + args[1:], capture_output=True, text=True)
    except (FileNotFoundError, OSError):
        return missing_tool(label, args[0], hint)
    out = (proc.stdout or "") + (proc.stderr or "")
    # `uv run X` / `pnpm exec X` / `npx X` where the SUB-tool isn't installed: the runner
    # spawned but couldn't find X. Also a setup gap → red, with the exact fix. We only
    # match the runner's own spawn-error phrasing, so a test that PRINTS "not found"
    # still fails as a normal test failure.
    subtool = None
    if len(args) > 1 and args[0] in ("uv", "pnpm", "yarn", "bun"):
        subtool = args[2] if args[0] in ("uv", "pnpm") and len(args) > 2 else args[1]
    elif args[0] in ("npx", "bunx"):
        subtool = args[2] if args[1].startswith("--") and len(args) > 2 else args[1]
    spawn_failed = bool(
        subtool
        and proc.returncode != 0
        and (
            f"Failed to spawn: `{subtool}`" in out
            or f"Failed to spawn: {subtool}" in out
            or f"{subtool}: command not found" in out
            or "could not determine executable to run" in out
            or "canceled due to missing packages" in out
            or ("No such file or directory (os error 2)" in out and "Failed to spawn" in out)
        )
    )
    if spawn_failed:
        return missing_tool(label, subtool or args[0], hint)
    if out.strip():
        sys.stdout.write(out if out.endswith("\n") else out + "\n")
    RAN.append(label)
    return proc.returncode


def skip_unconfigured(label: str, why: str) -> None:
    UNCONFIGURED.append(label)
    print(f"» {label}: {why} — skipped (not configured)")


def summary(*codes: int) -> int:
    parts = []
    if RAN:
        parts.append(f"ran: {', '.join(RAN)}")
    if UNCONFIGURED:
        parts.append(f"unconfigured: {', '.join(UNCONFIGURED)}")
    if MISSING:
        parts.append(f"MISSING TOOLS (not checked!): {', '.join(MISSING)}")
    print(f"  [{' | '.join(parts) if parts else 'nothing to do'}]")
    if MISSING and not LENIENT:
        return 3
    for c in codes:
        if c != 0:
            return c
    return 0


# --------------------------------------------------------------------------- gates
def gate_lint() -> int:
    codes = []
    if Path("pyproject.toml").exists():
        codes.append(run("ruff", ["uv", "run", "ruff", "check", "."], "uv sync"))
    if Path("package.json").exists():
        ex, _, pm = js_runner()
        # eslint v9 needs a flat config; without any config, running it is guaranteed noise.
        has_cfg = any(Path(p).exists() for p in (
            "eslint.config.js", "eslint.config.mjs", "eslint.config.cjs", "eslint.config.ts",
            ".eslintrc", ".eslintrc.js", ".eslintrc.cjs", ".eslintrc.json", ".eslintrc.yml"))
        if has_cfg:
            codes.append(run("eslint", ex + ["eslint", "."], f"{pm} install"))
        else:
            skip_unconfigured("eslint", "no eslint config file")
    return summary(*codes)


def gate_typecheck() -> int:
    codes = []
    py_target = "src" if Path("src").is_dir() else "."
    if Path("pyproject.toml").exists():
        codes.append(run("mypy", ["uv", "run", "mypy", py_target], "uv sync"))
    if Path("tsconfig.json").exists():
        ex, _, pm = js_runner()
        codes.append(run("tsc", ex + ["tsc", "--noEmit"], f"{pm} install"))
    return summary(*codes)


def gate_test() -> int:
    codes = []
    if Path("pyproject.toml").exists():
        rc = run("pytest", ["uv", "run", "pytest", "-q"], "uv sync")
        codes.append(0 if rc == 5 else rc)  # exit 5 = no tests collected (fresh project)
    if Path("package.json").exists():
        ex, _, pm = js_runner()
        deps = _pkg_all_deps()
        if "vitest" in deps:
            codes.append(run("vitest", ex + ["vitest", "run", "--passWithNoTests"],
                             f"{pm} install"))
        else:
            skip_unconfigured("vitest", "not in package.json dependencies")
    return summary(*codes)


def gate_fmt() -> int:
    codes = []
    if Path("pyproject.toml").exists():
        codes.append(run("ruff format", ["uv", "run", "ruff", "format", "."], "uv sync"))
    if Path("package.json").exists():
        ex, _, pm = js_runner()
        if "prettier" in _pkg_all_deps():
            codes.append(run("prettier", ex + ["prettier", "--write", "."], f"{pm} install"))
        else:
            skip_unconfigured("prettier", "not in package.json dependencies")
    return summary(*codes)


def _pkg_all_deps() -> dict:
    try:
        pkg = json.loads(Path("package.json").read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}
    return {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}


def gate_verify_libs() -> int:
    """Run every verification/verify_*.py and verify_*.ts — proves library APIs.

    A verify_*.py whose TARGET library isn't installed is SKIPPED (nothing to verify on
    this machine). A script that imports fine but whose ASSERTIONS fail (real API drift)
    fails the gate — that's the whole point of the protocol.
    """
    codes = []
    vdir = Path("verification")
    if not vdir.is_dir():
        print("library checks done (no verification/ dir)")
        return 0
    py_files = sorted(vdir.glob("verify_*.py"))
    ts_files = sorted(vdir.glob("verify_*.ts"))
    if py_files and which("uv") is None:
        codes.append(missing_tool("verify-libs(py)", "uv", "install mise/uv, then uv sync"))
        py_files = []
    for f in py_files:
        print(f"» {f}")
        r = subprocess.run([which("uv"), "run", "python", str(f)],
                           capture_output=True, text=True)
        if r.returncode == 0:
            RAN.append(f.name)
            if r.stdout.strip():
                print("  " + r.stdout.strip().replace("\n", "\n  "))
            continue
        if "ModuleNotFoundError" in r.stderr or "No module named" in r.stderr:
            skip_unconfigured(f.name, "target library not installed")
            continue
        print("  " + (r.stderr.strip() or r.stdout.strip()).replace("\n", "\n  "))
        codes.append(r.returncode)
    if ts_files:
        if not Path("package.json").exists():
            # No JS project configured — a verify_*.ts can't run here. Skip cleanly,
            # symmetric with the Python "target library not installed" skip above;
            # otherwise pnpm/npm auto-install fails with ERR_*_NO_PKG_MANIFEST and
            # turns `just verify` red for an unrelated reason in a Python-only repo.
            for f in ts_files:
                skip_unconfigured(f.name, "no package.json (JS stack not configured)")
        else:
            ex, _, pm = js_runner()
            for f in ts_files:
                codes.append(run(f.name, ex + ["tsx", str(f)], f"{pm} install"))
    print("library checks done")
    return summary(*codes)


def gate_smoke() -> int:
    """Actually run & observe the app (AGENTS.md §3): package.json `smoke` script if present."""
    pkg = Path("package.json")
    if pkg.exists():
        try:
            scripts = json.loads(pkg.read_text(encoding="utf-8")).get("scripts", {})
        except (ValueError, OSError):
            scripts = {}
        if "smoke" in scripts:
            _, rn, pm = js_runner()
            code = run("smoke", rn + ["smoke"], f"{pm} install")
            return summary(code)
    print("» smoke: no `smoke` script configured — skipping (add one to actually run the app; "
          "see skills/templates/smoke.spec.ts.template)")
    return 0


def gate_doctor() -> int:
    """Harness self-test: prove every CONFIGURED gate can actually execute on THIS machine.

    Run after scaffold, after cloning to a new machine, or whenever gate output looks
    suspicious. A green doctor means a green `just verify` is trustworthy; a red doctor
    means some gates are lying (or would lie) about what they checked.
    """
    problems = 0

    def check(name: str, ok: bool, detail: str) -> None:
        nonlocal problems
        print(f"  {'OK ' if ok else 'X  '}{name:<28} {detail}")
        if not ok:
            problems += 1

    print("» doctor — can every configured gate actually run?")
    check("just", which("just") is not None, which("just") or "NOT FOUND — mise install")
    check("git", which("git") is not None, which("git") or "NOT FOUND")
    ag = find_ast_grep()
    check("ast-grep (audit-sins)", ag is not None, ag or "NOT FOUND — mise install")
    if Path("pyproject.toml").exists():
        uv = which("uv")
        check("uv (python stack)", uv is not None, uv or "NOT FOUND — install mise/uv")
        if uv:
            for tool in ("ruff", "mypy", "pytest"):
                r = subprocess.run([uv, "run", tool, "--version"],
                                   capture_output=True, text=True)
                check(f"uv run {tool}", r.returncode == 0,
                      (r.stdout or r.stderr).strip().splitlines()[0][:60]
                      if (r.stdout or r.stderr).strip() else "no output")
    if Path("package.json").exists():
        ex, _, pm = js_runner()
        pm_path = which(ex[0])
        lock = next((p for p in ("pnpm-lock.yaml", "package-lock.json", "yarn.lock",
                                 "bun.lockb") if Path(p).exists()), "no lockfile")
        check(f"{pm} (js stack, via {lock})", pm_path is not None,
              pm_path or f"NOT FOUND — install {pm}")
        check("node_modules", Path("node_modules").is_dir(),
              "present" if Path("node_modules").is_dir() else f"missing — {pm} install")
        if pm_path and Path("node_modules").is_dir():
            deps = _pkg_all_deps()
            for tool, needed in (("tsc", Path("tsconfig.json").exists()),
                                 ("vitest", "vitest" in deps),
                                 ("tsx", any(Path("verification").glob("verify_*.ts"))
                                  if Path("verification").is_dir() else False)):
                if not needed:
                    continue
                r = subprocess.run([pm_path] + ex[1:] + [tool, "--version"],
                                   capture_output=True, text=True)
                check(f"{' '.join(ex)} {tool}", r.returncode == 0,
                      (r.stdout or r.stderr).strip().splitlines()[0][:60]
                      if (r.stdout or r.stderr).strip() else "spawn failed")
    hooks = Path(".git/hooks/pre-commit")
    check("pre-commit hook", hooks.exists(), str(hooks) if hooks.exists()
          else "missing — re-run scaffold or `just setup`")
    if problems:
        print(f"  DOCTOR: {problems} problem(s). Gates referencing these tools are NOT "
              "protecting you until fixed.")
        return 3
    print("  DOCTOR: all configured gates can execute. A green verify is trustworthy.")
    return 0


GATES = {
    "lint": gate_lint,
    "typecheck": gate_typecheck,
    "test": gate_test,
    "fmt": gate_fmt,
    "verify-libs": gate_verify_libs,
    "smoke": gate_smoke,
    "doctor": gate_doctor,
}


def main() -> None:
    if len(sys.argv) != 2 or sys.argv[1] not in GATES:
        print(f"usage: python scripts/run_gate.py {{{'|'.join(GATES)}}}")
        sys.exit(2)
    sys.exit(GATES[sys.argv[1]]())


if __name__ == "__main__":
    main()
