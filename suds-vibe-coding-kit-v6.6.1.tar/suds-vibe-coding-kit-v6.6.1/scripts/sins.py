#!/usr/bin/env python3
"""
sins.py — sins-sync / audit-sins for v6.1 (ast-grep based; no bash, no dual codegen).

  sync   regenerate rules/ (ast-grep rule files) + SinsGotchasLearnings_INDEX.md from
         SinsGotchasLearnings.md.
  audit  run `ast-grep scan` over the project. If rules/ is STALE vs SinsGotchasLearnings.md,
         it auto-regenerates first (idempotent) and prints a note — so a captured learning is
         always enforced, with NO "STALE AUDIT, go run sins-sync, re-verify" loop (the v6
         friction). A rule with `severity: error` fails the gate; warning/info are notes.
         If rules exist but ast-grep is absent, the audit FAILS loud (exit 3) with the
         install fix — run_gate.py's v6.5 no-silent-false-green policy, same LENIENT escape.

Usage:
    python scripts/sins.py sync
    python scripts/sins.py audit
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
except (AttributeError, ValueError):
    pass

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import extract_audits  # noqa: E402  (local helper; shares the staleness logic)
import run_gate  # noqa: E402  (shares find_ast_grep + the missing_tool red/LENIENT policy)


def py() -> str:
    return sys.executable or "python"


def regenerate() -> int:
    """Regenerate rules/ + index from the taxonomy."""
    if not Path("SinsGotchasLearnings.md").exists():
        print("no SinsGotchasLearnings.md — skipping")
        return 0
    extract_audits.main()
    idx = Path("SinsGotchasLearnings_INDEX.md")
    with idx.open("w", encoding="utf-8") as fh:
        r = subprocess.run(
            [py(), str(HERE / "build_sins_index.py"), "SinsGotchasLearnings.md"], stdout=fh
        )
    if r.returncode != 0:
        return r.returncode
    print("» regenerated rules/ + SinsGotchasLearnings_INDEX.md")
    return 0


def sync() -> int:
    return regenerate()


def audit() -> int:
    if not Path("SinsGotchasLearnings.md").exists():
        print("» no SinsGotchasLearnings.md — sins audit skipped")
        return 0
    # Self-healing: keep the generated rules current with the taxonomy, no manual sync needed.
    if extract_audits.is_stale():
        print("  i rules/ was stale vs SinsGotchasLearnings.md — regenerating before scan")
        if regenerate() != 0:
            return 1

    if not Path("rules").exists() or not any(Path("rules").glob("*.yml")):
        print("» no ast-grep rules to run (add `### Audit Rule` blocks to SinsGotchasLearnings.md)")
        return 0

    sg = run_gate.find_ast_grep()
    if sg is None:
        # v6.6.1: same NO-SILENT-FALSE-GREEN policy as every run_gate.py gate. Rules exist
        # (the taxonomy is CONFIGURED to be enforced) but the tool is absent → loud red,
        # exit 3, with the exact fix — never "skipped (non-fatal)" + green.
        # KIT_GATES_LENIENT=1 demotes to a warning, identical to the other gates.
        return run_gate.missing_tool(
            "audit-sins", "ast-grep",
            "`mise install` (it's in .mise.toml), or `npm i -g @ast-grep/cli` / "
            "`cargo install ast-grep` / `brew install ast-grep`")

    print(f"» sins audit (ast-grep scan via '{sg}')")
    # `ast-grep scan` reads sgconfig.yml, applies rules/, and exits non-zero on error-severity
    # findings. Suppress a single approved line with a `# ast-grep-ignore` comment above it.
    return subprocess.run([sg, "scan"]).returncode


def triage() -> int:
    """v6.5: print the health of the learning loop and what the sins-triage skill should
    work on. Purely informational — never fails. Run every ~10 new entries or at the end
    of a phase, then run the `skills/sins-triage.md` ritual on the findings."""
    src = Path("SinsGotchasLearnings.md")
    if not src.exists():
        print("no SinsGotchasLearnings.md — nothing to triage")
        return 0
    import re as _re

    import build_sins_index as bsi  # local helper; shares the entry parser
    raw = _re.split(r"\n(?=## \d+\. )", src.read_text(encoding="utf-8").replace("\r\n", "\n").replace("\r", "\n"))
    entries = [x for x in (bsi.parse_entry(e) for e in raw) if x]
    size_kb = src.stat().st_size / 1024
    enforced = [x for x in entries if x["enforced"]]
    digest = [x for x in entries if x["digest"]]
    bare = [x for x in entries if not x["triggers"] and not x["enforced"]]
    promote = [x for x in entries if x["recur"] >= 2 and not x["enforced"]]
    project = [x for x in entries if x["scope"] == "project"]

    print(f"» sins triage report — {len(entries)} entries, {size_kb:.0f} KB")
    print(f"  enforced (rule/test/type): {len(enforced)}  |  digest(★): {len(digest)}  |  "
          f"project-scoped: {len(project)}")
    if promote:
        print(f"  ⚠ PROMOTE NOW ({len(promote)}): recurred ≥2× while still prose — prose has "
              "failed for these; write the rule/test/type or mark Digest: yes:")
        for x in promote:
            print(f"     §{x['num']} {x['title']} (🔁×{x['recur']})")
    if bare:
        print(f"  i {len(bare)} prose entries have no Trigger: metadata — they can never be "
              "retrieved at the point of action. Fix first:")
        for x in bare[:10]:
            print(f"     §{x['num']} {x['title']}")
    if len(digest) > bsi.DIGEST_SOFT_CAP:
        print(f"  ⚠ digest over budget: {len(digest)} > {bsi.DIGEST_SOFT_CAP} — demote or "
              "promote-to-gate the excess (attention is the scarce resource).")
    if size_kb > 60:
        print(f"  ⚠ file is {size_kb:.0f} KB — run the sins-triage skill: merge duplicates, "
              "generalize project-scoped narratives, archive superseded entries.")
    if not (promote or bare or len(digest) > bsi.DIGEST_SOFT_CAP or size_kb > 60):
        print("  OK: learning loop healthy.")
    print("  Ritual: skills/sins-triage.md (merge → generalize → promote → collapse).")
    return 0


def main() -> None:
    cmd = sys.argv[1] if len(sys.argv) == 2 else ""
    if cmd == "sync":
        sys.exit(sync())
    elif cmd == "audit":
        sys.exit(audit())
    elif cmd == "triage":
        sys.exit(triage())
    else:
        print("usage: python scripts/sins.py {sync|audit|triage}")
        sys.exit(2)


if __name__ == "__main__":
    main()
