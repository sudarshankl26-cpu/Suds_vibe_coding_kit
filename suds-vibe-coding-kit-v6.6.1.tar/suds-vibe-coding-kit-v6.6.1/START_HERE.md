# START HERE — Sud's Vibe Coding Kit v6.6.1

> **Addendum (2026-07): the information-flow layer.** Three additions close the "agent invents
> the UX" gap: a `FLOW.md` contract (screens as questions, journeys, nav graph, per-screen
> states + data bindings), `skills/grill-to-flow.md` (a second one-question-at-a-time interview,
> run after PRD + DATA_MODEL on any UI project), and
> `skills/templates/flow-simulator.html.template` (a static greybox harness — the agent emits
> only a small FLOW_SPEC JSON, you click through screens/journeys/states and export feedback).
> Authoring order for UI projects is now PRD → GLOSSARY → DATA_MODEL → **FLOW** → ARCHITECTURE
> → EXECUTION_PLAN, and UI phases slice along FLOW journeys.
>
> **New in v6.6:** engineering discipline distilled from Matt Pocock's skills library
> (v1.1.0), kept solo-lean: test-quality anti-patterns (implementation-coupled, tautological,
> horizontal slicing — `AGENTS.md` §2) and seams-first eval-first (§4a); a feedback-loop
> debugging discipline (`skills/diagnose-bugs.md`, §6a rung 0); vertical-slice phasing +
> expand→migrate→contract for wide refactors and a hand-off-before-you-degrade context rule
> (§4b); a two-axis phase-end review (`skills/code-review.md`); deep-module design vocabulary
> with the deletion test (`skills/deep-modules.md`); and prototype-to-answer detours in the
> grill (`skills/prototype-to-answer.md`). No new gates — see the Field Guide's "What's new
> in v6.6".
>
> **New in v6.5:** trustworthy gates that can't silently false-green (`run_gate.py` fails
> loudly on a configured-but-missing tool; `just doctor` self-tests the harness), docs that
> can't rot silently (`dox-check` fails on wholesale-stale contract path refs + `[fill in]`
> placeholders once the repo has real source), and a learning loop with a motor (sins
> metadata + ★ALWAYS block + trigger map + recurrence ratchet + `just sins-triage`). Plus
> §4b subagent economics (context firewall, handoff packets, routing floor). Stays
> prose-and-suggestions over enforcement — see the Field Guide's "What's new in v6.5".
>
> **New in v6.4:** inline flags `#EXPORT_CRITICAL` / `#PLAN_UNCERTAINTY` / `#PATH_DECISION`
> (`AGENTS.md` §1a), a §2 *reuse-before-reinvent* anti-pattern, a built-in anti-AI-slop
> `DESIGN_GUIDELINES.md` (+ copy-paste build prompt `PROMPTS.md` §Q), a beginner "Start here"
> onboarding, and OpenAI Codex support (`.codex/`). All prose-only — no new gates or machinery.
>
> **New in v6.3:** tuned for 1M-context open-weight models. Adds `AGENTS.md` §4b *phased
> planning* (dated `plans/` files, ~300k tokens/phase, subagent delegation), a new
> `MODEL_NOTES.md` (per-model tips for GLM 5.2 / DeepSeek V4 Pro / MiniMax M3 / MiMo 2.5 Pro), an
> English/UTF-8 output rule, and a reordered §6a ladder. All additive — upgrading just refreshes
> `AGENTS.md` (+ the new files).
>
> **New in v6.2:** two suggestions added to `AGENTS.md` — §4a *eval-first for hard parts* and
> §6a the *anti-thrash escalation ladder*. Purely additive (no infra change). Details in the
> Field Guide's "What's new" sections.

This one tar does three jobs. Which path you take depends on the folder you're pointing at.

- **Empty folder -> new project ->** use `scaffold.ps1` (Path A)
- **Already on any older kit -> upgrade to v6.6.1 ->** drop the kit in `.kit-incoming/`, tell your agent "upgrade the kit" (`migrate/UPGRADE_AUTOPILOT.md` — zero steering); manual paths in `migrate/MIGRATION.md`
- **On v4/v5/early-v6 -> upgrade to v6.6.1 ->** use `migrate/` (Path B, the classify/backup migrator)
- **Existing project built WITHOUT the kit -> adopt ->** use `adopt/` (Path C)

> All three upgrade/adopt paths are documented end-to-end in one place:
> **[`migrate/MIGRATION.md`](migrate/MIGRATION.md)** (decision table + copy-paste
> commands + troubleshooting). `ADOPT_AND_UPGRADE.md` is now a thin pointer to it.

You never need two downloads. The `migrate/` folder is upgrade-only; when you scaffold a
new project it is stripped automatically, so new projects stay clean.

**One-time prerequisite (install once, ever, on your machine):**
[`mise`](https://mise.jdx.dev/installing-mise.html) — on Windows `winget install jdx.mise`,
in WSL `curl https://mise.run | sh`. It installs `just`/`uv`/`node`/`pnpm` for you so the
agent never has to. This is what fixed the old setup loops.

---

## Path A — New project

Your existing workflow. v5 only made it reliable.

1. Make a new folder. Rename it to your project name.
2. Extract the kit files **into it directly** — no sub-folder. This folder IS the project root.
3. Double-click **`scaffold.ps1`** (or in WSL: `bash scaffold.sh`). Runs once, in place:
   installs the toolchain, inits git + the verification hooks, makes the first commit, and
   prints your next prompt. Safe to run twice.
4. Open your coding agent in this folder and paste the grill prompt it printed:
   > Read CONTEXT.md and the files it lists. Then run the grill-to-prd skill
   > (skills/grill-to-prd.md): interview me ONE question at a time until the design is
   > fully resolved, recommending an answer for each. Do NOT write code or scaffold
   > anything yet — only interview, then produce PRD.md when done.
5. Answer the grill (it ends by asking your dev port — accept the random recommendation or
   pick your own). It writes `PRD.md`, then the rest of the contracts, then builds phase by
   phase. The final phase generates `start-server.ps1` / `stop-server.ps1` (or the
   `start-server.sh` / `stop-server.sh` pair on macOS/Linux — both template pairs ship in
   `skills/templates/`).
   **UI project?** After the PRD grill (and DATA_MODEL), run the flow grill before any build:
   > Run the grill-to-flow skill (skills/grill-to-flow.md): interview me one question at a
   > time about screens, journeys, and states; use the flow simulator for visual rounds;
   > produce FLOW.md when the flow is signed off.

That's it. Full detail: `README.md` and `VibeCodingKit_FieldGuide_v6.6.md`.

---

## Path B — Upgrade an existing v4/v5/early-v6 kit project to v6.6.1

**Already on v6.4?** Use `migrate/MIGRATION.md` Path A (a lighter manual swap of ~12 infra
files, no classification step). The migrator below is for v4/v5/early-v6 — or any time you
want the full backup + branch safety net.

**Do NOT extract the tar on top of your project** — that would overwrite your work. Extract
it elsewhere and point the migrator at your project. The migrator never touches your state
(contracts, incidents, logs, `src/`, `.env`); it only auto-replaces kit files that are still
byte-identical to stock v4. Anything your agent edited (or any v5/v6 infra) is staged for
review, not overwritten. It makes a git branch + a backup before changing anything, and is
fully reversible.

```bash
# 1. Unpack v6.6.1 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.6.1.tar -C /tmp/

# 2. From INSIDE your existing project — see the plan (changes nothing):
python /tmp/suds-vibe-coding-kit-v6.6.1/migrate/migrate_kit.py --kit /tmp/suds-vibe-coding-kit-v6.6 --plan

# 3. Apply (creates a git branch + backup first; stages judgment-call merges as *.kit-incoming):
python /tmp/suds-vibe-coding-kit-v6.6.1/migrate/migrate_kit.py --kit /tmp/suds-vibe-coding-kit-v6.6 --apply
```

Windows without WSL — use the launcher instead of calling Python directly:
```powershell
# from inside your project; add -Apply for step 3
C:\temp\suds-vibe-coding-kit-v6.6.1\migrate\migrate-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.6
```

After `--apply`, the safe changes are done and the judgment-call files sit next to yours as
`*.kit-incoming`. Hand it to your agent:

> Read `migrate/MIGRATION.md` and walk me through each `*.kit-incoming` file one at a time —
> show the diff, tell me what the kit changed, recommend an action, and apply only when I confirm.

For `SinsGotchasLearnings.md.kit-incoming` the agent runs the automated merge
(`migrate/merge_sins.py`) — it keeps your real incidents first and appends the kit's generic
ones renumbered, skipping duplicates. Then install the new toolchain and prove green:

```bash
mise install        # provisions just/uv/node/pnpm + ast-grep (the one v6.5+ prereq)
just sins-sync      # rebuild the ast-grep rules from your taxonomy
just verify-all     # audit-sins self-heals; everything must be green
```

Review the git diff. Keep it by merging the `migrate-kit-*` branch, or roll back via
`git checkout -` (and delete the branch) or by restoring the `.kit-backup-*/` folder.

Full detail: `migrate/MIGRATION.md` (and `ADOPT_AND_UPGRADE.md` for the PowerShell walkthrough).

---

## Path C - Adopt the kit into an existing NON-kit project

For a project you built without the kit and want to retrofit. Like migrate, you run a
script from inside your project pointing at the unpacked kit; it copies in the kit
machinery WITHOUT overwriting any file you already have, installs the gate hooks, and
generates the repo map. It does NOT fill your contracts (PRD/GLOSSARY/etc) - those
describe your project and get reverse-engineered from your code (the script prints the
agent prompt for that).

```bash
# 1. Unpack v6.6.1 OUTSIDE your project
tar -xf suds-vibe-coding-kit-v6.6.1.tar -C /tmp/
# 2. From INSIDE your existing project - see the plan (changes nothing):
python /tmp/suds-vibe-coding-kit-v6.6.1/adopt/adopt_kit.py --kit /tmp/suds-vibe-coding-kit-v6.6 --plan
# 3. Apply (adds missing kit files, installs hooks, generates the map):
python /tmp/suds-vibe-coding-kit-v6.6.1/adopt/adopt_kit.py --kit /tmp/suds-vibe-coding-kit-v6.6 --apply
```

Windows without WSL: `C:\temp\suds-vibe-coding-kit-v6.6.1\adopt\adopt-kit.ps1 -Kit C:\temp\suds-vibe-coding-kit-v6.6` (add `-Apply`).

After applying, run `mise install` (gets `ast-grep`), then paste the contract-backfill prompt
it printed into your agent (it drafts GLOSSARY/DATA_MODEL/ARCHITECTURE/PRD from your real code
for you to correct). Then `just verify` and triage what the audit flags in your existing code.
Full PowerShell walkthrough: `ADOPT_AND_UPGRADE.md`.

---

## The decision in one line

**Empty folder -> `scaffold`. Existing v4/v5 kit project -> `migrate`. Existing non-kit project -> `adopt`.**
