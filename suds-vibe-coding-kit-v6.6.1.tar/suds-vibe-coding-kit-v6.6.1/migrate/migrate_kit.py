#!/usr/bin/env python3
"""
migrate_kit.py — safely migrate an ongoing v4/v5/v6.x project onto the current Sud's Vibe
Coding Kit (v6.6.1).

Design principle: a migration must NEVER overwrite your accumulated project state, and
must NEVER blindly trust that kit-infrastructure files are stock (your coding agent may
have edited them). So every file is CLASSIFIED, not assumed:

  PRESERVE      — your state. Never touched. (STATE.md, logs, PRD/GLOSSARY/DATA_MODEL/
                  ARCHITECTURE, .env, src/, docs/adr/*, types/* you filled, fixtures…)
  OVERWRITE     — pure kit infrastructure that is byte-identical to a *stock prior kit
                  version* in your repo (verified by hash against every
                  migrate/<version>_baseline.sha256 the kit ships — v4, v6.4, …). Safe to
                  replace silently. The agent's upgrade skill (skills/upgrade-kit.md)
                  routes OVERWRITE/ADD/RETIRE automatically.
  ADD           — new in this kit, absent in your repo. Copied in.
  MERGE         — needs judgment: either the kit changed it AND you (or your agent) may
                  have too, or it carries content that must be combined
                  (SinsGotchasLearnings.md). The migrator does NOT auto-resolve these. It
                  writes the kit version next to yours as `<file>.kit-incoming` and lists
                  it for the agent to merge (3-way: your backup copy + the kit-incoming +
                  the current file — see skills/upgrade-kit.md).
  SKIP-DRIFTED  — infrastructure the kit would overwrite, BUT your copy matches no known
                  stock baseline (you or your agent edited it, or you're on a version this
                  kit has no baseline for). Treated as MERGE to be safe: the kit version
                  lands as `.kit-incoming`.

Nothing is applied in place without a git branch + a full backup first. Idempotent:
re-running detects already-migrated files and no-ops.

Usage:
    python migrate/migrate_kit.py --kit <path-to-unpacked-kit> [--plan|--apply]
        --plan   (default) classify and print the plan; touch nothing.
        --apply  create branch + backup, then apply OVERWRITE/ADD and stage MERGE files.
        --remove-retired   also delete files this kit retires on --apply.

    python migrate/migrate_kit.py --auto      (the agent autopilot entrypoint — v6.6+)
        Zero-argument end-to-end run, from the PROJECT root:
          1. DISCOVERS the staged kit folder (searches ./.kit-incoming, ./kit-incoming,
             and any top-level folder that contains AGENTS.md + migrate/*_baseline.sha256).
          2. Prints the plan, then applies it (branch + backup + WIP snapshot commit if the
             tree was dirty — nothing of yours can be lost).
          3. Auto-merges SinsGotchasLearnings.md via merge_sins.py (deterministic).
          4. Prints the AGENT NEXT STEPS block: the remaining .kit-incoming files and the
             per-file merge rules in migrate/UPGRADE_AUTOPILOT.md.
        The full unattended ritual (including the semantic merges and verification) is
        documented in migrate/UPGRADE_AUTOPILOT.md — an agent should follow THAT file.

    python migrate/migrate_kit.py --emit-baseline <version> --source <prior-kit-folder>
        Walk <source> and write migrate/<version>_baseline.sha256 next to this script.
        Use this when CUTTING a new kit release: it records the stock hashes of the
        prior version so the NEXT release's migrator can classify prior-version files as
        OVERWRITE instead of SKIP-DRIFTED. Never hand-edit a baseline.

    python migrate/migrate_kit.py --kit <kit> --from <version> [--plan|--apply]
        Restrict baseline matching to <version> only (e.g. --from v6.4). Without --from,
        every shipped baseline is consulted and the plan note reports which one matched.
"""
from __future__ import annotations

import argparse
import hashlib
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]  # avoid Windows cp1252 mojibake
except (AttributeError, ValueError):
    pass

# ── Classification policy ───────────────────────────────────────────────────
# PRESERVE: project state / contracts you fill in. NEVER touched by the migrator.
PRESERVE = {
    "STATE.md", "PRD.md", "GLOSSARY.md", "DATA_MODEL.md", "ARCHITECTURE.md",
    "UserPromptLog.md", "WorkLogAfterEachRun.md", "OpenTasksMustCompleteAll.md",
    "CONTEXT.md",  # routing file; if you somehow edited it, keep yours
    # v6.6.1: project contracts once authored — same class as PRD/DATA_MODEL. Without
    # these, a user-written FLOW.md landed in SKIP-DRIFTED and got flagged "needs a
    # human decision" on EVERY upgrade, when the right answer is always "keep yours".
    # (An untouched template copy is also fine to keep — it's inert until authored.)
    "FLOW.md", "DESIGN_GUIDELINES.md",
}
# Whole directory trees that are yours — never traversed for overwrite.
PRESERVE_DIRS = {"src", "docs", "tests", ".git"}

# MERGE: combine content / always needs human-or-agent judgment.
MERGE_ALWAYS = {
    "SinsGotchasLearnings.md",   # append the kit's generic entries after yours, renumbered
    "AGENTS.md",                 # the kit added §0a/§0b/§3 rules; your agent may have appended too
    "EXECUTION_PLAN.md",         # the kit fixed Phase 0 + added the server-script/smoke phase
    "skills/grill-to-prd.md",    # the kit added the port question
    "RepoMapReadFirst.md",       # has your curated block; regenerate, don't overwrite
}
# Generated — never migrate; regenerate after with `just sins-sync` / `just map-sync`.
GENERATED = {
    "SinsGotchasLearnings_INDEX.md",
}
# Files this kit retires — offer to remove (superseded), but only on --apply with consent.
#   setup.sh                      → superseded by scaffold.* (v5)
#   verification/audit_sins.{sh,py} → superseded by ast-grep rules in rules/ (v6.1)
# v6.4 → v6.5 retirements:
#   ADOPT_AND_UPGRADE_v6.1.md     → renamed/bumped to ADOPT_AND_UPGRADE.md
#   MIGRATION_v6.1.md             → superseded by migrate/MIGRATION.md (the three-path doc)
#   VibeCodingKit_FieldGuide_v6.4.md → version-bumped out by the v6.5 field guide
#   VibeCodingKit_Infographic_v6.4.html → version-bumped out by the v6.5 infographic
#   rules/leaflet-container-overflow-override.sins.yml → demo rule moved to
#     docs/ast-grep-examples/ (its shipped ### Audit Rule was dropped from §80 in v6.5)
# v6.5 → v6.6 retirements:
#   VibeCodingKit_FieldGuide_v6.5.md / VibeCodingKit_Infographic_v6.5.html → version-bumped
#     out by the v6.6 field guide + infographic
RETIRED = {
    "setup.sh", "verification/audit_sins.sh", "verification/audit_sins.py",
    "ADOPT_AND_UPGRADE_v6.1.md", "MIGRATION_v6.1.md",
    "VibeCodingKit_FieldGuide_v6.4.md", "VibeCodingKit_Infographic_v6.4.html",
    "VibeCodingKit_FieldGuide_v6.5.md", "VibeCodingKit_Infographic_v6.5.html",
    "rules/leaflet-container-overflow-override.sins.yml",
}


def sha256(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load_baselines(kit: Path) -> dict[str, dict[str, str]]:
    """Return {version: {rel: hash}} for every migrate/<version>_baseline.sha256 shipped.

    A "version" is the filename stem before `_baseline.sha256` (e.g. `v4`, `v6.4`).
    Older kits that ship only v4_baseline.sha256 keep working unchanged.
    """
    out: dict[str, dict[str, str]] = {}
    bdir = kit / "migrate"
    if not bdir.is_dir():
        return out
    for mf in sorted(bdir.glob("*_baseline.sha256")):
        version = mf.name[: -len("_baseline.sha256")]
        entries: dict[str, str] = {}
        for line in mf.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            h, _, rel = line.partition("  ")
            entries[rel.replace("\\", "/")] = h
        out[version] = entries
    return out


def match_baseline(rel: str, proj_hash: str, baselines: dict[str, dict[str, str]],
                   only: str | None = None) -> str | None:
    """Return the version whose stock hash for `rel` equals `proj_hash`, else None.

    `only` restricts the search to a single version (the --from flag). When multiple
    baselines match, the lowest version wins (oldest stock wins ties — a file that is
    simultaneously stock-v4 and stock-v6.4 is reported as v4, since that's the safer
    claim about provenance)."""
    versions = sorted(
        (v for v in baselines if only is None or v == only),
        key=_version_key,
    )
    for v in versions:
        if baselines[v].get(rel) == proj_hash:
            return v
    return None


def _version_key(version: str) -> tuple[int, ...]:
    """Sort versions numerically: 'v4' → (4,), 'v6.4' → (6, 4). Unknown → ()."""
    core = version[1:] if version.startswith("v") else version
    try:
        return tuple(int(x) for x in core.split("."))
    except ValueError:
        return ()


def in_preserve_dir(rel: str) -> bool:
    top = rel.split("/", 1)[0]
    return top in PRESERVE_DIRS


def classify(project: Path, kit: Path, only_version: str | None = None) -> dict[str, list[tuple[str, str]]]:
    """Return {action: [(rel, note), ...]}.

    `only_version` (the --from flag) restricts baseline matching to one version; when
    None, every shipped baseline is consulted and the OVERWRITE note names the match.
    """
    baselines = load_baselines(kit)
    plan: dict[str, list[tuple[str, str]]] = {
        "PRESERVE": [], "OVERWRITE": [], "ADD": [], "MERGE": [],
        "SKIP-DRIFTED": [], "RETIRE": [], "GENERATED": [],
    }

    kit_files = sorted(
        str(p.relative_to(kit)).replace("\\", "/")
        for p in kit.rglob("*") if p.is_file()
    )

    for rel in kit_files:
        # Never migrate the migrator's own folder, VCS, or Python bytecode caches.
        if (rel.startswith("migrate/") or rel.startswith(".git/")
                or "__pycache__" in rel or rel.endswith(".pyc")):
            continue

        proj_path = project / rel
        kit_path = kit / rel
        name = rel

        # Project-state files: preserve if present; add the template only if missing.
        if name in PRESERVE or in_preserve_dir(rel):
            if proj_path.exists():
                plan["PRESERVE"].append((rel, "your state — untouched"))
            else:
                plan["ADD"].append((rel, "missing; kit template added"))
            continue

        if name in GENERATED:
            plan["GENERATED"].append((rel, "regenerated after migrate (just sins-sync)"))
            continue

        if name in MERGE_ALWAYS:
            if not proj_path.exists():
                plan["ADD"].append((rel, "missing; kit version added"))
            elif kit_path.exists() and proj_path.exists() and sha256(proj_path) == sha256(kit_path):
                plan["PRESERVE"].append((rel, "already identical to this kit"))
            else:
                plan["MERGE"].append((rel, "combine your content with this kit's changes"))
            continue

        # Everything else = kit infrastructure (scripts, generators, configs, templates…).
        if not proj_path.exists():
            plan["ADD"].append((rel, "new in this kit"))
            continue

        if sha256(proj_path) == sha256(kit_path):
            plan["PRESERVE"].append((rel, "already identical to this kit"))
            continue

        # Differs from the kit. Is your copy stock of a known prior version (safe to
        # overwrite) or drifted (you/your agent edited it, or no baseline matches)?
        matched = match_baseline(rel, sha256(proj_path), baselines, only=only_version)
        if matched is not None:
            plan["OVERWRITE"].append((rel, f"stock {matched} → this kit (bugfixes)"))
        elif baselines:
            plan["SKIP-DRIFTED"].append(
                (rel, "matches no shipped baseline (your edits / unsupported version) — staged as .kit-incoming"))
        else:
            plan["SKIP-DRIFTED"].append((rel, "no baselines shipped — staged as .kit-incoming"))

    # Retired files present in the project.
    for name in sorted(RETIRED):
        if (project / name).exists():
            plan["RETIRE"].append((name, "retired by this kit (superseded)"))

    return plan


def git(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
    return subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True)


def emit_baseline(version: str, source: Path, dest_dir: Path) -> Path:
    """Write <dest_dir>/<version>_baseline.sha256 from every file under <source>.

    Used when CUTTING a release: point --source at the unpacked PRIOR kit and this
    records the stock hashes the next release's migrator will classify against. Output
    is GNU sha256sum format (`<hash>  <rel>`), matching the hand-maintained v4 file so
    the two are interchangeable. The migrator's own folder and VCS/bytecode are skipped
    so a baseline never records its own internals.
    """
    if not source.is_dir():
        raise SystemExit(f"ERROR: --source {source} is not a directory.")
    rels = sorted(
        str(p.relative_to(source)).replace("\\", "/")
        for p in source.rglob("*") if p.is_file()
        if not (str(p.relative_to(source)).replace("\\", "/").startswith("migrate/")
                or str(p.relative_to(source)).replace("\\", "/").startswith(".git/")
                or "__pycache__" in str(p) or str(p).endswith(".pyc"))
    )
    dest_dir.mkdir(parents=True, exist_ok=True)
    out = dest_dir / f"{version}_baseline.sha256"
    lines = [f"{sha256(source / rel)}  {rel}" for rel in rels]
    out.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    print(f"Wrote {out} — {len(lines)} stock file hashes for {version}.")
    print("Commit this alongside the kit so the next release can classify "
          f"{version} projects as OVERWRITE instead of SKIP-DRIFTED.")
    return out


def discover_kit(project: Path) -> Path | None:
    """Find a staged kit folder inside the project (v6.6 --auto).

    A candidate is a directory containing AGENTS.md AND migrate/*_baseline.sha256,
    that is not the project root itself. Preferred names first; otherwise every
    top-level dir (and one level below, for tar extractions that kept the
    kit's own top-level folder) is checked. Newest mtime wins ties.
    """
    preferred = [".kit-incoming", "kit-incoming", "_kit-incoming", "kit-new"]

    def is_kit(d: Path) -> bool:
        return (d.is_dir() and (d / "AGENTS.md").is_file()
                and any((d / "migrate").glob("*_baseline.sha256")))

    candidates: list[Path] = []
    for name in preferred:
        d = project / name
        if is_kit(d):
            candidates.append(d)
        elif d.is_dir():  # tar extracted WITH its top-level folder inside the staging dir
            candidates.extend(sub for sub in d.iterdir() if is_kit(sub))
    if not candidates:
        for d in project.iterdir():
            if d.name.startswith((".kit-backup", ".git")) or not d.is_dir():
                continue
            if is_kit(d):
                candidates.append(d)
            else:
                try:
                    candidates.extend(s for s in d.iterdir() if is_kit(s))
                except (PermissionError, OSError):
                    continue
    if not candidates:
        return None
    return max(candidates, key=lambda d: d.stat().st_mtime)


def snapshot_if_dirty(project: Path) -> None:
    """On the (already-created) migration branch, commit any uncommitted work as a
    WIP snapshot so the upgrade can never mix with or lose in-flight changes."""
    r = git(["status", "--porcelain"], project)
    if r.returncode == 0 and r.stdout.strip():
        git(["add", "-A"], project)
        c = git(["commit", "-m", "wip: pre-kit-upgrade snapshot (auto)"], project)
        print("  ✓ dirty tree snapshotted as its own commit" if c.returncode == 0
              else f"  ! could not snapshot dirty tree ({c.stderr.strip()}) — backup still covers it")


def auto_merge_sins(project: Path) -> bool:
    """Run merge_sins.py on a staged SinsGotchasLearnings sidecar. Returns True if merged."""
    mine = project / "SinsGotchasLearnings.md"
    inc = project / "SinsGotchasLearnings.md.kit-incoming"
    tool = Path(__file__).resolve().parent / "merge_sins.py"
    if not (mine.exists() and inc.exists() and tool.exists()):
        return False
    r = subprocess.run([sys.executable, str(tool), "--mine", str(mine), "--incoming", str(inc)],
                       cwd=project, capture_output=True, text=True)
    print(r.stdout.rstrip())
    if r.returncode == 0:
        inc.unlink(missing_ok=True)
        print("  ✓ SinsGotchasLearnings.md merged deterministically; sidecar removed")
        return True
    print(f"  ! merge_sins failed ({r.stderr.strip()}) — sidecar left for manual merge")
    return False


def apply(project: Path, kit: Path, plan: dict, remove_retired: bool) -> None:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

    # 1. Backup (outside git, always recoverable even if not a git repo).
    backup = project / f".kit-backup-{stamp}"
    backup.mkdir(exist_ok=True)
    for action in ("OVERWRITE", "MERGE", "SKIP-DRIFTED", "RETIRE"):
        for rel, _ in plan[action]:
            src = project / rel
            if src.exists():
                dst = backup / rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
    print(f"  ✓ backup written to {backup.name}/")

    # 2. Branch (only if it's a git repo and working tree is clean enough).
    if (project / ".git").exists():
        br = f"migrate-kit-{stamp}"
        r = git(["checkout", "-b", br], project)
        print(f"  ✓ git branch {br}" if r.returncode == 0
              else f"  ! could not branch ({r.stderr.strip()}); continuing on current branch")
        snapshot_if_dirty(project)

    def copy_in(rel: str) -> None:
        s, d = kit / rel, project / rel
        d.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(s, d)

    # 3. OVERWRITE + ADD (safe).
    for rel, _ in plan["OVERWRITE"]:
        copy_in(rel)
        print(f"  ~ overwrote {rel}")
    for rel, _ in plan["ADD"]:
        copy_in(rel)
        print(f"  + added     {rel}")

    # 4. MERGE + SKIP-DRIFTED → stage kit version as .kit-incoming (never clobber yours).
    staged: list[str] = []
    for action in ("MERGE", "SKIP-DRIFTED"):
        for rel, _ in plan[action]:
            inc = project / (rel + ".kit-incoming")
            inc.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(kit / rel, inc)
            staged.append(rel)
            print(f"  ⚑ staged    {rel}.kit-incoming  (merge needed)")

    # 5. Retired files.
    if remove_retired:
        for rel, _ in plan["RETIRE"]:
            (project / rel).unlink(missing_ok=True)
            print(f"  ✗ removed   {rel} (retired)")
    elif plan["RETIRE"]:
        print("  (RETIRE files left in place — re-run with --remove-retired to delete them.)")

    print("\nApplied. Nothing of yours was overwritten; merges are staged as .kit-incoming.")
    if staged:
        print("Next: resolve each .kit-incoming (see MIGRATION.md), then regenerate:")
        print("  just sins-sync && just map-sync   (or the python scripts directly)")
    print("Then prove green:  just verify-all")
    print(f"Rollback anytime: restore from {backup.name}/ or `git checkout -` + delete the branch.")


def print_plan(plan: dict) -> None:
    order = ["MERGE", "SKIP-DRIFTED", "OVERWRITE", "ADD", "RETIRE", "PRESERVE", "GENERATED"]
    label = {
        "MERGE": "MERGE — needs your/agent judgment (staged as .kit-incoming)",
        "SKIP-DRIFTED": "DRIFTED — matches no shipped baseline; kit staged as .kit-incoming",
        "OVERWRITE": "OVERWRITE — stock prior-version → this kit, bugfixes (safe)",
        "ADD": "ADD — new files in this kit",
        "RETIRE": "RETIRE — superseded by this kit (removed only with consent)",
        "PRESERVE": "PRESERVE — your state, untouched",
        "GENERATED": "GENERATED — regenerated after migrate",
    }
    for a in order:
        items = plan[a]
        if not items:
            continue
        print(f"\n## {label[a]}  ({len(items)})")
        for rel, note in items:
            print(f"   {rel:<42} {note}")


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Migrate a v4/v5/v6.x project onto the current kit (v6.6.1) safely, "
                    "or emit a baseline when cutting a new release.")
    ap.add_argument("--kit", help="path to the unpacked kit folder (required except with --emit-baseline)")
    ap.add_argument("--project", default=".", help="path to your project (default: cwd)")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--plan", action="store_true", help="classify only (default)")
    g.add_argument("--apply", action="store_true", help="apply OVERWRITE/ADD, stage MERGE")
    g.add_argument("--auto", action="store_true",
                   help="v6.6 autopilot: discover the staged kit, plan, apply, auto-merge "
                        "sins, and print the agent's remaining steps")
    g.add_argument("--emit-baseline", metavar="VERSION",
                   help="write migrate/<VERSION>_baseline.sha256 from --source and exit "
                        "(used when cutting a release; e.g. --emit-baseline v6.4)")
    ap.add_argument("--source", help="prior kit folder to hash for --emit-baseline")
    ap.add_argument("--from", dest="from_version", metavar="VERSION",
                    help="restrict baseline matching to VERSION (e.g. v6.4); "
                         "default: consult every shipped baseline")
    ap.add_argument("--remove-retired", action="store_true",
                    help="also delete files this kit retires on --apply")
    args = ap.parse_args()

    # ── emit-baseline mode (release tooling, not migration) ────────────────────
    if args.emit_baseline:
        if not args.source:
            ap.error("--emit-baseline requires --source <prior-kit-folder>")
        # Write next to this script (migrate/), so it ships with the kit regardless of cwd.
        dest_dir = Path(__file__).resolve().parent
        emit_baseline(args.emit_baseline, Path(args.source).resolve(), dest_dir)
        return

    # ── migration mode ─────────────────────────────────────────────────────────
    project = Path(args.project).resolve()
    if args.auto and not args.kit:
        found = discover_kit(project)
        if found is None:
            print("ERROR (--auto): no staged kit found. Unpack the new kit into "
                  "./.kit-incoming/ (any folder containing AGENTS.md + "
                  "migrate/*_baseline.sha256 works), then re-run.")
            sys.exit(2)
        args.kit = str(found)
        print(f"--auto: discovered staged kit at {found}\n")
    if not args.kit:
        ap.error("--kit is required (or use --auto / --emit-baseline)")
    kit = Path(args.kit).resolve()
    baselines = load_baselines(kit)
    if not baselines:
        print(f"ERROR: {kit} doesn't look like a kit folder (no migrate/*_baseline.sha256).")
        sys.exit(2)
    if kit == project:
        print("ERROR: --kit and --project are the same folder. Unpack the kit elsewhere.")
        sys.exit(2)
    if args.from_version and args.from_version not in baselines:
        avail = ", ".join(sorted(baselines, key=_version_key))
        print(f"ERROR: --from {args.from_version} matches no shipped baseline "
              f"(available: {avail}).")
        sys.exit(2)

    plan = classify(project, kit, only_version=args.from_version)
    matched_versions = sorted({note.split()[1] for _, note in plan["OVERWRITE"]
                              if note.startswith("stock ")})
    from_note = f" [restricted to {args.from_version}]" if args.from_version else ""
    print(f"Migration plan for: {project}\n(kit: {kit}){from_note}")
    if matched_versions and not args.from_version:
        print(f"Detected stock-version matches: {', '.join(matched_versions)}")
    print_plan(plan)

    if args.apply or args.auto:
        print("\n— applying —")
        apply(project, kit, plan, args.remove_retired)
    else:
        print("\n(plan only — nothing changed. Re-run with --apply to execute.)")
        return

    if args.auto:
        print("\n— auto-merging deterministic pieces —")
        auto_merge_sins(project)
        remaining = sorted(
            str(p.relative_to(project)).replace("\\", "/")
            for p in project.rglob("*.kit-incoming") if p.is_file())
        print("\n════ AGENT NEXT STEPS (migrate/UPGRADE_AUTOPILOT.md §3–§5) ════")
        if remaining:
            print("Semantic merges remaining (rules per file in UPGRADE_AUTOPILOT.md §3):")
            for rel in remaining:
                print(f"   · {rel}")
        else:
            print("No semantic merges remaining.")
        print("Then: §4 regenerate + verify (just sins-sync && just map-sync && "
              "just doctor && just verify-all)")
        print("Then: §5 clean up staging + commit. Do NOT stop to ask the user unless "
              "a stop condition in UPGRADE_AUTOPILOT.md §6 is met.")


if __name__ == "__main__":
    main()
