# EXECUTION_PLAN

> **Build state lives in `STATE.md`, not here.** That file holds the machine-readable
> `current_phase` / `active_task` / `completed_phases` block agents read at session start.
> This file is the *plan* (relatively stable); STATE.md is the *cursor* (changes constantly).
> Keeping them separate means agents load ~200 tokens to orient instead of re-reading this
> whole file. When you finish a phase, update STATE.md (AGENTS.md §0, PROMPTS.md §H).


How the build proceeds, phase by phase. Each phase is shippable and tested before moving on.

Phases are sized so each is independently shippable and verifiable. For larger projects, this file may be long (2000+ lines) — that's fine. For smaller projects, a single page is enough.

> **This file vs. `plans/` working plans.** This is the *whole-project* build plan. For one
> large/complex chunk of work mid-build (a refactor, a migration, a multi-file feature), write a
> separate dated working plan under `plans/<slug>-YYYY-MM-DD.md` (AGENTS.md §4b): keep each phase
> small (a handful of files — rule of thumb well under ~300k tokens), and delegate independent
> slices to subagents (Explore → Plan → Execute) where the tool supports it. The working plan is
> disposable; this file and `STATE.md` remain the durable record.

---

## Global rules

1. **One phase at a time, in order.** No skipping.
2. **Verification gates close each phase.** All listed criteria must pass before starting the next phase.
3. **One commit per phase minimum.** Larger phases may span multiple commits, but no commit spans multiple phases.
4. **The reference files (PRD, GLOSSARY, DATA_MODEL, FLOW, ARCHITECTURE) are immutable during a phase.** If a phase reveals one of them is wrong, finish the phase if possible, then update the reference file in a separate commit, then start the next phase.
5. **Risk-flagged units get evals first.** For any unit with complex logic, edge-case handling, validation, a parser, or money/units math, write its edge-case tests *before* the implementation (AGENTS.md §4a). The grill marks these in the acceptance criteria.
6. **UI phases slice along FLOW.md journeys and cite its screen IDs.** A UI phase is a
   journey (or journey segment) demoable end-to-end, and its acceptance criteria name FLOW
   screens and states explicitly (e.g. "S1 nominal + empty + loading render per FLOW §5") —
   never "build the components".
7. **No phase is done with an unresolved `#PLAN_UNCERTAINTY`.** If the agent assumed something to make progress, it tagged it inline (AGENTS.md §1a); before closing the phase, each one is validated, promoted to a PRD open question, or written up as an ADR. Never silently cross an `#EXPORT_CRITICAL`.

---

## Library verification protocol

Before writing code that uses a library new to this repo, the agent writes `verification/verify_<library>.py` (or .ts) and runs it. See AGENTS.md §4.

List libraries that will need verification scripts here so it's not forgotten:

- [ ] [Library 1, e.g. sqlglot — used in Phase 2]
- [ ] [Library 2, e.g. tree-sitter-typescript — used in Phase 2.5]
- [ ] ...

---

## Phase template

Every phase below follows this template. The agent stops, verifies, commits, then moves on.

```
## Phase N — <name>

**Goal:** [One sentence.]
**Duration:** [estimate in focused dev-time]
**Prerequisites:** [What earlier phases must be complete.]
**Flags:** [#EXPORT_CRITICAL constraints this phase must hold · any #PLAN_UNCERTAINTY to resolve before done — AGENTS.md §1a. Omit if none.]

### N.1 [Step]
[Detailed steps with concrete file paths and code where appropriate.]

### N.X Verification
- [ ] [Test command] returns [expected output]
- [ ] Manual: [thing you check by hand]
- [ ] Any risk-flagged unit (complex logic / edge cases / validation / parser / money-units) has its edge cases written as tests FIRST and passing (AGENTS.md §4a)
- [ ] No `#PLAN_UNCERTAINTY` left unresolved; no `#EXPORT_CRITICAL` silently changed (AGENTS.md §1a)
- [ ] If this phase ships UI: it follows `DESIGN_GUIDELINES.md` — no AI-slop tells, PRD design language honored

### N.Y Acceptance checklist
- [ ] [Concrete criterion 1]
- [ ] [Concrete criterion 2]
- [ ] [Tests passing]
- [ ] [Linter passing]
- [ ] [Type checker passing]

Commit: `git commit -m "phase N: <one-line summary>"`
```

---

## Phase 0 — Skeleton

**Goal:** Repo exists, basic file structure, "hello world" runs.

> **Note:** `scaffold.ps1`/`scaffold.sh` already ran git init, installed hooks, and made
> the bootstrap commit IN PLACE in this folder. Do NOT `mkdir <project>` or re-init git —
> you are already inside the project root. Phase 0 is about the first runnable code.

### 0.1 Language init (in place, here)

```bash
# You are already in the project root. Initialize the language toolchain in place:
uv init          # Python   (or:)
pnpm init        # Node/TS
# Do NOT create a sub-folder for the app; the project root IS the app root.
```

Then install the dev tools the verification gate needs (stack-aware — installs ruff/mypy/
pytest for Python, eslint/typescript/vitest/tsx for Node, based on which manifest exists):

```bash
just setup       # run ONCE, here, after the manifest(s) exist
```

Until you run this, `just verify` will LOUDLY report lint/typecheck/test as SKIPPED (it
won't silently pass) — so you always know whether the gate is really checking your code.

### 0.2 Project structure

```
<project root = this folder>/
├── .gitignore
├── .env                  # PORT lives here (from the grill) — single source of truth
├── README.md
├── pyproject.toml / package.json
├── src/
└── tests/fixtures/
```

### 0.3 First runnable thing

[Minimal "hello world" appropriate to the project — a CLI that prints version, or a server
that boots on `$PORT` from `.env`, plus one passing test.]

### 0.4 Acceptance

- [ ] `<run command>` produces expected output
- [ ] Server (if any) boots on the PORT from `.env` — not a hardcoded port
- [ ] `<test command>` passes (even if zero tests)
- [ ] `just verify` passes
- [ ] `git log` shows the bootstrap commit + this phase's commit

Commit: `phase 0: skeleton`

---

## Phase 1 — [First real capability]

[Fill in based on your project. Each phase should be self-contained and testable.]

---

## Phase 2 — ...

[Continue.]

---

## Final phase − 1 — Server control scripts (if the app runs a server)

**Goal:** Two robust server-control scripts in the project ROOT so the user can
start and stop the dev server with one command — no terminal incantations.

**Prerequisites:** App runs; `.env` has `PORT`; ARCHITECTURE.md names the dev command.

### Steps

1. Copy the template pair matching the platform the USER runs the server on:
   - Windows → `skills/templates/start-server.ps1.template` → `start-server.ps1`
     and `stop-server.ps1.template` → `stop-server.ps1` (project root).
   - macOS / Linux / WSL → `skills/templates/start-server.sh.template` → `start-server.sh`
     and `stop-server.sh.template` → `stop-server.sh` (project root), then `chmod +x` both.
   (Both pairs implement the same contract; generate both pairs only if the project is
   genuinely used from both shells.)
2. Fill EVERY `{{...}}` placeholder from ARCHITECTURE.md + `.env`:
   - `{{PROJECT_NAME}}`, `{{APP_DIR}}` (`.` if root), `{{DEV_COMMAND}}`,
     and the optional `{{INSTALL_CHECK}}` / `{{INSTALL_COMMAND}}` block (delete if unused).
   (`dox-check` fails on any leftover `{{PLACEHOLDER}}` in a generated script — a half-filled
   script must never survive to runtime.)
3. Delete the template header comment block from each generated script.
4. Confirm both scripts read `PORT` from `.env` — NO hardcoded port literal anywhere
   (SinsGotchasLearnings §24; the `localhost:NNNN` audit will catch a stray one).

### Verification
- [ ] `.\start-server.ps1` (or `./start-server.sh`) boots the server on the `.env` PORT
- [ ] `.\stop-server.ps1` (or `./stop-server.sh`) frees that port (kill-by-port)
- [ ] `grep -rn "localhost:[0-9]" .` finds no hardcoded port in source
- [ ] `just dox-check` green (no unfilled `{{...}}` placeholders)

Commit: `phase: server control scripts`

---

## Final phase — Distribution

[How the thing gets to users. CLI tool? Web app? Library? This phase covers packaging, distribution, and final docs.]

---

## Anti-goals for v1

Things explicitly NOT built in v1. From PRD §5 and §7 — repeated here for the agent's convenience.

- [Anti-goal 1]
- [Anti-goal 2]

---

## After v1 ships

Future phases (v1.1, v2) — high-level, no commitment.

- [Future capability 1]
- [Future capability 2]