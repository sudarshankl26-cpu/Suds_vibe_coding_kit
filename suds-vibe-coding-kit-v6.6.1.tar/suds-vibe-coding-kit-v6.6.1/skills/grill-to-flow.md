---
name: grill-to-flow
description: One-question-at-a-time interview that turns PRD.md + DATA_MODEL.md into FLOW.md — the screen inventory, navigation graph, per-screen contracts, and states. Run it AFTER grill-to-prd and DATA_MODEL, BEFORE ARCHITECTURE/EXECUTION_PLAN, for any project with a UI.
---

# Skill: grill-to-flow

Companion to `skills/grill-to-prd.md`. That grill closes the *requirements* misalignment
gap; this one closes the *navigation* gap — the #2 cause of "it works but it isn't what I
pictured." Its job: force every screen, click, and state to be a **decided** thing before
any layout is generated, so the agent renders FLOW.md instead of inventing UX.

Skip entirely for CLIs / libraries / pipelines. For a single-screen tool, run the short
form (steps 3, 5, 6 only).

## Preconditions

`PRD.md` and `DATA_MODEL.md` exist. Read them first, plus `GLOSSARY.md` and
`DESIGN_GUIDELINES.md` / the chosen design language. Never re-ask what they already answer.

## How to run it (the prompt the agent follows)

> Read PRD.md, DATA_MODEL.md, GLOSSARY.md. Then run the grill-to-flow skill: interview me
> ONE question at a time until the information flow is fully resolved, recommending an
> answer for each. Do NOT write code, wireframes, or components yet — only interview,
> then produce FLOW.md from the kit template when done.

Same session rules as grill-to-prd: **one question at a time · always recommend an answer
with a one-line reason · sharpen fuzzy terms into GLOSSARY immediately · probe with concrete
scenarios · record rejected patterns as §7 flow anti-goals · prototype when paper can't
decide** (`skills/prototype-to-answer.md` — layout disputes between two real alternatives
are the canonical case: mock both as throwaway HTML, look, decide, delete).

## The interview ladder (broad → narrow, in this order)

**1. Roles → questions.** For each PRD role: "When [role] opens this, what question are they
trying to answer, and how often?" Push past features to questions — "see sales data" is not
an answer; "which region is missing target *this week*" is. Rank the questions. This fills
FLOW §1.

**2. The 90-second test (dashboards).** For the primary role: "You open it, you have 90
seconds and zero clicks. What MUST you know before you close it?" The answer, in order, is
the top of the home screen. Everything not named here is behind a zoom or filter. Recommend
a concrete payload and let them correct it.

**3. Journeys.** For each ranked question: trigger → path → **the real-world decision at the
end**. Force the ending: "After seeing this, what do you *do* — call someone, export, edit,
close the tab?" A journey that ends in "just look" is usually two journeys or zero. Fills §2.

**4. Drill hierarchy.** For each journey, walk the narrowing: overview → "which one?" →
"why?" → row-level truth. At each hop ask: "What context travels with the click?" (the
selection, the time range, the filters). Default pattern to recommend for dashboards:
**overview first, zoom and filter, details on demand.** Fills §4's edges and labels.

**5. Screen inventory.** Now — and only now — name the screens the journeys need. For each:
its one-sentence question, route, entry and exit points. Challenge every screen that no
journey traverses ("nothing routes here — cut it or find its journey?") and every question
answered by two screens ("merge or differentiate?"). Apply the ≤3-clicks and no-dead-end
rules. Fills §3.

**6. Per-screen bindings — cross-examine DATA_MODEL.** For each screen, each displayed
number/list: which `Entity.field`, what grain, what aggregation, what comparison baseline?
**When a screen wants data the model doesn't have, stop the flow grill and reconcile the
contract conflict first** — either DATA_MODEL gains the field (separate, deliberate change)
or the screen loses the widget. This collision is the single highest-value moment of the
whole grill; never paper over it. Fills §5 bindings.

**7. States.** For every screen, resolve all six: loading / empty / partial / error / nominal
/ permission-denied. Recommend defaults (skeletons over spinners; empty states carry the CTA
that escapes them). Probe with scenarios: "First-ever login, zero data — what does S1 show?"
"The metrics API times out but auth worked — blank page or degraded view?" Fills §5 states.

**8. Filters & controls.** Every control: options, **default**, global-or-local, URL param.
Concrete probe: "You filter to Region=West on Overview, then click into a detail — is West
still applied?" (Global-vs-local is decided once, in §4, not per screen.)

**9. Stateful widgets → risk flags.** Anything with cross-filtering, multi-step entry,
optimistic updates, or undo: sketch its state table on the spot (§6) and **mark it
risk-flagged** so AGENTS.md §4a eval-first applies — the transition table becomes tests
before the widget is built.

**10. Flow anti-goals.** "What navigation patterns do you NOT want, ever?" (configurable
layouts, nested modals, hamburger-everything…). Write them into §7 with reasons; tag
non-negotiables `#EXPORT_CRITICAL`.

## Visual mode — the flow simulator (use it; don't hand-draw mockups)

Flow is a visual judgment for humans; prose walls hide bad navigation. But per-screen HTML
mockups burn tokens and drag the session into fonts and colors that DESIGN_GUIDELINES / the
design language already settled. The kit resolves this with
`skills/templates/flow-simulator.html.template` — a **static greybox harness you never
regenerate**. The ONLY thing you emit per project is the `FLOW_SPEC` object at the top of a
copy of that file (~3–5k chars for a whole app): screens with zones on a 12-col grid, `goto`
edges with carried context, states, and journeys. The harness gives the user clickable
screens, journey playback with narration, a nominal/loading/empty/error switcher, an
auto-drawn nav map, and per-zone keep/change/kill flags that export as `FLOW_FEEDBACK.md`.

### The FLOW_SPEC shape (the ONLY thing you author — the contract, restated here)

```js
const FLOW_SPEC = {
  project: "Name shown in the harness header",
  screens: [ {
    id: "S1", name: "Overview", route: "/",
    question: "The one question this screen answers",
    zones: [ {
      id: "z1", label: "what the zone shows",
      type: "kpi|chart|table|filter|nav|action|form|text",
      x: 1, y: 1, w: 12, h: 2,      // 12-col grid; y = row, h = row-span, rows ≈64px
      goto: "S2",                    // optional: click-through target screen id
      carry: "context that travels with the click",   // optional
      note: "designer note shown on hover"            // optional
    } ],
    states: { empty: "…", error: "…", loading: true } // optional per-screen states
  } ],
  journeys: [ { id: "J1", name: "…", role: "…",
                steps: [ { screen: "S1", zone: "z1"|null, say: "narration" } ] } ]
}
```

Every screen with a missing `states` entry renders an `⚠ UNSPECIFIED` overlay in the
state switcher — that is the harness telling you FLOW.md §5 has a hole. `FLOW_FEEDBACK.md`
is GENERATED by the harness's export button; you only ever consume it (each line carries the
screen/zone id and its `[keep]`/`[change]`/`[kill]` flag plus the user's note) — never write
one by hand.

Cadence inside the grill:
1. **First cut after step 5** (screen inventory exists, even rough): copy the template to
   `plans/flow-sim-v1.html`, inject the spec, tell the user to open it and walk J1.
2. **User exports `FLOW_FEEDBACK.md`** → you reconcile every item into the draft (a `[kill]`
   removes the zone, a `[change]` edits it, screen notes may add/merge/reorder), regenerate
   only the spec, bump the filename (`-v2`). Two or three rounds is normal; each round costs
   a spec, not a mockup.
3. **Layout dispute between two real alternatives?** Two specs in two copies, user clicks
   both, picks one — that IS the `prototype-to-answer` detour for flow. Delete the loser.
4. **Empty/error probing (step 7):** have the user flip the state switcher on every screen —
   an `⚠ UNSPECIFIED` overlay is a hole in FLOW.md §5, fix it before proceeding.

Hard rules: never restyle the harness, never add brand colors or real data to it, never
inline per-screen bespoke HTML. When the user signs off, transcribe the final spec into
FLOW.md (§3–§6 map 1:1: zones→reading order and bindings, gotos→§4 edges, journeys→§2) and
archive the sim under `plans/`. The sim is scaffolding; FLOW.md is the contract.

## When the grilling is done

Fill `FLOW.md` from the kit template, run its §8 completeness gate, and fix what fails
**before** ARCHITECTURE/EXECUTION_PLAN. Anything the user deferred gets a `#PLAN_UNCERTAINTY`
tag and a PRD §9 open question — a guessed screen is worse than a missing one.

Then, when writing EXECUTION_PLAN.md: **slice phases vertically along journeys** — J1
end-to-end with real data and all six states first — never horizontally by component type.
Phase acceptance criteria cite FLOW screen IDs ("S1 nominal + empty + loading render per
FLOW §5"), which is what makes the build predictable and reviewable.
