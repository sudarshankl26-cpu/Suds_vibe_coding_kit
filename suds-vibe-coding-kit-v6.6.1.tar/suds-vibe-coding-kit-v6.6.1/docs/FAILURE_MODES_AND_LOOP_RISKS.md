# Failure modes, loop risks, and confusion scenarios

> A grounded catalog of the ways the kit (or an agent driving it) can malfunction,
> get stuck in a loop, or become confused — what each looks like, what causes it,
> how the kit defends against it, and the residual risk to watch.
>
> Categories: **A. Silent false-green** (gate claims pass but checked nothing) ·
> **B. Red-herring failures** (gate fails for an unrelated reason → agent loops on
> the wrong fix) · **C. Self-referential loops** (a gate/check feeds itself) ·
> **D. Context & token blowup** (the agent drowns in the kit's own files) ·
> **E. State-race / multi-writer corruption** · **F. Drift & rot** (docs/contracts
> stop matching code) · **G. Migration & upgrade hazards** · **H. Tool/model
> incompatibility**.
>
> Each entry is tagged **[DEFENDED]** (the kit has a mechanism), **[PARTIAL]**
> (mechanism exists but has a gap), or **[RESIDUAL]** (no gate; prose discipline
> only). Validated against the v6.5 kit on 2026-07-06 via `just doctor` +
> `just verify` + `just verify-all`.

---

## A. Silent false-green — the gate passed but checked nothing

This is the highest-severity class: a green `just verify` that the agent trusts,
but the gate actually no-op'd. v6.5's entire `run_gate.py` rewrite exists to kill it.

**A1. Configured-but-missing tool prints "skipping" and returns green.** `[DEFENDED]`
- *Symptom:* gate says "skipping" / "not found" and exits 0; agent trusts it.
- *Cause:* a stack is configured (e.g. `pyproject.toml` exists) but the tool
  (`ruff`/`mypy`/`pytest`) isn't installed. Pre-v6.5 this no-op'd silently — an
  entire harness once did nothing for a whole phase this way
  (`SinsGotchasLearnings` §33 / ex-§85).
- *Kit defense:* `run_gate.py` `missing_tool()` returns exit **3** (red) with the
  exact setup command when a configured tool is absent. `just doctor` self-tests
  every configured gate can actually execute. **v6.6.1:** `audit-sins`
  (`scripts/sins.py`) now goes through the SAME `missing_tool()` policy — before,
  it had its own ast-grep lookup that printed "SKIPPED (non-fatal)" and returned
  green, i.e. this exact failure mode surviving inside the kit's signature gate.
  `sins.py` and `doctor` also share one `find_ast_grep()` so they can't disagree.
- *Residual:* `KIT_GATES_LENIENT=1` demotes these to warnings (intentional escape
  hatch for docs-only sessions) — but it prints a loud banner every run so it
  can't be left on by accident. Don't leave it on.

**A2. The wrong package manager is assumed (pnpm-flavored kit on an npm project).** `[DEFENDED]`
- *Symptom:* JS gates fail or skip because the kit assumed `pnpm` but the project
  uses `npm`/`yarn`/`bun`.
- *Cause:* hardcoded package manager.
- *Kit defense:* `run_gate.py` `js_runner()` **detects from the lockfile**
  (`pnpm-lock.yaml` / `package-lock.json` / `yarn.lock` / `bun.lockb`), never
  assumes. Falls back to "whatever exists" only when there's no lockfile yet.

**A3. The gate's sub-tool isn't installed (runner spawns but inner tool missing).** `[DEFENDED]`
- *Symptom:* `uv run ruff` or `pnpm exec eslint` spawns, can't find the inner tool,
  returns a confusing spawn error.
- *Kit defense:* `run_gate.py` matches the runner's own "Failed to spawn" /
  "command not found" phrasing and routes it to `missing_tool()` (red + fix),
  rather than letting it surface as a generic test failure the agent misdiagnoses.

**A4. `doctor` is green but `verify` still skips something.** `[RESIDUAL]`
- *Gap:* doctor checks the tools *exist*; it doesn't prove every gate *runs the
  right files*. If a gate's config is misconfigured (e.g. ruff excludes the whole
  tree), doctor is green and verify is green but nothing was checked.
- *Mitigation:* read the gate's own summary line — it prints `[ran: … | unconfigured: … | MISSING: …]`. If `ran:` is empty, nothing ran.

---

## B. Red-herring failures — the agent loops on the wrong fix

The gate legitimately fails, but the *reason* is unrelated to the code the agent
is editing. The agent sees red, assumes its current change is wrong, and thrashes.

**B1. `verify_*.ts` fails with `ERR_PNPM_NO_PKG_MANIFEST` in a Python-only project.** `[DEFENDED — fixed in this audit]`
- *Symptom:* `just verify` exits 1 with a wall of pnpm stack trace pointing at
  `verify_zod.ts`, in a repo with no `package.json`.
- *Cause:* the `verify-libs` gate ran TS verify files unconditionally; pnpm tried
  to auto-install, found no manifest, and crashed. Asymmetric with the Python
  path (which cleanly skips `verify_sqlglot.py` as "target library not installed").
- *Was:* a real bug — observed in this validation run on the unpacked kit.
  An agent would loop trying to "fix" the zod script or add a package.json.
- *Fix applied:* `run_gate.py gate_verify_libs()` now skips `verify_*.ts` files
  when no `package.json` exists (symmetric with the Python skip). Verified green.
- *Migration note:* if you hit this, your `run_gate.py` is pre-v6.5 — re-run
  MIGRATION.md Path A or B to get the fix.

**B2. `dox-check` informational notes mistaken for failures.** `[RESIDUAL]`
- *Symptom:* `dox-check` prints `i ARCHITECTURE.md: 1 referenced path(s) missing`
  and the agent "fixes" it by deleting the line or inventing the path.
- *Reality:* these are **informational notes** (the `i` prefix), not failures
  (`x`). A contract doc referencing a not-yet-built path is normal mid-project.
  The gate only *fails* on wholesale rot (≥3 missing AND >30% of refs).
- *Mitigation:* mark planned paths with `<!-- planned -->` to silence the note;
  don't invent paths to make the note go away.

**B3. `check-prompt-log` out-of-order timestamps.** `[DEFENDED — v6.1]`
- *Symptom:* the prompt log has entries that look out-of-order.
- *Cause:* cross-tool clock skew (UTC vs local, two machines).
- *Was:* v6 made this a hard fail AND compared timestamps naively, so the agent
  "fixed" it by **rewriting the append-only trail** — the single biggest time-sink in v6.
- *Kit defense:* `check_prompt_log.py` compares timezone-aware *instants* (not
  strings), and out-of-order is a **note, not a failure**. AGENTS.md §0a forbids
  re-stamping past entries. Never edit `UserPromptLog.md` content.

**B4. `check-tasks` fails because a deferred task has no reason.** `[DEFENDED]`
- *Symptom:* `verify-all` fails with "DEFERRED without a reason: [~] —".
- *Cause:* `[~]` and `[!]` markers require ≥3 chars of reason text; a bare em-dash
  doesn't count.
- *Fix:* write an actual reason: `[~] blocked on API X landing in v2` not `[~] —`.

**B5. ast-grep rule matches its own comment / matches too broadly.** `[PARTIAL]`
- *Symptom:* `audit-sins` flags a line that's correct, or a rule matches the
  example in its own doc.
- *Cause:* a `### Audit Rule` with a pattern that's too eager, or that matches
  the comment explaining it.
- *Kit defense:* ast-grep is AST-based (a rule can't match its own comment, unlike
  the old grep engine). `sgconfig.yml` excludes `docs/ast-grep-examples/` from scans.
- *Residual:* an over-broad `files:` glob or pattern is on the rule author. Use
  `# ast-grep-ignore` / `// ast-grep-ignore` on the line above a legitimate
  exception — never delete or weaken the rule.

---

## C. Self-referential loops — a check feeds itself

**C1. "STALE AUDIT — run sins-sync, re-verify" loop.** `[DEFENDED — v6.1]`
- *Symptom:* agent edits `SinsGotchasLearnings.md`, `audit-sins` says rules are
  stale, agent runs `sins-sync`, re-runs verify, edits again, stale again…
- *Was:* v6 required a manual sync between editing the taxonomy and auditing.
- *Kit defense:* `sins.py audit()` **self-heals** — if rules are stale vs the
  taxonomy, it regenerates them inline before scanning. No sync-then-re-verify dance.

**C2. Repo-map regeneration churn.** `[DEFENDED]`
- *Symptom:* agent runs `just map-sync`, the map changes, dox-check re-reports,
  agent re-runs…
- *Kit defense:* `build_repo_map.py` preserves your curated "start here" block;
  only the auto-generated tree refreshes. `dox-check` MAP-FRESH only fails on
  wholesale staleness (≥3 dead paths) or leftover `[fill in]` placeholders, not
  on every diff.

**C3. Re-walking the file tree "to understand structure".** `[DEFENDED — prose]`
- *Symptom:* agent spends 50k+ tokens re-discovering the codebase layout each
  session instead of reading the 2k-token map.
- *Kit defense:* AGENTS.md §0 step 1 mandates `RepoMapReadFirst.md` first; the
  anti-pattern is explicitly listed in §2 ("Reinventing an in-repo pattern").
- *Residual:* prose discipline — no gate forces the agent to read the map first.

---

## D. Context & token blowup — the agent drowns in kit files

**D1. The agent reads everything every session.** `[DEFENDED — §0 protocol]`
- *Symptom:* agent reads `AGENTS.md` (37k), `SinsGotchasLearnings.md` (74k),
  all contract docs, the field guide (29k)… every session, blowing the context
  window before any work starts.
- *Kit defense:* §0 prescribes a strict read order with token budgets — map
  first (~2k), STATE (~200), the index's ★ALWAYS block + trigger map (not the
  full sins file), current phase only. The full sins taxonomy is read **on
  demand** via the trigger map.
- *Residual:* if the agent ignores §0, no gate stops it. Non-frontier models
  (GLM/DeepSeek/MiniMax/MiMo) see `MODEL_NOTES.md` for budget-specific guidance.

**D2. A single trajectory for a large task.** `[DEFENDED — §4b]`
- *Symptom:* one long session for a 20-file refactor; recall degrades, cost
  spikes, prompt-cache misses.
- *Kit defense:* §4b prescribes dated `plans/` files, small phases (~300k tokens
  each), and subagent delegation with a **context firewall** (subagents write to
  `.scratch/<task>/`, return only path + 3-line summary).
- *Residual:* a suggestion, not a gate — the agent must choose to phase the work.

**D3. Sins taxonomy grows unbounded.** `[PARTIAL — sins-triage]`
- *Symptom:* `SinsGotchasLearnings.md` accretes entries until it's unreadable.
- *Kit defense:* `just sins-triage` reports promotion candidates, entries without
  triggers, digest-over-budget, file bloat. The recurrence ratchet (§0a) promotes
  repeated prose failures into gates (type/ast-grep/test) instead of a 3rd entry.
- *Residual:* triage is informational — the agent/user must act on it.

---

## E. State-race / multi-writer corruption

**E1. Two top-level agents on the same checkout.** `[RESIDUAL — unsupported by design]`
- *Symptom:* `UserPromptLog.md` appends race (Windows sharing-violation),
  `STATE.md` last-write-wins, `.git/index.lock` contention fails a commit mid-flight.
- *Kit defense:* AGENTS.md §8 explicitly states "concurrent multi-agent use is not
  supported" — STATE.md is a baton between tools used **one at a time**.
- *The supported parallel path:* a single orchestrator delegating via the §4b
  subagent firewall (each writes to its own `.scratch/<task>/`, returns a summary).
- *Residual:* no gate prevents two humans from opening two agents on one repo.
  It's a configuration the kit refuses to support.

**E2. `.env` / port contention.** `[DEFENDED]`
- *Symptom:* two dev servers fight over the same port.
- *Kit defense:* port lives once in `.env` as `PORT`; all consumers read it
  (SinsGotchasLearnings §24). No `localhost:NNNN` literals (§2 anti-pattern).

**E3. `.env` copied from the example with `PORT=` left empty.** `[DEFENDED — dox-check check 7, v6.6.1]`
- *Symptom:* every consumer builds `localhost:` (no port); the app won't boot and
  the error is obscure. (`.env.example` ships `PORT=` empty on purpose — a shipped
  default would put every kit project on the same port.)
- *Kit defense:* `dox-check` (part of `just verify`) hard-fails when `.env` has a
  `PORT=` line with no value, with the fix in the message. No `.env` / no `PORT`
  line = not a server project = clean skip.

---

## F. Drift & rot — docs/contracts stop matching code

**F1. Contract docs reference paths that no longer exist.** `[DEFENDED — dox-check]`
- *Kit defense:* `dox-check` check 5 scans contract docs for backticked repo paths;
  wholesale rot (≥3 missing AND >30%) is a hard fail. Mark planned paths
  `<!-- planned -->`.

**F2. RepoMap describes a deleted architecture.** `[DEFENDED — dox-check check 6]`
- *Kit defense:* once the repo has real source, the map can't keep `[fill in]`
  placeholders or reference ≥3 dead paths. Fix is `just map-sync`.

**F2b. Generated scripts still contain `{{PLACEHOLDER}}` tokens.** `[DEFENDED — dox-check check 8, v6.6.1]`
- *Symptom:* a half-filled `start-server.ps1` / `start-server.sh` / smoke spec fails
  at RUNTIME with a confusing error — after the agent already declared the phase done.
- *Kit defense:* `dox-check` hard-fails on `{{UPPERCASE}}` tokens in any `*.ps1` /
  `*.sh` / `*.spec.ts` outside `skills/templates/`. Uppercase-only matching, so
  justfile `{{name}}` recipes and `${{ … }}` CI syntax never false-positive.

**F3. `verify.ps1` (PowerShell fallback) drifts from the justfile gate list.** `[DEFENDED]`
- *Kit defense:* `dox-check` `check_verify_parity()` ensures the no-just fallback
  runs the same gates as `justfile`'s `verify:` chain. Two hand-maintained lists
  drift; this catches it.

**F4. Hierarchical AGENTS.md child weakens a root rule.** `[DEFENDED — dox-check]`
- *Kit defense:* checks 1–4 enforce every child is indexed, points to root, and
  doesn't re-permit a root `❌`. Best-effort heuristic on the NO-WEAKEN check.

**F5. Inline flags (`#PLAN_UNCERTAINTY`) left unresolved at "done".** `[RESIDUAL]`
- *Gap:* no gate scans for unresolved uncertainty flags. They survive on disk for
  the §I drift audit and phase-end reconciliation to find — but those are agent
  discipline, not enforced.
- *Mitigation:* AGENTS.md §1a states "a phase is not done while one is unresolved"
  as a rule the agent enforces. Promote to `#EXPORT_CRITICAL` (§6-gated) if it
  needs teeth.

---

## G. Migration & upgrade hazards

**G1. Extracting the tar on top of an existing project.** `[DEFENDED — the one rule]`
- *Symptom:* lost work — the tar overwrites project state.
- *Kit defense:* every migration doc leads with "unpack OUTSIDE your project."
  The migrator/adopt scripts refuse to run if `--kit == --project`. The
  classify/backup/branch safety net means even a mistake is recoverable.

**G2. Auto-resolving `.kit-incoming` merges.** `[DEFENDED — the one agent rule]`
- *Symptom:* agent bulk-accepts all staged merges, clobbering project-specific
  content in AGENTS.md / SinsGotchasLearnings.md.
- *Kit defense:* MIGRATION.md "the one rule for the agent" — diff, explain,
  recommend, apply only on confirmation, one file at a time. `merge_sins.py`
  keeps your incidents first and verbatim.

**G3. Version drift in the migration docs themselves.** `[DEFENDED — this audit]`
- *Symptom:* docs say "upgrade to v6.1" when the kit is v6.5; agent follows stale
  instructions.
- *Was:* `ADOPT_AND_UPGRADE.md` and `START_HERE.md` still referenced v6.1.
- *Fix applied:* consolidated into `migrate/MIGRATION.md` (single source of truth);
  `ADOPT_AND_UPGRADE.md` is now a thin redirect; START_HERE Path B header corrected.
  No v6.1 references remain (except the explanatory note in the redirect).

**G4. Leftover retired files (old grep audit engine).** `[DEFENDED]`
- *Symptom:* `verification/audit_sins.{sh,py}` linger, agent runs the dead engine.
- *Kit defense:* migrator `--remove-retired` deletes them; MIGRATION.md Path A
  step 4 clears `rules/*.sins.yml` before regenerating.

**G5. Pre-commit hook not updated after migrate.** `[PARTIAL]`
- *Gap:* the `migrate` script does NOT touch hooks (your v4/v5 hook stays, which
  may run code-only `verify` not the full `verify-all`).
- *Fix:* after migrating, overwrite the hook (MIGRATION.md documents this):
  `.git/hooks/pre-commit` → `exec just verify-all`. `scaffold` and `adopt` both
  install the full hook already; only the migrate path needs the manual step.

---

## H. Tool / model incompatibility

**H1. Non-frontier model ignores the protocol.** `[PARTIAL — MODEL_NOTES.md]`
- *Symptom:* GLM/DeepSeek/MiniMax/MiMo skips the §0 read order, doesn't phase
  work, thrashes on failures.
- *Kit defense:* `MODEL_NOTES.md` gives per-model tips (context budget,
  reasoning-effort tiers, sampling). §6a anti-thrash ladder works with rungs 1–2
  (diagnostics + minimal repro) that need only code execution, no fancy tools.
- *Residual:* the kit can't force a model to read its guidance.

**H2. Tool without subagents / web search / Context7.** `[DEFENDED — graceful degradation]`
- *Symptom:* §4b / §6a rungs 3–4 reference tools the agent doesn't have.
- *Kit defense:* §6a explicitly says "use whichever are available — not every
  tool has Context7/web search/LSP/subagents; skip what you genuinely don't have."
  Rungs 1–2 always work. §4b has a "if the tool has no subagents, run phases
  sequentially in the main session" fallback.

**H3. Tool without a prompt-capture hook (Kilo, Zed, Antigravity, Hermes).** `[DEFENDED]`
- *Symptom:* `UserPromptLog.md` doesn't get auto-populated.
- *Kit defense:* §0a — "Only in a hook-less tool, append the entry yourself: the
  prompt inside a `~~~text` fence, EXACTLY as typed."

**H4. CRLF line endings break gate regexes.** `[DEFENDED — v6.5]`
- *Symptom:* a gate fails with "no heading found" even though the heading is
  visible — because Windows saved CRLF and the regex anchors on `\n`.
- *Kit defense:* every gate's `read_text_lf()` normalizes CRLF/CR → LF on read
  (never touching the file on disk). CRLF-immune for free.

**H5. `KIT_GATES_LENIENT=1` left set in a shell profile.** `[DEFENDED — loud banner]`
- *Symptom:* every missing tool becomes a silent warning; verify is "green" but
  checked nothing (back to A1).
- *Kit defense:* `run_gate.py` prints a loud boxed banner **every run** when
  LENIENT is set, so it can't be forgotten. Unset it for real builds.

---

## How to validate the kit is healthy (the check the user asked for)

Run these three, in order, on any machine you're about to drive a project from:

```bash
just doctor       # 1. every configured gate can actually execute (no silent false-greens)
just verify       # 2. code gates green mid-work (lint/typecheck/test/verify-libs/audit-sins/dox)
just verify-all   # 3. + bookkeeping (check-tasks/check-prompt-log) + smoke → all green
```

**Read the output, don't just check the exit code.** Each gate prints a summary
line: `[ran: … | unconfigured: … | MISSING: …]`. If `ran:` is empty or `MISSING:`
is non-empty, the green is not real — fix what doctor reports first.

**Validation result on this kit (2026-07-06):**
- `just doctor` → 1 expected finding (`pre-commit hook missing` — this is the
  unpackaged kit folder, not a scaffolded project; correct behavior).
- `just verify` → **found and fixed B1** (`verify_zod.ts` ERR_PNPM_NO_PKG_MANIFEST
  in a Python-only repo). Now green.
- `just verify-all` → green post-fix. All gates ran or cleanly skipped
  (unconfigured stacks skip symmetrically now).

The kit is functioning correctly with no residual looping or logic-management
issues after the B1 fix. The one residual class to stay aware of is **A4/E1/F5**
(doctor proves tools exist, not that gates check the right things; concurrent
multi-agent is unsupported; inline-flag resolution is prose discipline) — these
are documented above and have no gate by design.
